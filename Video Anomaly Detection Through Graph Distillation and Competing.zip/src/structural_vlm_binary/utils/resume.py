from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Set


@dataclass
class ResumeState:
    processed_keys: Set[str]
    y_true: List[int]
    y_pred: List[int]
    truncated_invalid_tail: bool = False


def compute_run_hash(cfg: Dict[str, Any]) -> str:
    raw = json.dumps(cfg, sort_keys=True, ensure_ascii=False)
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:12]


def atomic_write_json(path: Path, obj: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", delete=False, encoding="utf-8", dir=str(path.parent), suffix=".tmp") as tf:
        json.dump(obj, tf, ensure_ascii=False, indent=2)
        tmp = Path(tf.name)
    os.replace(tmp, path)


def load_resume_state(pred_path: Path) -> ResumeState:
    processed: Set[str] = set()
    y_true: List[int] = []
    y_pred: List[int] = []
    valid_lines: List[str] = []
    truncated = False
    with Path(pred_path).open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = line.strip()
            if not s:
                continue
            try:
                obj = json.loads(s)
            except Exception:
                truncated = True
                break
            valid_lines.append(line)
            seg_key = str(obj.get("segment_key", ""))
            if seg_key:
                processed.add(seg_key)
            try:
                y_true.append(int(obj.get("y_true", 0)))
                y_pred.append(int(obj.get("y_pred", 0)))
            except Exception:
                pass
    if truncated:
        with Path(pred_path).open("w", encoding="utf-8") as f:
            for line in valid_lines:
                f.write(line)
    return ResumeState(processed_keys=processed, y_true=y_true, y_pred=y_pred, truncated_invalid_tail=truncated)
