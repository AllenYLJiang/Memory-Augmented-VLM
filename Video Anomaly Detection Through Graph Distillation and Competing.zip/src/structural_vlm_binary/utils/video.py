from __future__ import annotations

import hashlib
import logging
import math
import re
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class VideoMeta:
    fps: float
    num_frames: int
    duration_sec: float


def _safe_float(x: object, default: float = 0.0) -> float:
    try:
        v = float(x)
        if math.isnan(v) or math.isinf(v):
            return float(default)
        return v
    except Exception:
        return float(default)


def _ensure_cv2():
    try:
        import cv2  # type: ignore
        return cv2
    except Exception as e:
        raise RuntimeError(
            "OpenCV is required. Please install opencv-python-headless or opencv-python."
        ) from e


def ffprobe_meta(video_path: Path) -> VideoMeta:
    cv2 = _ensure_cv2()
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Unable to open video: {video_path}")
    try:
        fps = _safe_float(cap.get(cv2.CAP_PROP_FPS), 25.0)
        if fps <= 0:
            fps = 25.0
        n = int(_safe_float(cap.get(cv2.CAP_PROP_FRAME_COUNT), 0.0))
        if n <= 0:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            cnt = 0
            while True:
                ok, _ = cap.read()
                if not ok:
                    break
                cnt += 1
            n = cnt
        if n <= 0:
            raise RuntimeError(f"Unable to determine frame count for {video_path}")
        return VideoMeta(fps=float(fps), num_frames=int(n), duration_sec=float(n) / float(fps))
    finally:
        cap.release()


def _safe_dirname(stem: str) -> str:
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", stem)
    base = re.sub(r"_+", "_", base).strip("._-") or "video"
    base = base[:80]
    h = hashlib.sha1(stem.encode("utf-8", errors="ignore")).hexdigest()[:8]
    return f"{base}_{h}"


def _open_writer(dst_video: Path, fps: float, size: Tuple[int, int]):
    cv2 = _ensure_cv2()
    w, h = int(size[0]), int(size[1])
    dst_video.parent.mkdir(parents=True, exist_ok=True)
    for code in ["mp4v", "avc1", "H264", "XVID"]:
        try:
            writer = cv2.VideoWriter(str(dst_video), cv2.VideoWriter_fourcc(*code), float(fps), (w, h))
            if writer.isOpened():
                return writer
            writer.release()
        except Exception:
            pass
    raise RuntimeError(f"Failed to open VideoWriter for {dst_video}")


def _is_readable_video(path: Path, *, min_frames: int = 1) -> bool:
    cv2 = _ensure_cv2()
    if not path.exists() or path.stat().st_size < 1024:
        return False
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        return False
    try:
        reported = int(_safe_float(cap.get(cv2.CAP_PROP_FRAME_COUNT), 0.0))
        if reported > 0 and reported < int(min_frames):
            return False
        ok, frame = cap.read()
        return bool(ok and frame is not None)
    finally:
        cap.release()


def extract_segment(
    *,
    src_video: Path,
    start_frame: int,
    end_frame: int,
    fps: float,
    dst_video: Path,
) -> Path:
    cv2 = _ensure_cv2()
    start_frame = max(0, int(start_frame))
    end_frame = max(start_frame, int(end_frame))

    tmp_video = dst_video.with_name(dst_video.stem + ".tmp" + dst_video.suffix)
    dst_video.parent.mkdir(parents=True, exist_ok=True)
    if dst_video.exists() and _is_readable_video(dst_video, min_frames=1):
        return dst_video
    for p in [dst_video, tmp_video]:
        if p.exists():
            try:
                p.unlink()
            except Exception:
                pass

    cap = cv2.VideoCapture(str(src_video))
    if not cap.isOpened():
        raise RuntimeError(f"Unable to open video: {src_video}")
    try:
        reported_n = int(_safe_float(cap.get(cv2.CAP_PROP_FRAME_COUNT), 0.0))
        if reported_n > 0:
            end_frame = min(end_frame, reported_n - 1)
            start_frame = min(start_frame, end_frame)
        fps_cap = _safe_float(cap.get(cv2.CAP_PROP_FPS), 25.0)
        fps_out = float(fps) if float(fps) > 0 else float(fps_cap)
        cap.set(cv2.CAP_PROP_POS_FRAMES, float(start_frame))
        ok, frame = cap.read()
        if not ok or frame is None:
            raise RuntimeError(f"Failed to read frame {start_frame} from {src_video}")
        h, w = frame.shape[:2]
        writer = _open_writer(tmp_video, fps_out, (w, h))
        try:
            writer.write(frame)
            cur = start_frame + 1
            while cur <= end_frame:
                ok, fr = cap.read()
                if not ok or fr is None:
                    break
                if fr.shape[:2] != (h, w):
                    fr = cv2.resize(fr, (w, h))
                writer.write(fr)
                cur += 1
        finally:
            writer.release()
    finally:
        cap.release()
    if not tmp_video.exists() or tmp_video.stat().st_size <= 0:
        raise RuntimeError(f"Failed to create segment for {src_video}")
    tmp_video.replace(dst_video)
    expected = max(1, end_frame - start_frame + 1)
    min_ok = max(1, int(expected * 0.8))
    if not _is_readable_video(dst_video, min_frames=min_ok):
        try:
            dst_video.unlink()
        except Exception:
            pass
        raise RuntimeError(f"Created unreadable segment: {dst_video}")
    return dst_video


class SegmentCache:
    def __init__(self, cache_dir: Path) -> None:
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._locks_guard = threading.Lock()
        self._locks: dict[str, threading.Lock] = {}

    def _lock_for(self, out: Path) -> threading.Lock:
        key = str(Path(out).resolve())
        with self._locks_guard:
            lk = self._locks.get(key)
            if lk is None:
                lk = threading.Lock()
                self._locks[key] = lk
            return lk

    def get_segment(self, *, video_path: Path, start_frame: int, end_frame: int, fps: float) -> Path:
        key = hashlib.sha1(f"{video_path.resolve()}|{start_frame}|{end_frame}".encode("utf-8")).hexdigest()[:16]
        vid_dir = self.cache_dir / _safe_dirname(video_path.stem)
        out = vid_dir / f"seg_{key}_f{start_frame}-{end_frame}.mp4"
        with self._lock_for(out):
            return extract_segment(src_video=video_path, start_frame=start_frame, end_frame=end_frame, fps=fps, dst_video=out)
