from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

SEG_RE = re.compile(r"_seg(\d+)_f(\d+)-(\d+)\.mp4$", re.IGNORECASE)


@dataclass(frozen=True)
class SegmentInfo:
    video_id: str
    path: Path
    seg_idx: int
    start_frame: int
    end_frame: int


def parse_segment_filename(name: str) -> Optional[Tuple[int, int, int]]:
    m = SEG_RE.search(name)
    if not m:
        return None
    seg_idx, s, e = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if e < s:
        s, e = e, s
    return seg_idx, s, e


def scan_segments(segments_root: Path) -> List[SegmentInfo]:
    out: List[SegmentInfo] = []
    for vid_dir in sorted([p for p in Path(segments_root).iterdir() if p.is_dir()]):
        for mp4 in sorted(vid_dir.glob("*.mp4")):
            parsed = parse_segment_filename(mp4.name)
            if not parsed:
                continue
            seg_idx, s, e = parsed
            out.append(SegmentInfo(video_id=vid_dir.name, path=mp4, seg_idx=seg_idx, start_frame=s, end_frame=e))
    return out
