from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Tuple


def merge_intervals(intervals: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
    if not intervals:
        return []
    intervals = sorted(intervals)
    merged: List[Tuple[int, int]] = []
    cur_s, cur_e = intervals[0]
    for s, e in intervals[1:]:
        if s <= cur_e + 1:
            cur_e = max(cur_e, e)
        else:
            merged.append((cur_s, cur_e))
            cur_s, cur_e = s, e
    merged.append((cur_s, cur_e))
    return merged


def _pairwise_intervals(nums: List[int]) -> List[Tuple[int, int]]:
    intervals: List[Tuple[int, int]] = []
    for i in range(0, len(nums) - 1, 2):
        s, e = nums[i], nums[i + 1]
        if e < s:
            s, e = e, s
        if s < 0 or e < 0:
            continue
        intervals.append((s, e))
    return intervals


def _parse_uniform_annotation_numbers(nums: List[int]) -> List[Tuple[int, int]]:
    """
    Robust parsing for the user's annotations_uniform_format.txt.

    Observed patterns:
    1) direct interval pairs: [start1, end1, start2, end2, ...]
    2) count-prefixed pairs: [k, start1, end1, ...] with optional trailing sentinels like -1

    The old parser treated every integer after the video id as an interval endpoint.
    That can turn a leading count token like `1` into a fake anomaly starting at frame 1,
    which incorrectly marks early windows (e.g. frames 0-95) as anomalous.
    """
    clean = [int(x) for x in nums if int(x) >= 0]
    if not clean:
        return []

    if len(clean) % 2 == 1 and 0 < clean[0] <= 20:
        return merge_intervals(_pairwise_intervals(clean[1:]))

    if 0 < clean[0] <= 20 and (len(clean) - 1) >= 2 * clean[0] and (len(clean) - 1) % 2 == 0:
        k = clean[0]
        payload = clean[1 : 1 + 2 * k]
        if len(payload) == 2 * k:
            return merge_intervals(_pairwise_intervals(payload))

    return merge_intervals(_pairwise_intervals(clean))


def load_annotations(anno_file: Path) -> Dict[str, List[Tuple[int, int]]]:
    ann: Dict[str, List[Tuple[int, int]]] = {}
    with Path(anno_file).open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            parts = line.strip().split()
            if not parts:
                continue
            vid = parts[0]
            nums: List[int] = []
            for x in parts[1:]:
                try:
                    nums.append(int(x))
                except Exception:
                    pass
            ann[vid] = _parse_uniform_annotation_numbers(nums)
    return ann


def overlap_len_inclusive(a0: int, a1: int, b0: int, b1: int) -> int:
    lo = max(a0, b0)
    hi = min(a1, b1)
    return max(0, hi - lo + 1)


def anomalous_fraction(seg_start: int, seg_end: int, intervals: List[Tuple[int, int]]) -> float:
    seg_len = seg_end - seg_start + 1
    if seg_len <= 0 or not intervals:
        return 0.0
    total = 0
    for s, e in intervals:
        total += overlap_len_inclusive(seg_start, seg_end, s, e)
    return total / float(seg_len)


def gt_label(seg_start: int, seg_end: int, intervals: List[Tuple[int, int]], threshold: float = 0.6):
    frac = anomalous_fraction(seg_start, seg_end, intervals)
    return (1 if frac >= threshold else 0), frac
