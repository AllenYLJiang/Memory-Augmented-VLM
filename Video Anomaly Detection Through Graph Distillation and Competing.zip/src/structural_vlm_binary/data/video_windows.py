from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, List, Optional, Tuple

from ..utils.video import SegmentCache, ffprobe_meta


@dataclass(frozen=True)
class WindowSegment:
    video_id: str
    video_path: Path
    seg_idx: int
    start_frame: int
    end_frame: int
    fps: float
    cache_path: Optional[Path] = None


def scan_videos(videos_root: Path, glob: str = "*.mp4") -> List[Path]:
    return sorted(Path(videos_root).glob(glob))


def iter_windows(*, num_frames: int, window: int, stride: int, max_windows: int = 0) -> Iterator[Tuple[int, int, int]]:
    seg_idx = 0
    start = 0
    last = num_frames - 1
    while start <= last:
        end = min(last, start + window - 1)
        yield seg_idx, start, end
        seg_idx += 1
        if max_windows and seg_idx >= max_windows:
            break
        if end >= last:
            break
        start += stride


def build_window_dataset(
    *,
    videos_root: Path,
    window: int,
    stride: int,
    videos_glob: str = "*.mp4",
    max_windows_per_video: int = 0,
) -> List[WindowSegment]:
    vids = scan_videos(Path(videos_root), glob=videos_glob)
    out: List[WindowSegment] = []
    for vp in vids:
        meta = ffprobe_meta(vp)
        for seg_idx, s, e in iter_windows(num_frames=meta.num_frames, window=window, stride=stride, max_windows=max_windows_per_video):
            out.append(WindowSegment(video_id=vp.stem, video_path=vp, seg_idx=seg_idx, start_frame=s, end_frame=e, fps=meta.fps))
    return out
