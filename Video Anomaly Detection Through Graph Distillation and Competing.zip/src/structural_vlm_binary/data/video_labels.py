from __future__ import annotations

import re
from typing import Dict, List, Set

# XD-Violence-style filename codes used as a video-level prior/filter.
# This is intentionally conservative: if no label code is present, all abnormal graphs stay allowed.
CODE_TO_GRAPH: Dict[str, str] = {
    "B1": "reciprocal_conflict_chain",
    "B2": "localized_discharge_chain",
    "G": "source_centered_blast_chain",
    "B4": "crowd_escalation_chain",
    "B5": "unilateral_control_chain",
    "B6": "vehicle_collision_chain",
}

_LABEL_RE = re.compile(r"label_([^./\\]+)")


def extract_label_codes(name: str) -> List[str]:
    m = _LABEL_RE.search(str(name))
    if not m:
        return []
    out: List[str] = []
    for tok in m.group(1).split("-"):
        tok = tok.strip()
        if not tok or tok == "0":
            continue
        out.append(tok)
    return out


def allowed_abnormal_graphs_from_video_name(name: str) -> Set[str]:
    out: Set[str] = set()
    for code in extract_label_codes(name):
        g = CODE_TO_GRAPH.get(code)
        if g:
            out.add(g)
    return out
