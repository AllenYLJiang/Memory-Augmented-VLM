from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from statistics import median
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .graph_schema import ABNORMAL_GRAPHS, node_evidence_class
from .ov_client import OpenVikingStore, join_uri


_FRONT_MATTER_RE = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)
_KEYVAL_RE = re.compile(r"^([A-Za-z0-9_\-]+):\s*(.+)$")
_LINEAR_MODEL_NAME = "linear_score_v2"
_MIN_GRAPH_POS = 8
_MIN_GRAPH_NEG = 8
_MIN_GRAPH_TOTAL = 40


def safe_slug(s: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_\-]+", "_", str(s or "")).strip("_") or "default"


def clamp01(x: Any) -> float:
    try:
        v = float(x)
    except Exception:
        return 0.0
    if math.isnan(v):
        return 0.0
    if v < 0.0:
        return 0.0
    if v > 1.0:
        return 1.0
    return v


def _prob_margin01(ab_prob: float, nm_prob: float) -> float:
    # ab_prob - nm_prob is nominally in [-1, 1]; map to [0, 1]
    return clamp01(0.5 + 0.5 * (float(ab_prob) - float(nm_prob)))


@dataclass(frozen=True)
class RescueCriterion:
    graph: str = "global"
    criterion_model: str = _LINEAR_MODEL_NAME
    weight_center_direct_anchor: float = 0.40
    weight_center_binding_consistency: float = 0.20
    weight_center_scene_relation: float = 0.15
    weight_rescue_direct_gain: float = 0.25
    score_threshold: float = 0.50
    samples_positive: int = 0
    samples_negative: int = 0
    source_level: str = "global"

    def feature_vector(
        self,
        *,
        center_direct_anchor: float,
        center_binding_consistency: float,
        center_scene_relation: float,
        rescue_direct_gain: float,
    ) -> Dict[str, float]:
        return {
            "center_direct_anchor": clamp01(center_direct_anchor),
            "center_binding_consistency": clamp01(center_binding_consistency),
            "center_scene_relation": clamp01(center_scene_relation),
            "rescue_direct_gain": clamp01(rescue_direct_gain),
        }

    def score(
        self,
        *,
        center_direct_anchor: float,
        center_binding_consistency: float,
        center_scene_relation: float,
        rescue_direct_gain: float,
    ) -> Tuple[float, Dict[str, float], Dict[str, float]]:
        feats = self.feature_vector(
            center_direct_anchor=center_direct_anchor,
            center_binding_consistency=center_binding_consistency,
            center_scene_relation=center_scene_relation,
            rescue_direct_gain=rescue_direct_gain,
        )
        contribs = {
            "center_direct_anchor": self.weight_center_direct_anchor * feats["center_direct_anchor"],
            "center_binding_consistency": self.weight_center_binding_consistency * feats["center_binding_consistency"],
            "center_scene_relation": self.weight_center_scene_relation * feats["center_scene_relation"],
            "rescue_direct_gain": self.weight_rescue_direct_gain * feats["rescue_direct_gain"],
        }
        score = float(sum(contribs.values()))
        return score, feats, contribs

    def to_meta(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CompetitionCriterion:
    graph: str = "global"
    criterion_model: str = _LINEAR_MODEL_NAME
    weight_abnormal_direct: float = 0.40
    weight_normal_clearance: float = 0.20
    weight_abnormal_binding: float = 0.20
    weight_probability_margin: float = 0.20
    score_threshold: float = 0.55
    samples_positive: int = 0
    samples_negative: int = 0
    source_level: str = "global"

    def feature_vector(
        self,
        *,
        ab_direct: float,
        nm_direct: float,
        ab_prob: float,
        nm_prob: float,
        ab_binding: float,
    ) -> Dict[str, float]:
        return {
            "abnormal_direct": clamp01(ab_direct),
            "normal_clearance": clamp01(1.0 - clamp01(nm_direct)),
            "abnormal_binding": clamp01(ab_binding),
            "probability_margin": _prob_margin01(float(ab_prob), float(nm_prob)),
        }

    def score(
        self,
        *,
        ab_direct: float,
        nm_direct: float,
        ab_prob: float,
        nm_prob: float,
        ab_binding: float,
    ) -> Tuple[float, Dict[str, float], Dict[str, float]]:
        feats = self.feature_vector(
            ab_direct=ab_direct,
            nm_direct=nm_direct,
            ab_prob=ab_prob,
            nm_prob=nm_prob,
            ab_binding=ab_binding,
        )
        contribs = {
            "abnormal_direct": self.weight_abnormal_direct * feats["abnormal_direct"],
            "normal_clearance": self.weight_normal_clearance * feats["normal_clearance"],
            "abnormal_binding": self.weight_abnormal_binding * feats["abnormal_binding"],
            "probability_margin": self.weight_probability_margin * feats["probability_margin"],
        }
        score = float(sum(contribs.values()))
        return score, feats, contribs

    def to_meta(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CriterionRuleSet:
    rescue_global: RescueCriterion = RescueCriterion()
    rescue_by_graph: Dict[str, RescueCriterion] | None = None
    competition_global: CompetitionCriterion = CompetitionCriterion()
    competition_by_graph: Dict[str, CompetitionCriterion] | None = None

    def rescue(self, graph: str) -> RescueCriterion:
        if self.rescue_by_graph and graph in self.rescue_by_graph:
            return self.rescue_by_graph[graph]
        return self.rescue_global

    def competition(self, graph: str) -> CompetitionCriterion:
        if self.competition_by_graph and graph in self.competition_by_graph:
            return self.competition_by_graph[graph]
        return self.competition_global


class CriterionManager:
    def __init__(self, rules: CriterionRuleSet) -> None:
        self.rules = rules

    @classmethod
    def from_local_repo(cls, repo_dir: Path) -> "CriterionManager":
        repo_dir = Path(repo_dir)
        rules = CriterionRuleSet(rescue_by_graph={}, competition_by_graph={})
        if not repo_dir.exists():
            return cls(rules)
        loaded = 0
        for md in repo_dir.rglob("*.md"):
            kind, graph, meta = _parse_criterion_markdown(md.read_text(encoding="utf-8", errors="ignore"))
            if not kind:
                continue
            if str(meta.get("criterion_model", "") or "") != _LINEAR_MODEL_NAME:
                continue
            if kind == "rescue_gate":
                loaded += 1
                rule = RescueCriterion(
                    graph=graph or "global",
                    criterion_model=str(meta.get("criterion_model", _LINEAR_MODEL_NAME)),
                    weight_center_direct_anchor=float(meta.get("weight_center_direct_anchor", rules.rescue_global.weight_center_direct_anchor)),
                    weight_center_binding_consistency=float(meta.get("weight_center_binding_consistency", rules.rescue_global.weight_center_binding_consistency)),
                    weight_center_scene_relation=float(meta.get("weight_center_scene_relation", rules.rescue_global.weight_center_scene_relation)),
                    weight_rescue_direct_gain=float(meta.get("weight_rescue_direct_gain", rules.rescue_global.weight_rescue_direct_gain)),
                    score_threshold=float(meta.get("score_threshold", rules.rescue_global.score_threshold)),
                    samples_positive=int(meta.get("samples_positive", 0) or 0),
                    samples_negative=int(meta.get("samples_negative", 0) or 0),
                    source_level=str(meta.get("source_level", "global") or "global"),
                )
                if rule.graph == "global":
                    rules.rescue_global = rule
                else:
                    rules.rescue_by_graph[rule.graph] = rule
            elif kind == "abnormal_over_normal":
                loaded += 1
                rule = CompetitionCriterion(
                    graph=graph or "global",
                    criterion_model=str(meta.get("criterion_model", _LINEAR_MODEL_NAME)),
                    weight_abnormal_direct=float(meta.get("weight_abnormal_direct", rules.competition_global.weight_abnormal_direct)),
                    weight_normal_clearance=float(meta.get("weight_normal_clearance", rules.competition_global.weight_normal_clearance)),
                    weight_abnormal_binding=float(meta.get("weight_abnormal_binding", rules.competition_global.weight_abnormal_binding)),
                    weight_probability_margin=float(meta.get("weight_probability_margin", rules.competition_global.weight_probability_margin)),
                    score_threshold=float(meta.get("score_threshold", rules.competition_global.score_threshold)),
                    samples_positive=int(meta.get("samples_positive", 0) or 0),
                    samples_negative=int(meta.get("samples_negative", 0) or 0),
                    source_level=str(meta.get("source_level", "global") or "global"),
                )
                if rule.graph == "global":
                    rules.competition_global = rule
                else:
                    rules.competition_by_graph[rule.graph] = rule
        if loaded <= 0:
            rules = CriterionRuleSet(rescue_by_graph={}, competition_by_graph={})
        return cls(rules)

    @classmethod
    def from_openviking(cls, store: OpenVikingStore, root_uri: str) -> "CriterionManager":
        rules = CriterionRuleSet(rescue_by_graph={}, competition_by_graph={})
        graph_keys = [g.key for g in ABNORMAL_GRAPHS]
        targets: List[Tuple[str, str]] = [("rescue_gate", "global"), ("abnormal_over_normal", "global")]
        targets += [("rescue_gate", g) for g in graph_keys]
        targets += [("abnormal_over_normal", g) for g in graph_keys]
        for kind, graph in targets:
            uri = join_uri(root_uri, f"criteria/{kind}/{safe_slug(graph)}/")
            try:
                matches = store.find(f"{kind} {graph} criterion score", target_uri=uri, limit=3, score_threshold=None)
            except Exception:
                matches = []
            if not matches:
                continue
            text = None
            for m in matches:
                try:
                    text = store.read(m.uri)
                    if text:
                        break
                except Exception:
                    continue
            if not text:
                continue
            parsed_kind, parsed_graph, meta = _parse_criterion_markdown(text)
            if parsed_kind != kind:
                continue
            if str(meta.get("criterion_model", "") or "") != _LINEAR_MODEL_NAME:
                continue
            g = parsed_graph or graph
            if kind == "rescue_gate":
                rule = RescueCriterion(
                    graph=g,
                    criterion_model=str(meta.get("criterion_model", _LINEAR_MODEL_NAME)),
                    weight_center_direct_anchor=float(meta.get("weight_center_direct_anchor", rules.rescue_global.weight_center_direct_anchor)),
                    weight_center_binding_consistency=float(meta.get("weight_center_binding_consistency", rules.rescue_global.weight_center_binding_consistency)),
                    weight_center_scene_relation=float(meta.get("weight_center_scene_relation", rules.rescue_global.weight_center_scene_relation)),
                    weight_rescue_direct_gain=float(meta.get("weight_rescue_direct_gain", rules.rescue_global.weight_rescue_direct_gain)),
                    score_threshold=float(meta.get("score_threshold", rules.rescue_global.score_threshold)),
                    samples_positive=int(meta.get("samples_positive", 0) or 0),
                    samples_negative=int(meta.get("samples_negative", 0) or 0),
                    source_level=str(meta.get("source_level", "global") or "global"),
                )
                if g == "global":
                    rules.rescue_global = rule
                else:
                    rules.rescue_by_graph[g] = rule
            else:
                rule = CompetitionCriterion(
                    graph=g,
                    criterion_model=str(meta.get("criterion_model", _LINEAR_MODEL_NAME)),
                    weight_abnormal_direct=float(meta.get("weight_abnormal_direct", rules.competition_global.weight_abnormal_direct)),
                    weight_normal_clearance=float(meta.get("weight_normal_clearance", rules.competition_global.weight_normal_clearance)),
                    weight_abnormal_binding=float(meta.get("weight_abnormal_binding", rules.competition_global.weight_abnormal_binding)),
                    weight_probability_margin=float(meta.get("weight_probability_margin", rules.competition_global.weight_probability_margin)),
                    score_threshold=float(meta.get("score_threshold", rules.competition_global.score_threshold)),
                    samples_positive=int(meta.get("samples_positive", 0) or 0),
                    samples_negative=int(meta.get("samples_negative", 0) or 0),
                    source_level=str(meta.get("source_level", "global") or "global"),
                )
                if g == "global":
                    rules.competition_global = rule
                else:
                    rules.competition_by_graph[g] = rule
        return cls(rules)

    def should_accept_rescue(
        self,
        *,
        graph: str,
        base_ab_graph: str,
        base_ab_direct: float,
        base_ab_binding: float,
        base_ab_scene_relation: float,
        final_ab_direct: float,
    ) -> Tuple[bool, Dict[str, Any]]:
        rule = self.rules.rescue(graph)
        rescue_gain = max(0.0, float(final_ab_direct) - float(base_ab_direct))
        score, feats, contribs = rule.score(
            center_direct_anchor=base_ab_direct,
            center_binding_consistency=base_ab_binding,
            center_scene_relation=base_ab_scene_relation,
            rescue_direct_gain=rescue_gain,
        )
        ok = bool(score >= float(rule.score_threshold))
        return ok, {
            "criterion_kind": "rescue_gate",
            "criterion_model": rule.criterion_model,
            "graph": graph,
            "rule": rule.to_meta(),
            "base_ab_graph": str(base_ab_graph or "NONE"),
            "features": feats,
            "contributions": contribs,
            "score": float(score),
            "score_threshold": float(rule.score_threshold),
            "accept": ok,
        }

    def maybe_force_abnormal(
        self,
        *,
        graph: str,
        ab_direct: float,
        nm_direct: float,
        ab_prob: float,
        nm_prob: float,
        ab_binding: float,
        decision: str,
    ) -> Tuple[bool, Dict[str, Any]]:
        rule = self.rules.competition(graph)
        score, feats, contribs = rule.score(
            ab_direct=ab_direct,
            nm_direct=nm_direct,
            ab_prob=ab_prob,
            nm_prob=nm_prob,
            ab_binding=ab_binding,
        )
        ok = bool(decision in {"uncertain", "normal"} and score >= float(rule.score_threshold))
        return ok, {
            "criterion_kind": "abnormal_over_normal",
            "criterion_model": rule.criterion_model,
            "graph": graph,
            "rule": rule.to_meta(),
            "decision_before": decision,
            "features": feats,
            "contributions": contribs,
            "score": float(score),
            "score_threshold": float(rule.score_threshold),
            "force_abnormal": ok,
        }


def _to_bool(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    return s in {"1", "true", "yes", "y", "on"}


def _parse_criterion_markdown(text: str) -> Tuple[str, str, Dict[str, Any]]:
    meta: Dict[str, Any] = {}
    m = _FRONT_MATTER_RE.search(text or "")
    if m:
        for line in m.group(1).splitlines():
            mm = _KEYVAL_RE.match(line.strip())
            if not mm:
                continue
            k = mm.group(1).strip()
            v = mm.group(2).strip()
            meta[k] = _parse_scalar(v)
    kind = str(meta.get("criterion_kind", "") or "")
    graph = str(meta.get("graph", "") or "")
    return kind, graph, meta


def _parse_scalar(v: str) -> Any:
    vv = str(v).strip()
    if vv.lower() in {"true", "false"}:
        return vv.lower() == "true"
    try:
        if "." in vv:
            return float(vv)
        return int(vv)
    except Exception:
        return vv


def _extract_comp(record: Dict[str, Any], which: str) -> Dict[str, Any]:
    src = record.get(which, {}) if isinstance(record.get(which, {}), dict) else {}
    comp = src.get("competition_debug", {}) if isinstance(src.get("competition_debug", {}), dict) else {}
    return comp


def _best_profile(comp: Dict[str, Any], side: str) -> Dict[str, Any]:
    item = comp.get(f"best_{side}") if isinstance(comp.get(f"best_{side}"), dict) else None
    if not item:
        return {}
    prof = item.get("profile", {}) if isinstance(item.get("profile", {}), dict) else {}
    out = dict(prof)
    out["probability"] = float(item.get("probability", 0.0) or 0.0)
    out["graph"] = str(item.get("graph", out.get("graph", "NONE")) or "NONE")
    return out


def _safe_float(d: Dict[str, Any], k: str, default: float = 0.0) -> float:
    try:
        return float(d.get(k, default) or default)
    except Exception:
        return float(default)


def _count_rescue_event_updates(graph: str, rescue_result: Dict[str, Any]) -> int:
    node_ids = rescue_result.get("updated_nodes_now_supported_in_center", []) if isinstance(rescue_result.get("updated_nodes_now_supported_in_center", []), list) else []
    n = 0
    for node_id in node_ids:
        if not isinstance(node_id, str):
            continue
        if node_evidence_class(graph, node_id) == "event_anchor":
            n += 1
    return int(n)


def _select_final_rescue_attempt(record: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    rescue = record.get("rescue", {}) if isinstance(record.get("rescue", {}), dict) else {}
    attempts = rescue.get("attempts", []) if isinstance(rescue.get("attempts", []), list) else []
    final_from = str(rescue.get("final_from", "base") or "base")
    if final_from == "base":
        return None
    m = re.match(r"rescue_(\d+)x", final_from)
    if not m:
        return attempts[-1] if attempts else None
    fac = int(m.group(1))
    for a in attempts:
        if int(a.get("factor", -1)) == fac:
            return a
    return attempts[-1] if attempts else None


def _balanced_threshold(pos_scores: List[float], neg_scores: List[float], default: float) -> float:
    pos = [float(x) for x in pos_scores if x is not None and not math.isnan(float(x))]
    neg = [float(x) for x in neg_scores if x is not None and not math.isnan(float(x))]
    if not pos or not neg:
        return float(default)
    cands = sorted(set(pos + neg + [default]))
    best_t = float(default)
    best_bal = -1.0
    for t in cands:
        tpr = sum(1 for x in pos if x >= t) / max(1, len(pos))
        tnr = sum(1 for x in neg if x < t) / max(1, len(neg))
        bal = 0.5 * (tpr + tnr)
        if bal > best_bal:
            best_bal = bal
            best_t = float(t)
    return float(best_t)


def _mean(xs: List[float]) -> float:
    if not xs:
        return 0.0
    return float(sum(float(x) for x in xs) / len(xs))


def _std(xs: List[float]) -> float:
    if len(xs) <= 1:
        return 0.0
    m = _mean(xs)
    return float(math.sqrt(sum((float(x) - m) ** 2 for x in xs) / len(xs)))


def _monotonic_linear_weights(
    pos_rows: List[Dict[str, float]],
    neg_rows: List[Dict[str, float]],
    feature_names: List[str],
    fallback_weights: Dict[str, float],
) -> Dict[str, float]:
    if not pos_rows or not neg_rows:
        return dict(fallback_weights)
    raw: Dict[str, float] = {}
    for name in feature_names:
        pos_vals = [clamp01(r.get(name, 0.0)) for r in pos_rows]
        neg_vals = [clamp01(r.get(name, 0.0)) for r in neg_rows]
        diff = _mean(pos_vals) - _mean(neg_vals)
        spread = _std(pos_vals) + _std(neg_vals) + 1e-6
        raw[name] = max(0.0, diff / spread)
    s = sum(raw.values())
    if s <= 1e-8:
        return dict(fallback_weights)
    return {k: float(v / s) for k, v in raw.items()}


def _scores_from_rows(rows: List[Dict[str, float]], weights: Dict[str, float]) -> List[float]:
    outs: List[float] = []
    for r in rows:
        s = 0.0
        for k, w in weights.items():
            s += float(w) * clamp01(r.get(k, 0.0))
        outs.append(float(s))
    return outs


def _sufficient_graph_support(pos_n: int, neg_n: int) -> bool:
    return bool(pos_n >= _MIN_GRAPH_POS and neg_n >= _MIN_GRAPH_NEG and (pos_n + neg_n) >= _MIN_GRAPH_TOTAL)


def write_criterion_repo_from_predictions(predictions_path: Path, out_repo: Path) -> Dict[str, Any]:
    predictions_path = Path(predictions_path)
    out_repo = Path(out_repo)
    out_repo.mkdir(parents=True, exist_ok=True)

    rescue_examples: Dict[str, Dict[str, List[Dict[str, float]]]] = {}
    comp_examples: Dict[str, Dict[str, List[Dict[str, float]]]] = {}

    def _add_row(bucket: Dict[str, Dict[str, List[Dict[str, float]]]], graph: str, label: str, row: Dict[str, float]) -> None:
        graph = graph or "global"
        bucket.setdefault(graph, {}).setdefault(label, []).append({k: clamp01(v) for k, v in row.items()})
        bucket.setdefault("global", {}).setdefault(label, []).append({k: clamp01(v) for k, v in row.items()})

    with predictions_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except Exception:
                continue
            y_true = int(rec.get("y_true", 0) or 0)
            y_pred = int(rec.get("y_pred", 0) or 0)

            rescue = rec.get("rescue", {}) if isinstance(rec.get("rescue", {}), dict) else {}
            if str(rescue.get("final_from", "base") or "base") != "base" and y_pred == 1:
                base_comp = _extract_comp(rec, "base_result")
                final_comp = _extract_comp(rec, "final_result")
                base_ab = _best_profile(base_comp, "abnormal")
                final_ab = _best_profile(final_comp, "abnormal")
                graph = str(final_ab.get("graph", base_ab.get("graph", "NONE")) or "NONE")
                if graph != "NONE":
                    label = "pos" if y_true == 1 else "neg"
                    base_direct = _safe_float(base_ab, "event_anchor_strength")
                    base_binding = _safe_float(base_ab, "binding_consistency")
                    base_relation = _safe_float(base_ab, "scene_relation_support")
                    final_direct = _safe_float(final_ab, "event_anchor_strength")
                    gain = max(0.0, final_direct - base_direct)
                    _add_row(rescue_examples, graph, label, {
                        "center_direct_anchor": base_direct,
                        "center_binding_consistency": base_binding,
                        "center_scene_relation": base_relation,
                        "rescue_direct_gain": gain,
                    })

            base = rec.get("base_result", {}) if isinstance(rec.get("base_result", {}), dict) else {}
            base_dec = str(base.get("binary_decision", rec.get("binary_decision", "uncertain")) or "uncertain")
            base_comp = _extract_comp(rec, "base_result")
            base_ab = _best_profile(base_comp, "abnormal")
            base_nm = _best_profile(base_comp, "normal")
            graph = str(base_ab.get("graph", "NONE") or "NONE")
            if graph != "NONE" and base_dec in {"uncertain", "normal"}:
                ab_direct = _safe_float(base_ab, "event_anchor_strength")
                ab_prob = _safe_float(base_ab, "probability")
                nm_direct = _safe_float(base_nm, "confound_anchor_strength")
                nm_prob = _safe_float(base_nm, "probability")
                ab_binding = _safe_float(base_ab, "binding_consistency")
                if ab_direct > 0.05 or ab_prob > 0.30:
                    label = "pos" if y_true == 1 else "neg"
                    _add_row(comp_examples, graph, label, {
                        "abnormal_direct": ab_direct,
                        "normal_clearance": 1.0 - clamp01(nm_direct),
                        "abnormal_binding": ab_binding,
                        "probability_margin": _prob_margin01(ab_prob, nm_prob),
                    })

    rescue_global = _learn_rescue_from_bucket("global", rescue_examples.get("global", {}))
    comp_global = _learn_comp_from_bucket("global", comp_examples.get("global", {}))

    rescue_rules: Dict[str, RescueCriterion] = {}
    comp_rules: Dict[str, CompetitionCriterion] = {}
    skipped_graphs: Dict[str, Dict[str, Any]] = {}

    for g in sorted(set(k for k in rescue_examples.keys() if k != "global")):
        pos_n = len((rescue_examples.get(g, {}) or {}).get("pos", []))
        neg_n = len((rescue_examples.get(g, {}) or {}).get("neg", []))
        if _sufficient_graph_support(pos_n, neg_n):
            rescue_rules[g] = _learn_rescue_from_bucket(g, rescue_examples.get(g, {}), fallback=rescue_global, source_level="graph")
        else:
            skipped_graphs.setdefault(g, {})["rescue"] = {"samples_positive": pos_n, "samples_negative": neg_n, "reason": "insufficient_support_fallback_to_global"}

    for g in sorted(set(k for k in comp_examples.keys() if k != "global")):
        pos_n = len((comp_examples.get(g, {}) or {}).get("pos", []))
        neg_n = len((comp_examples.get(g, {}) or {}).get("neg", []))
        if _sufficient_graph_support(pos_n, neg_n):
            comp_rules[g] = _learn_comp_from_bucket(g, comp_examples.get(g, {}), fallback=comp_global, source_level="graph")
        else:
            skipped_graphs.setdefault(g, {})["competition"] = {"samples_positive": pos_n, "samples_negative": neg_n, "reason": "insufficient_support_fallback_to_global"}

    _write_rule(out_repo, "rescue_gate", rescue_global.graph, rescue_global.to_meta(), statement="Allow neighboring-window rescue to influence the center only when a simple rescue score from center direct anchor, binding, scene relation, and rescue gain exceeds threshold.")
    _write_rule(out_repo, "abnormal_over_normal", comp_global.graph, comp_global.to_meta(), statement="When the base model is uncertain or weakly normal, let abnormal cues conquer normal/context only when a simple abnormal-over-normal score exceeds threshold.")
    for g, rule in rescue_rules.items():
        _write_rule(out_repo, "rescue_gate", g, rule.to_meta(), statement=f"Graph-specific rescue score rule for {g}; learned only because this graph had enough support examples.")
    for g, rule in comp_rules.items():
        _write_rule(out_repo, "abnormal_over_normal", g, rule.to_meta(), statement=f"Graph-specific abnormal-over-normal score rule for {g}; learned only because this graph had enough support examples.")

    summary = {
        "predictions_path": str(predictions_path),
        "out_repo": str(out_repo),
        "criterion_model": _LINEAR_MODEL_NAME,
        "support_policy": {
            "min_graph_positive": _MIN_GRAPH_POS,
            "min_graph_negative": _MIN_GRAPH_NEG,
            "min_graph_total": _MIN_GRAPH_TOTAL,
        },
        "rescue_global": rescue_global.to_meta(),
        "competition_global": comp_global.to_meta(),
        "rescue_graphs": {k: v.to_meta() for k, v in rescue_rules.items()},
        "competition_graphs": {k: v.to_meta() for k, v in comp_rules.items()},
        "skipped_graphs": skipped_graphs,
    }
    (out_repo / "criteria_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def _learn_rescue_from_bucket(graph: str, bucket: Dict[str, List[Dict[str, float]]], fallback: RescueCriterion | None = None, source_level: str = "global") -> RescueCriterion:
    fb = fallback or RescueCriterion(graph=graph, source_level=source_level)
    pos_rows = [dict(r) for r in (bucket.get("pos", []) if isinstance(bucket.get("pos", []), list) else [])]
    neg_rows = [dict(r) for r in (bucket.get("neg", []) if isinstance(bucket.get("neg", []), list) else [])]
    feature_names = ["center_direct_anchor", "center_binding_consistency", "center_scene_relation", "rescue_direct_gain"]
    fallback_weights = {
        "center_direct_anchor": fb.weight_center_direct_anchor,
        "center_binding_consistency": fb.weight_center_binding_consistency,
        "center_scene_relation": fb.weight_center_scene_relation,
        "rescue_direct_gain": fb.weight_rescue_direct_gain,
    }
    weights = _monotonic_linear_weights(pos_rows, neg_rows, feature_names, fallback_weights)
    pos_scores = _scores_from_rows(pos_rows, weights)
    neg_scores = _scores_from_rows(neg_rows, weights)
    threshold = _balanced_threshold(pos_scores, neg_scores, fb.score_threshold)
    return RescueCriterion(
        graph=graph,
        criterion_model=_LINEAR_MODEL_NAME,
        weight_center_direct_anchor=float(weights["center_direct_anchor"]),
        weight_center_binding_consistency=float(weights["center_binding_consistency"]),
        weight_center_scene_relation=float(weights["center_scene_relation"]),
        weight_rescue_direct_gain=float(weights["rescue_direct_gain"]),
        score_threshold=float(threshold),
        samples_positive=len(pos_rows),
        samples_negative=len(neg_rows),
        source_level=source_level,
    )


def _learn_comp_from_bucket(graph: str, bucket: Dict[str, List[Dict[str, float]]], fallback: CompetitionCriterion | None = None, source_level: str = "global") -> CompetitionCriterion:
    fb = fallback or CompetitionCriterion(graph=graph, source_level=source_level)
    pos_rows = [dict(r) for r in (bucket.get("pos", []) if isinstance(bucket.get("pos", []), list) else [])]
    neg_rows = [dict(r) for r in (bucket.get("neg", []) if isinstance(bucket.get("neg", []), list) else [])]
    feature_names = ["abnormal_direct", "normal_clearance", "abnormal_binding", "probability_margin"]
    fallback_weights = {
        "abnormal_direct": fb.weight_abnormal_direct,
        "normal_clearance": fb.weight_normal_clearance,
        "abnormal_binding": fb.weight_abnormal_binding,
        "probability_margin": fb.weight_probability_margin,
    }
    weights = _monotonic_linear_weights(pos_rows, neg_rows, feature_names, fallback_weights)
    pos_scores = _scores_from_rows(pos_rows, weights)
    neg_scores = _scores_from_rows(neg_rows, weights)
    threshold = _balanced_threshold(pos_scores, neg_scores, fb.score_threshold)
    return CompetitionCriterion(
        graph=graph,
        criterion_model=_LINEAR_MODEL_NAME,
        weight_abnormal_direct=float(weights["abnormal_direct"]),
        weight_normal_clearance=float(weights["normal_clearance"]),
        weight_abnormal_binding=float(weights["abnormal_binding"]),
        weight_probability_margin=float(weights["probability_margin"]),
        score_threshold=float(threshold),
        samples_positive=len(pos_rows),
        samples_negative=len(neg_rows),
        source_level=source_level,
    )


def _write_rule(out_repo: Path, kind: str, graph: str, meta: Dict[str, Any], *, statement: str) -> None:
    graph_slug = safe_slug(graph)
    d = out_repo / "criteria" / safe_slug(kind) / graph_slug
    d.mkdir(parents=True, exist_ok=True)
    p = d / "criterion.md"
    lines = ["---", "kind: criterion", f"criterion_kind: {kind}", f"criterion_model: {_LINEAR_MODEL_NAME}", f"graph: {graph}"]
    for k, v in meta.items():
        if k in {"graph", "criterion_model"}:
            continue
        lines.append(f"{k}: {v}")
    lines.append("---\n")
    lines.append("# Criterion\n")
    lines.append(f"**Statement**: {statement}\n")
    p.write_text("\n".join(lines), encoding="utf-8")
