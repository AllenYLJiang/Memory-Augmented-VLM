from __future__ import annotations

import ast
import json
import logging
import os
import random
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

logger = logging.getLogger(__name__)
_JSON_BLOCK_RE = re.compile(r"\{[\s\S]*?\}", re.M)
_CODE_FENCE_RE = re.compile(r"```(?:json|JSON)?\s*([\s\S]*?)```", re.M)
_TRAILING_COMMA_RE = re.compile(r",(?=\s*[}\]])")
_PY_LITERAL_TOKEN_REPLACEMENTS = {
    "true": "True",
    "false": "False",
    "null": "None",
}


def _balanced_json_candidates(text: str) -> list[str]:
    candidates: list[str] = []
    in_str = False
    escape = False
    stack: list[str] = []
    start: int | None = None
    quote_char = '"'
    for i, ch in enumerate(text):
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == quote_char:
                in_str = False
            continue
        if ch in {'"', "'"}:
            in_str = True
            quote_char = ch
            continue
        if ch in "[{":
            if not stack:
                start = i
            stack.append(ch)
            continue
        if ch in "]}":
            if not stack:
                continue
            opener = stack[-1]
            if (opener == "[" and ch == "]") or (opener == "{" and ch == "}"):
                stack.pop()
                if not stack and start is not None:
                    candidates.append(text[start:i + 1])
                    start = None
            else:
                stack.clear()
                start = None
    return candidates


def _jsonish_variants(candidate: str) -> list[str]:
    base = candidate.strip().lstrip("\ufeff")
    variants: list[str] = []
    seen: set[str] = set()

    def add(s: str) -> None:
        s = s.strip()
        if s and s not in seen:
            seen.add(s)
            variants.append(s)

    add(base)
    add(_TRAILING_COMMA_RE.sub("", base))
    add(re.sub(r"^```(?:json|JSON)?\s*|```$", "", base, flags=re.M).strip())

    py_like = _TRAILING_COMMA_RE.sub("", base)
    for k, v in _PY_LITERAL_TOKEN_REPLACEMENTS.items():
        py_like = re.sub(rf"(?<![A-Za-z0-9_\"])\b{k}\b(?![A-Za-z0-9_\"])", v, py_like)
    add(py_like)
    return variants


def _candidate_pool(text: str) -> list[str]:
    pool: list[str] = []
    seen: set[str] = set()

    def add_many(items: Iterable[str]) -> None:
        for item in items:
            s = item.strip()
            if s and s not in seen:
                seen.add(s)
                pool.append(s)

    add_many([text])
    add_many(m.group(1) for m in _CODE_FENCE_RE.finditer(text))
    add_many(_balanced_json_candidates(text))
    add_many(m.group(0) for m in _JSON_BLOCK_RE.finditer(text))
    pool.sort(key=len, reverse=True)
    return pool


def extract_first_json_block(text: str) -> str:
    candidates = _candidate_pool(text)
    if not candidates:
        raise ValueError("No JSON-like object found in model output")
    return candidates[0]


def parse_json_like(text: str) -> Dict[str, Any]:
    pool = _candidate_pool(text)
    errors: list[str] = []
    for candidate in pool:
        for variant in _jsonish_variants(candidate):
            try:
                obj = json.loads(variant)
                if isinstance(obj, dict):
                    return obj
                if isinstance(obj, list) and obj and isinstance(obj[0], dict):
                    return {"items": obj}
            except Exception as e:
                errors.append(f"json:{type(e).__name__}: {e}")
            try:
                obj = ast.literal_eval(variant)
                if isinstance(obj, dict):
                    return obj
                if isinstance(obj, list) and obj and isinstance(obj[0], dict):
                    return {"items": obj}
            except Exception as e:
                errors.append(f"ast:{type(e).__name__}: {e}")
    excerpt = text[:2000]
    raise ValueError(
        "Could not parse model output as JSON. "
        f"Tried {len(pool)} candidate blocks. "
        f"Sample output excerpt:\n{excerpt}\n"
        f"Recent parse errors: {errors[-6:]}"
    )


def _is_retryable_exception(e: BaseException) -> bool:
    msg = str(e).lower()
    retry_tokens = [
        "http", "timeout", "timed out", "temporarily", "unavailable",
        "service unavailable", "bad gateway", "gateway", "connection",
        "connect", "reset", "refused", "remote end closed", "rate limit",
        "too many requests", "429", "500", "502", "503", "504",
    ]
    return any(t in msg for t in retry_tokens)


@dataclass
class DashScopeVLMConfig:
    model: str = "qwen-vl-max"
    vl_high_resolution_images: bool = True
    fps: float = 2.0
    api_key_env: str = "DASHSCOPE_API_KEY"
    max_retries: int = 5
    backoff_base_sec: float = 1.0
    backoff_factor: float = 2.0
    backoff_max_sec: float = 20.0
    jitter_frac: float = 0.2
    json_parse_retries: int = 4


class DashScopeVLM:
    def __init__(self, cfg: DashScopeVLMConfig) -> None:
        self.cfg = cfg
        api_key = os.getenv(cfg.api_key_env)
        if not api_key:
            raise EnvironmentError(f"Missing environment variable {cfg.api_key_env}")
        os.environ[cfg.api_key_env] = api_key

    def _call_messages(self, messages: list[dict[str, Any]], **extra_kwargs: Any) -> str:
        try:
            from dashscope import MultiModalConversation  # type: ignore
        except Exception as e:
            raise ImportError("dashscope is not installed. Please pip install dashscope") from e

        last_err: Optional[BaseException] = None
        for attempt in range(int(self.cfg.max_retries) + 1):
            try:
                resp = MultiModalConversation.call(model=self.cfg.model, messages=messages, **extra_kwargs)
                try:
                    blocks = resp.output.choices[0].message.content
                    parts = []
                    for b in blocks:
                        if isinstance(b, dict) and "text" in b:
                            parts.append(b["text"])
                        else:
                            parts.append(str(b))
                    return "\n".join(parts)
                except Exception:
                    return str(resp)
            except Exception as e:
                last_err = e
                if attempt >= int(self.cfg.max_retries) or not _is_retryable_exception(e):
                    raise
                sleep = min(
                    float(self.cfg.backoff_max_sec),
                    float(self.cfg.backoff_base_sec) * (float(self.cfg.backoff_factor) ** float(attempt)),
                )
                jf = float(self.cfg.jitter_frac)
                if jf > 0:
                    sleep = max(0.0, sleep * (1.0 + random.uniform(-jf, jf)))
                logger.warning("DashScope call failed (%d/%d): %r. Retrying in %.2fs", attempt + 1, int(self.cfg.max_retries) + 1, e, sleep)
                time.sleep(sleep)

        if last_err is not None:
            raise last_err
        raise RuntimeError("DashScope call failed for unknown reasons")

    def call_video(self, *, video_path: Path, prompt: str) -> str:
        video_uri = video_path.resolve().as_uri()
        messages = [{
            "role": "user",
            "content": [
                {"video": video_uri, "fps": self.cfg.fps},
                {"text": prompt},
            ],
        }]
        return self._call_messages(messages)

    def call_image(self, *, image_path: Path, prompt: str) -> str:
        image_uri = image_path.resolve().as_uri()
        messages = [{
            "role": "user",
            "content": [
                {"image": image_uri},
                {"text": prompt},
            ],
        }]
        return self._call_messages(messages, vl_high_resolution_images=bool(self.cfg.vl_high_resolution_images))

    def call_json(self, *, video_path: Path, prompt: str) -> Dict[str, Any]:
        last_err: Optional[BaseException] = None
        last_text: Optional[str] = None
        retries = max(1, int(self.cfg.json_parse_retries))
        for attempt in range(retries):
            try:
                last_text = self.call_video(video_path=video_path, prompt=prompt)
                return parse_json_like(last_text)
            except Exception as e:
                last_err = e
                logger.warning("JSON parse failed for video %s (attempt %d/%d): %s", video_path, attempt + 1, retries, e)
                if attempt >= retries - 1:
                    break
                time.sleep(0.3)
        if last_err is not None:
            if last_text:
                logger.error("Last unparsed video response excerpt for %s:\n%s", video_path, last_text[:2000])
            raise last_err
        raise RuntimeError("DashScope JSON call failed")

    def call_image_json(self, *, image_path: Path, prompt: str) -> Dict[str, Any]:
        last_err: Optional[BaseException] = None
        last_text: Optional[str] = None
        retries = max(1, int(self.cfg.json_parse_retries))
        for attempt in range(retries):
            try:
                last_text = self.call_image(image_path=image_path, prompt=prompt)
                return parse_json_like(last_text)
            except Exception as e:
                last_err = e
                logger.warning("JSON parse failed for image %s (attempt %d/%d): %s", image_path, attempt + 1, retries, e)
                if attempt >= retries - 1:
                    break
                time.sleep(0.3)
        if last_err is not None:
            if last_text:
                logger.error("Last unparsed image response excerpt for %s:\n%s", image_path, last_text[:2000])
            raise last_err
        raise RuntimeError("DashScope image JSON call failed")
