from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import random
import shutil
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List

from . import __version__
from .agent import AgentConfig, StructuralBinaryAgent
from .data.annotations import gt_label, load_annotations
from .data.segments import scan_segments
from .data.video_windows import WindowSegment, build_window_dataset
from .metrics import compute_binary_metrics
from .grounding import sample_video_frames
from .utils.video import _ensure_cv2
from .runtime_meta import assert_run_runtime_compatible
from .criteria import write_criterion_repo_from_predictions
from .ov_client import OpenVikingStore
from .utils.resume import ResumeState, atomic_write_json, compute_run_hash, load_resume_state

_RETRYABLE_HINTS = [
    "http", "timeout", "timed out", "temporarily", "unavailable",
    "service unavailable", "bad gateway", "gateway", "connection",
    "connect", "reset", "refused", "remote end closed", "rate limit",
    "too many requests", "429", "500", "502", "503", "504",
]


def _print_runtime_banner(runtime_metadata: Dict[str, Any]) -> None:
    core = runtime_metadata.get("core_files", {}) if isinstance(runtime_metadata.get("core_files", {}), dict) else {}
    print(f"[runtime] package_version={runtime_metadata.get('package_version')} runtime_signature={runtime_metadata.get('runtime_signature')}")
    print(f"[runtime] package_file={core.get('package', '')}")
    print(f"[runtime] agent_file={core.get('agent', '')}")
    print(f"[runtime] graph_schema_file={core.get('graph_schema', '')}")


def _agent_from_args(args: argparse.Namespace) -> StructuralBinaryAgent:
    return StructuralBinaryAgent(
        AgentConfig(
            model=args.vlm_model,
            fps=float(args.vlm_fps),
            api_key_env=args.api_key_env,
            vl_high_resolution_images=bool(getattr(args, "vl_high_resolution_images", True)),
            cache_dir=args.cache_dir,
            enable_rescue=not bool(getattr(args, "no_rescue", False)),
            rescue_factors=(int(getattr(args, "rescue_first", 3) or 3), int(getattr(args, "rescue_second", 5) or 5)),
            enable_grounding=not bool(getattr(args, "no_grounding", False)),
            grounding_backend=str(getattr(args, "grounding_backend", "clip_gradcam")),
            grounding_model=str(getattr(args, "grounding_model", "openai/clip-vit-base-patch32")),
            grounding_sample_frames=int(getattr(args, "grounding_sample_frames", 6) or 6),
            grounding_phrase_limit_per_node=int(getattr(args, "grounding_phrase_limit_per_node", 6) or 6),
            grounding_device=str(getattr(args, "grounding_device", "auto")),
            enable_criteria=(not bool(getattr(args, "disable_criteria", False))) and bool(str(getattr(args, "criterion_repo", "") or "").strip() or str(getattr(args, "criterion_root_uri", "") or "").strip() or Path(str(getattr(args, "criterion_root_uri_file", "./.ov_criterion_root_uri"))).exists()),
            criterion_repo=str(getattr(args, "criterion_repo", "") or ""),
            criterion_root_uri=str(getattr(args, "criterion_root_uri", "") or ""),
            criterion_root_uri_file=str(getattr(args, "criterion_root_uri_file", "./.ov_criterion_root_uri") or "./.ov_criterion_root_uri"),
            criterion_ov_mode=str(getattr(args, "criterion_ov_mode", "embedded") or "embedded"),
            criterion_ov_data=str(getattr(args, "criterion_ov_data", "./.openviking_criteria_data") or "./.openviking_criteria_data"),
            criterion_ov_url=str(getattr(args, "criterion_ov_url", "") or ""),
            criterion_ov_api_key=str(getattr(args, "criterion_ov_api_key", "") or ""),
        )
    )


def _is_retryable_exception(e: BaseException) -> bool:
    msg = str(e).lower()
    return any(tok in msg for tok in _RETRYABLE_HINTS)


def _retry_sleep_sec(attempt_idx: int) -> float:
    return min(20.0, 1.0 * (2.0 ** max(0, int(attempt_idx) - 1)))


def _maybe_shuffle_in_place(items: List[Any], seed: int | None) -> None:
    if seed is None:
        return
    rnd = random.Random(int(seed))
    rnd.shuffle(items)


def _window_jobs(windows: List[WindowSegment], anno: Dict[str, Any], gt_threshold: float) -> List[Dict[str, Any]]:
    jobs: List[Dict[str, Any]] = []
    for ws in windows:
        y_t, frac = gt_label(ws.start_frame, ws.end_frame, anno.get(ws.video_id, []), threshold=float(gt_threshold))
        jobs.append({
            "segment_key": f"{ws.video_id}__seg{ws.seg_idx}_f{ws.start_frame}-{ws.end_frame}",
            "video_id": ws.video_id,
            "video_path": str(ws.video_path),
            "seg_idx": ws.seg_idx,
            "start_frame": ws.start_frame,
            "end_frame": ws.end_frame,
            "gt_anom_fraction": frac,
            "y_true": y_t,
            "ws": ws,
        })
    return jobs


def _segment_jobs(segs: List[Any], anno: Dict[str, Any], gt_threshold: float) -> List[Dict[str, Any]]:
    jobs: List[Dict[str, Any]] = []
    for seg in segs:
        y_t, frac = gt_label(seg.start_frame, seg.end_frame, anno.get(seg.video_id, []), threshold=float(gt_threshold))
        jobs.append({
            "segment_key": f"{seg.video_id}__seg{seg.seg_idx}_f{seg.start_frame}-{seg.end_frame}",
            "video_id": seg.video_id,
            "segment_path": str(seg.path),
            "start_frame": seg.start_frame,
            "end_frame": seg.end_frame,
            "gt_anom_fraction": frac,
            "y_true": y_t,
            "seg": seg,
        })
    return jobs


def _predict_window_job(agent: StructuralBinaryAgent, job: Dict[str, Any], max_consecutive_errors: int) -> Dict[str, Any]:
    ws: WindowSegment = job["ws"]
    consecutive = 0
    while True:
        try:
            result = agent.predict_window(video_path=ws.video_path, start_frame=ws.start_frame, end_frame=ws.end_frame)
            return {
                "segment_key": job["segment_key"],
                "video_id": job["video_id"],
                "video_path": job["video_path"],
                "seg_idx": job["seg_idx"],
                "start_frame": job["start_frame"],
                "end_frame": job["end_frame"],
                "gt_anom_fraction": job["gt_anom_fraction"],
                "y_true": int(job["y_true"]),
                "binary_decision": result.get("binary_decision"),
                "y_pred": 1 if str(result.get("binary_decision")) == "abnormal" else 0,
                "best_abnormal_graph": result.get("best_abnormal_graph"),
                "best_abnormal_confidence": result.get("best_abnormal_confidence"),
                "best_normal_graph": result.get("best_normal_graph"),
                "best_normal_confidence": result.get("best_normal_confidence"),
                "segment_path": result.get("segment_path"),
                "observations": result.get("observations"),
                "graph_matches": result.get("graph_matches"),
                "grounding": result.get("grounding"),
                "neutral_scene_inference": result.get("neutral_scene_inference"),
                "raw_base_result": result.get("raw_base_result"),
                "base_result": result.get("base_result"),
                "final_result": result.get("final_result"),
                "stage_trace": result.get("stage_trace"),
                "rescue": result.get("rescue"),
                "runtime_metadata": result.get("runtime_metadata"),
                "video_label_codes": result.get("video_label_codes"),
                "allowed_abnormal_graphs": result.get("allowed_abnormal_graphs"),
            }
        except Exception as e:
            if not _is_retryable_exception(e):
                raise
            consecutive += 1
            if consecutive > int(max_consecutive_errors):
                raise RuntimeError(
                    f"segment {job['segment_key']} failed after {consecutive} consecutive retryable errors"
                ) from e
            sleep = _retry_sleep_sec(consecutive)
            print(f"[retry] {job['segment_key']} retryable error ({consecutive}/{max_consecutive_errors}): {e}; sleeping {sleep:.1f}s")
            time.sleep(sleep)


def _predict_segment_job(agent: StructuralBinaryAgent, job: Dict[str, Any], max_consecutive_errors: int) -> Dict[str, Any]:
    seg = job["seg"]
    consecutive = 0
    while True:
        try:
            result = agent.predict_segment(segment_path=seg.path, video_id=seg.video_id)
            return {
                "segment_key": job["segment_key"],
                "video_id": job["video_id"],
                "segment_path": job["segment_path"],
                "start_frame": job["start_frame"],
                "end_frame": job["end_frame"],
                "gt_anom_fraction": job["gt_anom_fraction"],
                "y_true": int(job["y_true"]),
                "binary_decision": result.get("binary_decision"),
                "y_pred": 1 if str(result.get("binary_decision")) == "abnormal" else 0,
                "best_abnormal_graph": result.get("best_abnormal_graph"),
                "best_normal_graph": result.get("best_normal_graph"),
                "observations": result.get("observations"),
                "graph_matches": result.get("graph_matches"),
                "grounding": result.get("grounding"),
                "neutral_scene_inference": result.get("neutral_scene_inference"),
                "raw_base_result": result.get("raw_base_result"),
                "base_result": result.get("base_result"),
                "final_result": result.get("final_result"),
                "stage_trace": result.get("stage_trace"),
                "rescue": result.get("rescue"),
                "runtime_metadata": result.get("runtime_metadata"),
                "video_label_codes": result.get("video_label_codes"),
                "allowed_abnormal_graphs": result.get("allowed_abnormal_graphs"),
            }
        except Exception as e:
            if not _is_retryable_exception(e):
                raise
            consecutive += 1
            if consecutive > int(max_consecutive_errors):
                raise RuntimeError(
                    f"segment {job['segment_key']} failed after {consecutive} consecutive retryable errors"
                ) from e
            sleep = _retry_sleep_sec(consecutive)
            print(f"[retry] {job['segment_key']} retryable error ({consecutive}/{max_consecutive_errors}): {e}; sleeping {sleep:.1f}s")
            time.sleep(sleep)


def _iter_completed_records(
    *,
    jobs: List[Dict[str, Any]],
    worker_fn,
    agent: StructuralBinaryAgent,
    async_workers: int,
    max_consecutive_errors: int,
):
    workers = max(1, int(async_workers))
    if workers <= 1:
        for job in jobs:
            yield worker_fn(agent, job, max_consecutive_errors)
        return

    max_in_flight = max(workers, workers * 2)
    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        future_to_job: Dict[cf.Future[Dict[str, Any]], Dict[str, Any]] = {}
        job_iter = iter(jobs)

        def submit_one() -> bool:
            try:
                job = next(job_iter)
            except StopIteration:
                return False
            fut = ex.submit(worker_fn, agent, job, max_consecutive_errors)
            future_to_job[fut] = job
            return True

        while len(future_to_job) < min(max_in_flight, len(jobs)):
            if not submit_one():
                break

        while future_to_job:
            done, _ = cf.wait(future_to_job.keys(), return_when=cf.FIRST_COMPLETED)
            for fut in done:
                job = future_to_job.pop(fut)
                try:
                    yield fut.result()
                except Exception as e:
                    for pending in future_to_job:
                        pending.cancel()
                    raise RuntimeError(f"job failed for {job.get('segment_key', '<unknown>')}") from e
                finally:
                    while len(future_to_job) < max_in_flight:
                        if not submit_one():
                            break


def _diagnose_error_stage(record: Dict[str, Any]) -> Dict[str, Any]:
    y_true = int(record.get("y_true", 0))
    def dec_to_pred(dec: Any) -> int:
        return 1 if str(dec) == "abnormal" else 0
    raw = ((record.get("raw_base_result") or {}) if isinstance(record.get("raw_base_result"), dict) else {})
    base = ((record.get("base_result") or {}) if isinstance(record.get("base_result"), dict) else {})
    final = ((record.get("final_result") or {}) if isinstance(record.get("final_result"), dict) else {})
    raw_pred = dec_to_pred(raw.get("binary_decision", "uncertain"))
    grounded_pred = dec_to_pred(base.get("binary_decision", "uncertain"))
    final_pred = dec_to_pred(final.get("binary_decision", record.get("binary_decision", "uncertain")))
    suspected = "base_vlm_graph_judgment"
    if raw_pred == y_true and grounded_pred != y_true:
        suspected = "cue_grounding_verification_or_fusion"
    elif grounded_pred == y_true and final_pred != y_true and str((record.get("rescue") or {}).get("final_from", "base")) != "base":
        suspected = "rescue"
    elif raw_pred != y_true:
        suspected = "base_vlm_graph_judgment"
    elif grounded_pred != y_true:
        suspected = "cue_grounding_verification_or_fusion"
    return {
        "suspected_error_stage": suspected,
        "raw_vlm_decision": raw.get("binary_decision"),
        "after_grounding_decision": base.get("binary_decision"),
        "final_decision": final.get("binary_decision", record.get("binary_decision")),
        "best_abnormal_graph_raw": raw.get("best_abnormal_graph"),
        "best_abnormal_graph_after_grounding": base.get("best_abnormal_graph"),
        "best_abnormal_graph_final": final.get("best_abnormal_graph", record.get("best_abnormal_graph")),
        "best_normal_graph_raw": raw.get("best_normal_graph"),
        "best_normal_graph_after_grounding": base.get("best_normal_graph"),
        "best_normal_graph_final": final.get("best_normal_graph", record.get("best_normal_graph")),
        "allowed_abnormal_graphs": record.get("allowed_abnormal_graphs"),
        "video_label_codes": record.get("video_label_codes"),
        "competition_debug": final.get("competition_debug"),
        "rescue_final_from": ((record.get("rescue") or {}) if isinstance(record.get("rescue"), dict) else {}).get("final_from", "base"),
    }


def _dump_frame_strip(segment_path: Path, out_path: Path, sample_frames: int = 6) -> None:
    cv2 = _ensure_cv2()
    frames = sample_video_frames(segment_path, sample_frames)
    if not frames:
        return
    thumbs = []
    target_h = 180
    for idx, frame in frames:
        h, w = frame.shape[:2]
        new_w = max(1, int(round(w * (target_h / max(1, h)))))
        thumb = cv2.resize(frame, (new_w, target_h))
        cv2.putText(thumb, f"f{idx}", (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2, cv2.LINE_AA)
        thumbs.append(thumb)
    strip = thumbs[0]
    for t in thumbs[1:]:
        if t.shape[0] != strip.shape[0]:
            t = cv2.resize(t, (t.shape[1], strip.shape[0]))
        strip = cv2.hconcat([strip, t])
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out_path), strip)


TOP_EVIDENCE_COPY_COUNT = 8


def _copy_top_evidence(record: Dict[str, Any], dst_dir: Path) -> List[str]:
    grounding = (record.get("grounding") or {}) if isinstance(record.get("grounding"), dict) else {}
    node_evidence = grounding.get("node_evidence", []) if isinstance(grounding.get("node_evidence", []), list) else []
    ranked = sorted(
        [ne for ne in node_evidence if isinstance(ne, dict) and str(ne.get("evidence_image_path", ""))],
        key=lambda x: (0 if str(x.get("verification_label", "unverified")) == "yes" else 1, -float(x.get("grounded_score", 0.0) or 0.0)),
    )
    copied = []
    for ne in ranked[:TOP_EVIDENCE_COPY_COUNT]:
        src = Path(str(ne.get("evidence_image_path")))
        if not src.exists():
            continue
        safe_name = f"{ne.get('graph','g')}__{ne.get('node_key','n')}__f{ne.get('best_frame_index',-1)}.jpg"
        dst = dst_dir / _slug_filename(safe_name)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        copied.append(str(dst))
    return copied


def _slug_filename(name: str) -> str:
    import re
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", str(name))
    s = re.sub(r"_+", "_", s).strip("._-")
    return s or "item"


def _dump_error_case(run_dir: Path, record: Dict[str, Any]) -> None:
    y_true = int(record.get("y_true", 0))
    y_pred = int(record.get("y_pred", 0))
    if y_true == y_pred:
        return
    kind = "fp" if (y_true == 0 and y_pred == 1) else "fn"
    seg_key = _slug_filename(str(record.get("segment_key", "segment")))
    case_dir = Path(run_dir) / "error_dumps" / kind / seg_key
    case_dir.mkdir(parents=True, exist_ok=True)
    segment_path = Path(str(record.get("segment_path", ""))) if record.get("segment_path") else None
    if segment_path and segment_path.exists():
        try:
            _dump_frame_strip(segment_path, case_dir / "sampled_frames.jpg", sample_frames=6)
        except Exception as e:
            (case_dir / "sampled_frames_error.txt").write_text(str(e), encoding="utf-8")
    copied = _copy_top_evidence(record, case_dir / "grounding_panels")
    diagnosis = _diagnose_error_stage(record)
    atomic_write_json(case_dir / "stage_diagnosis.json", diagnosis)
    record_to_dump = dict(record)
    record_to_dump["debug_grounding_panels"] = copied
    atomic_write_json(case_dir / "record.json", record_to_dump)



def cmd_predict_segment(args: argparse.Namespace) -> None:
    agent = _agent_from_args(args)
    meta = agent.runtime_metadata()
    _print_runtime_banner(meta)
    result = agent.predict_segment(segment_path=Path(args.video_path), video_id=args.video_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_predict_window(args: argparse.Namespace) -> None:
    agent = _agent_from_args(args)
    meta = agent.runtime_metadata()
    _print_runtime_banner(meta)
    result = agent.predict_window(video_path=Path(args.video_path), start_frame=int(args.start_frame), end_frame=int(args.end_frame))
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_eval_videos(args: argparse.Namespace) -> None:
    agent = _agent_from_args(args)
    runtime_metadata = agent.runtime_metadata()
    _print_runtime_banner(runtime_metadata)
    if getattr(agent, "cfg", None) is not None and getattr(agent.cfg, "enable_grounding", False):
        print("[grounding] prewarming backend")
        agent.grounder._backend()

    anno = load_annotations(Path(args.annotations))
    windows = build_window_dataset(
        videos_root=Path(args.videos_root),
        window=int(args.window),
        stride=int(args.stride),
        videos_glob=str(args.videos_glob),
        max_windows_per_video=int(args.max_windows_per_video or 0),
    )
    _maybe_shuffle_in_place(windows, args.shuffle_seed)
    if args.limit:
        windows = windows[: int(args.limit)]

    cfg = {
        "cmd": "eval-videos",
        "videos_root": str(Path(args.videos_root).resolve()),
        "annotations": str(Path(args.annotations).resolve()),
        "window": int(args.window),
        "stride": int(args.stride),
        "gt_threshold": float(args.gt_threshold),
        "limit": int(args.limit or 0),
        "max_windows_per_video": int(args.max_windows_per_video or 0),
        "vlm_model": str(args.vlm_model),
        "vlm_fps": float(args.vlm_fps),
        "vl_high_resolution_images": bool(getattr(args, "vl_high_resolution_images", True)),
        "vl_high_resolution_images": bool(getattr(args, "vl_high_resolution_images", True)),
        "enable_rescue": not bool(getattr(args, "no_rescue", False)),
        "rescue_factors": [int(getattr(args, "rescue_first", 3) or 3), int(getattr(args, "rescue_second", 5) or 5)],
        "enable_grounding": not bool(getattr(args, "no_grounding", False)),
        "grounding_backend": str(getattr(args, "grounding_backend", "clip_gradcam")),
        "grounding_model": str(getattr(args, "grounding_model", "openai/clip-vit-base-patch32")),
        "grounding_sample_frames": int(getattr(args, "grounding_sample_frames", 6) or 6),
        "grounding_phrase_limit_per_node": int(getattr(args, "grounding_phrase_limit_per_node", 6) or 6),
        "grounding_device": str(getattr(args, "grounding_device", "auto")),
        "criterion_repo": str(getattr(args, "criterion_repo", "") or ""),
        "criterion_root_uri": str(getattr(args, "criterion_root_uri", "") or ""),
        "criterion_root_uri_file": str(getattr(args, "criterion_root_uri_file", "./.ov_criterion_root_uri") or "./.ov_criterion_root_uri"),
        "criterion_ov_mode": str(getattr(args, "criterion_ov_mode", "embedded") or "embedded"),
        "criterion_ov_data": str(getattr(args, "criterion_ov_data", "./.openviking_criteria_data") or "./.openviking_criteria_data"),
        "disable_criteria": bool(getattr(args, "disable_criteria", False)),
        "project_version": __version__,
        "async_workers": int(args.async_workers),
        "max_consecutive_errors": int(args.max_consecutive_errors),
        "shuffle_seed": args.shuffle_seed,
    }
    run_hash = compute_run_hash(cfg)
    out_dir = Path(args.out_dir)
    if args.run_dir:
        run_dir = Path(args.run_dir)
    elif args.fresh_run:
        run_dir = out_dir / time.strftime("%Y%m%d_%H%M%S")
    else:
        run_dir = out_dir / f"eval_{run_hash}"
    run_dir.mkdir(parents=True, exist_ok=True)

    pred_path = run_dir / "predictions.jsonl"
    runtime_path = run_dir / "runtime_metadata.json"
    if not args.fresh_run:
        assert_run_runtime_compatible(run_dir, runtime_metadata)
    atomic_write_json(run_dir / "run_config.json", cfg)
    atomic_write_json(runtime_path, runtime_metadata)

    resume = ResumeState(processed_keys=set(), y_true=[], y_pred=[])
    if (not args.fresh_run) and pred_path.exists():
        resume = load_resume_state(pred_path)
        if resume.truncated_invalid_tail:
            print(f"[resume] Truncated invalid tail in {pred_path}")
        print(f"[resume] Loaded {len(resume.y_true)} existing predictions from {pred_path}")

    jobs = _window_jobs(windows, anno, float(args.gt_threshold))
    jobs = [job for job in jobs if job["segment_key"] not in resume.processed_keys]

    y_true: List[int] = list(resume.y_true)
    y_pred: List[int] = list(resume.y_pred)
    processed = set(resume.processed_keys)
    completed_new = 0
    total_all = len(windows)

    mode = "a" if ((not args.fresh_run) and pred_path.exists()) else "w"
    with pred_path.open(mode, encoding="utf-8") as f:
        for record in _iter_completed_records(
            jobs=jobs,
            worker_fn=_predict_window_job,
            agent=agent,
            async_workers=int(args.async_workers),
            max_consecutive_errors=int(args.max_consecutive_errors),
        ):
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
            f.flush()
            y_true.append(int(record["y_true"]))
            y_pred.append(int(record["y_pred"]))
            processed.add(str(record["segment_key"]))
            if int(record.get("y_true", 0)) != int(record.get("y_pred", 0)):
                _dump_error_case(run_dir, record)
            completed_new += 1
            seen = len(processed)
            if completed_new % max(1, int(args.report_every)) == 0:
                m = compute_binary_metrics(y_true, y_pred)
                print(
                    f"[{seen}/{total_all}] acc={m['accuracy']:.4f} prec={m['precision']:.4f} rec={m['recall']:.4f} "
                    f"tp={m['tp']} fp={m['fp']} tn={m['tn']} fn={m['fn']}"
                )

    metrics = compute_binary_metrics(y_true, y_pred)
    atomic_write_json(run_dir / "summary.json", {"predictions_path": str(pred_path.name), "overall_confusion": metrics})
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    print(f"Saved run to: {run_dir}")


def cmd_eval_segments(args: argparse.Namespace) -> None:
    agent = _agent_from_args(args)
    runtime_metadata = agent.runtime_metadata()
    _print_runtime_banner(runtime_metadata)
    if getattr(agent, "cfg", None) is not None and getattr(agent.cfg, "enable_grounding", False):
        print("[grounding] prewarming backend")
        agent.grounder._backend()
    anno = load_annotations(Path(args.annotations))
    segs = scan_segments(Path(args.segments_root))
    _maybe_shuffle_in_place(segs, args.shuffle_seed)
    if args.limit:
        segs = segs[: int(args.limit)]
    jobs = _segment_jobs(segs, anno, float(args.gt_threshold))
    out_dir = Path(args.out_dir)
    run_dir = out_dir / time.strftime("%Y%m%d_%H%M%S") if args.fresh_run or not args.run_dir else Path(args.run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(run_dir / "runtime_metadata.json", runtime_metadata)
    atomic_write_json(run_dir / "run_config.json", {
        "cmd": "eval-segments",
        "segments_root": str(Path(args.segments_root).resolve()),
        "annotations": str(Path(args.annotations).resolve()),
        "gt_threshold": float(args.gt_threshold),
        "report_every": int(args.report_every),
        "limit": int(args.limit or 0),
        "vlm_model": str(args.vlm_model),
        "vlm_fps": float(args.vlm_fps),
        "enable_rescue": not bool(getattr(args, "no_rescue", False)),
        "rescue_factors": [int(getattr(args, "rescue_first", 3) or 3), int(getattr(args, "rescue_second", 5) or 5)],
        "enable_grounding": not bool(getattr(args, "no_grounding", False)),
        "grounding_backend": str(getattr(args, "grounding_backend", "clip_gradcam")),
        "grounding_model": str(getattr(args, "grounding_model", "openai/clip-vit-base-patch32")),
        "grounding_sample_frames": int(getattr(args, "grounding_sample_frames", 6) or 6),
        "grounding_phrase_limit_per_node": int(getattr(args, "grounding_phrase_limit_per_node", 6) or 6),
        "grounding_device": str(getattr(args, "grounding_device", "auto")),
        "criterion_repo": str(getattr(args, "criterion_repo", "") or ""),
        "criterion_root_uri": str(getattr(args, "criterion_root_uri", "") or ""),
        "criterion_root_uri_file": str(getattr(args, "criterion_root_uri_file", "./.ov_criterion_root_uri") or "./.ov_criterion_root_uri"),
        "criterion_ov_mode": str(getattr(args, "criterion_ov_mode", "embedded") or "embedded"),
        "criterion_ov_data": str(getattr(args, "criterion_ov_data", "./.openviking_criteria_data") or "./.openviking_criteria_data"),
        "disable_criteria": bool(getattr(args, "disable_criteria", False)),
        "project_version": __version__,
        "async_workers": int(args.async_workers),
        "max_consecutive_errors": int(args.max_consecutive_errors),
        "shuffle_seed": args.shuffle_seed,
    })
    pred_path = run_dir / "predictions.jsonl"
    y_true: List[int] = []
    y_pred: List[int] = []
    with pred_path.open("w", encoding="utf-8") as f:
        completed = 0
        total = len(jobs)
        for record in _iter_completed_records(
            jobs=jobs,
            worker_fn=_predict_segment_job,
            agent=agent,
            async_workers=int(args.async_workers),
            max_consecutive_errors=int(args.max_consecutive_errors),
        ):
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
            f.flush()
            y_true.append(int(record["y_true"]))
            y_pred.append(int(record["y_pred"]))
            if int(record.get("y_true", 0)) != int(record.get("y_pred", 0)):
                _dump_error_case(run_dir, record)
            completed += 1
            if completed % max(1, int(args.report_every)) == 0:
                m = compute_binary_metrics(y_true, y_pred)
                print(f"[{completed}/{total}] acc={m['accuracy']:.4f} prec={m['precision']:.4f} rec={m['recall']:.4f}")
    metrics = compute_binary_metrics(y_true, y_pred)
    atomic_write_json(run_dir / "summary.json", {"predictions_path": str(pred_path.name), "overall_confusion": metrics})
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    print(f"Saved run to: {run_dir}")



def cmd_learn_criteria(args: argparse.Namespace) -> None:
    summary = write_criterion_repo_from_predictions(Path(args.predictions), Path(args.out_repo))
    if bool(getattr(args, "index", False)):
        store = OpenVikingStore(mode=str(args.criterion_ov_mode), data_path=str(args.criterion_ov_data), server_url=(str(args.criterion_ov_url) or None), server_api_key=(str(args.criterion_ov_api_key) or None))
        store.initialize()
        try:
            root_uri = store.ingest_context_repo(Path(args.out_repo), target_uri=str(args.target_uri), reason="structural_vlm_binary learned criteria", wait=True)
        finally:
            store.close()
        Path(args.criterion_root_uri_file).write_text(root_uri, encoding="utf-8")
        summary["criterion_root_uri"] = root_uri
        print(f"Indexed learned criteria. root_uri = {root_uri}")
        print(f"Saved root_uri to {args.criterion_root_uri_file}")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="structural-vlm-binary")
    sub = p.add_subparsers(dest="cmd", required=True)

    def add_common(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("--vlm-model", default="qwen-vl-max", choices=["qwen-vl-max", "qwen3.6-plus"], help="DashScope multimodal model to use.")
        sp.add_argument("--vlm-fps", type=float, default=2.0)
        sp.add_argument("--api-key-env", default="DASHSCOPE_API_KEY")
        sp.add_argument("--vl-high-resolution-images", dest="vl_high_resolution_images", action="store_true", default=True, help="Enable DashScope vl_high_resolution_images for image inputs.")
        sp.add_argument("--no-vl-high-resolution-images", dest="vl_high_resolution_images", action="store_false", help="Disable DashScope vl_high_resolution_images for image inputs.")
        sp.add_argument("--cache-dir", default=".cache_segments")
        sp.add_argument("--no-rescue", action="store_true")
        sp.add_argument("--rescue-first", type=int, default=3)
        sp.add_argument("--rescue-second", type=int, default=5)
        sp.add_argument("--no-grounding", action="store_true", help="Disable local cue grounding.")
        sp.add_argument("--grounding-backend", default="clip_gradcam", help="Local cue-grounding backend.")
        sp.add_argument("--grounding-model", default="openai/clip-vit-base-patch32", help="HF model used for cue grounding.")
        sp.add_argument("--grounding-sample-frames", type=int, default=6, help="Number of evenly sampled frames per segment for cue grounding.")
        sp.add_argument("--grounding-phrase-limit-per-node", type=int, default=6, help="Max candidate phrases tested per graph node.")
        sp.add_argument("--grounding-device", default="auto", help="Grounding device: auto/cpu/cuda/mps.")
        sp.add_argument("--criterion-repo", default="", help="Local learned criterion repo")
        sp.add_argument("--criterion-root-uri", default="", help="OpenViking root_uri for learned criteria")
        sp.add_argument("--criterion-root-uri-file", default="./.ov_criterion_root_uri", help="File containing OpenViking criterion root_uri")
        sp.add_argument("--criterion-ov-mode", default="embedded", choices=["embedded", "http"])
        sp.add_argument("--criterion-ov-data", default="./.openviking_criteria_data")
        sp.add_argument("--criterion-ov-url", default="")
        sp.add_argument("--criterion-ov-api-key", default="")
        sp.add_argument("--disable-criteria", action="store_true", help="Disable learned criteria even if configured")

    def add_eval_controls(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("--async-workers", type=int, default=1, help="Number of concurrent segment/window predictions.")
        sp.add_argument(
            "--max-consecutive-errors",
            type=int,
            default=5,
            help="Maximum consecutive retryable errors for a single item before giving up.",
        )
        sp.add_argument(
            "--shuffle-seed",
            type=int,
            default=None,
            help="If set, deterministically shuffle the evaluation order before applying --limit.",
        )

    sp = sub.add_parser("predict-segment")
    add_common(sp)
    sp.add_argument("--video-path", required=True)
    sp.add_argument("--video-id", default=None)
    sp.set_defaults(func=cmd_predict_segment)

    sp = sub.add_parser("predict-window")
    add_common(sp)
    sp.add_argument("--video-path", required=True)
    sp.add_argument("--start-frame", type=int, required=True)
    sp.add_argument("--end-frame", type=int, required=True)
    sp.set_defaults(func=cmd_predict_window)

    sp = sub.add_parser("eval-videos")
    add_common(sp)
    add_eval_controls(sp)
    sp.add_argument("--videos-root", required=True)
    sp.add_argument("--annotations", required=True)
    sp.add_argument("--out-dir", required=True)
    sp.add_argument("--window", type=int, default=96)
    sp.add_argument("--stride", type=int, default=32)
    sp.add_argument("--videos-glob", default="*.mp4")
    sp.add_argument("--max-windows-per-video", type=int, default=0)
    sp.add_argument("--gt-threshold", type=float, default=0.6)
    sp.add_argument("--report-every", type=int, default=10)
    sp.add_argument("--limit", type=int, default=0)
    sp.add_argument("--fresh-run", action="store_true")
    sp.add_argument("--run-dir", default=None)
    sp.set_defaults(func=cmd_eval_videos)

    sp = sub.add_parser("eval-segments")
    add_common(sp)
    add_eval_controls(sp)
    sp.add_argument("--segments-root", required=True)
    sp.add_argument("--annotations", required=True)
    sp.add_argument("--out-dir", required=True)
    sp.add_argument("--gt-threshold", type=float, default=0.6)
    sp.add_argument("--report-every", type=int, default=10)
    sp.add_argument("--limit", type=int, default=0)
    sp.add_argument("--fresh-run", action="store_true")
    sp.add_argument("--run-dir", default=None)
    sp.set_defaults(func=cmd_eval_segments)

    sp = sub.add_parser("learn-criteria")
    sp.add_argument("--predictions", required=True)
    sp.add_argument("--out-repo", required=True)
    sp.add_argument("--index", action="store_true")
    sp.add_argument("--target-uri", default="viking://resources/structural_vlm_binary_criteria/")
    sp.add_argument("--criterion-root-uri-file", default="./.ov_criterion_root_uri")
    sp.add_argument("--criterion-ov-mode", default="embedded", choices=["embedded", "http"])
    sp.add_argument("--criterion-ov-data", default="./.openviking_criteria_data")
    sp.add_argument("--criterion-ov-url", default="")
    sp.add_argument("--criterion-ov-api-key", default="")
    sp.set_defaults(func=cmd_learn_criteria)
    return p


def main(argv: List[str] | None = None) -> None:
    p = build_parser()
    args = p.parse_args(argv)
    args.func(args)
