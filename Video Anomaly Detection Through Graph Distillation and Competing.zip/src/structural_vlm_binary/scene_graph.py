from __future__ import annotations

from typing import Any, Dict, Iterable, List, Tuple

GRAPH_REASONING_STYLE: Dict[str, str] = {
    "localized_discharge_chain": "local_source",
    "source_centered_blast_chain": "local_source",
    "vehicle_collision_chain": "phase_object",
    "reciprocal_conflict_chain": "local_pair",
    "unilateral_control_chain": "local_pair",
    "crowd_escalation_chain": "distributed_crowd",
    "text_card_non_scene": "frame_wide",
    "camera_flash_or_edit": "local_source",
    "sports_or_ceremonial_contact": "local_pair",
    "rescue_or_assist_interaction": "local_pair",
    "vehicle_motion_disturbance": "phase_object",
    "ceremonial_crowd_gathering": "distributed_crowd",
    "stage_effect_or_fireworks": "local_source",
}


def graph_reasoning_style(graph_key: str) -> str:
    return GRAPH_REASONING_STYLE.get(str(graph_key or ""), "generic")


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def _text(v: Any) -> str:
    return str(v or "").strip()


def normalize_scene_graph(neutral: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(neutral or {})
    for key in [
        "local_entities",
        "local_local_relations",
        "local_global_relations",
        "temporal_story",
        "salient_concrete_cues",
        "most_likely_event_fragments",
        "visibility_limits",
        "uncertainties_or_contradictions",
    ]:
        if not isinstance(out.get(key, []), list):
            out[key] = []

    entities = []
    for idx, e in enumerate(out.get("local_entities", []), start=1):
        if not isinstance(e, dict):
            continue
        ee = dict(e)
        ee.setdefault("id", f"L{idx}")
        ee["id"] = _text(ee.get("id")) or f"L{idx}"
        ee["location"] = _text(ee.get("location"))
        ee["what_is_visible"] = _text(ee.get("what_is_visible"))
        ee["role_or_function"] = _text(ee.get("role_or_function"))
        ee["state_or_action"] = _text(ee.get("state_or_action"))
        try:
            ee["confidence"] = _clamp01(float(ee.get("confidence", 0.0) or 0.0))
        except Exception:
            ee["confidence"] = 0.0
        entities.append(ee)
    out["local_entities"] = entities

    def _norm_relation_list(items: Iterable[Any], prefix: str, keys: Tuple[str, ...]) -> List[Dict[str, Any]]:
        rels = []
        for idx, r in enumerate(items, start=1):
            if not isinstance(r, dict):
                continue
            rr = dict(r)
            rr.setdefault("id", f"{prefix}{idx}")
            rr["id"] = _text(rr.get("id")) or f"{prefix}{idx}"
            for k in keys:
                rr[k] = _text(rr.get(k))
            try:
                rr["confidence"] = _clamp01(float(rr.get("confidence", 0.0) or 0.0))
            except Exception:
                rr["confidence"] = 0.0
            rels.append(rr)
        return rels

    out["local_local_relations"] = _norm_relation_list(
        out.get("local_local_relations", []), "R", ("a", "relation", "b", "evidence")
    )
    out["local_global_relations"] = _norm_relation_list(
        out.get("local_global_relations", []), "G", ("local", "relation", "global_context")
    )
    out["temporal_story"] = _norm_relation_list(
        out.get("temporal_story", []), "T", ("phase", "statement")
    )
    return out


def normalize_match_scene_fields(match: Dict[str, Any]) -> Dict[str, Any]:
    mm = dict(match or {})
    for fld in ["scene_anchor_support", "scene_relation_support", "scene_global_support", "binding_consistency"]:
        try:
            mm[fld] = _clamp01(float(mm.get(fld, 0.0) or 0.0))
        except Exception:
            mm[fld] = 0.0
    mm["graph_scope"] = _text(mm.get("graph_scope")) or "unknown"
    be = mm.get("bound_entities", {})
    if not isinstance(be, dict):
        be = {}
    norm_be: Dict[str, List[str]] = {}
    for k, v in be.items():
        kk = _text(k)
        if not kk:
            continue
        if isinstance(v, list):
            vals = [_text(x) for x in v if _text(x)]
        else:
            vals = [_text(v)] if _text(v) else []
        norm_be[kk] = vals
    mm["bound_entities"] = norm_be
    br = mm.get("bound_relations", [])
    if not isinstance(br, list):
        br = []
    mm["bound_relations"] = [_text(x) for x in br if _text(x)]
    sig = mm.get("scene_competition_signature", {})
    if not isinstance(sig, dict):
        sig = {}
    mm["scene_competition_signature"] = {
        "entities": [_text(x) for x in (sig.get("entities", []) if isinstance(sig.get("entities", []), list) else []) if _text(x)],
        "relations": [_text(x) for x in (sig.get("relations", []) if isinstance(sig.get("relations", []), list) else []) if _text(x)],
        "context": _text(sig.get("context")) or mm["graph_scope"],
    }
    return mm


def derive_scene_support(match: Dict[str, Any], scene_graph: Dict[str, Any], graph_key: str) -> Dict[str, Any]:
    mm = normalize_match_scene_fields(match)
    sg = normalize_scene_graph(scene_graph or {})
    style = graph_reasoning_style(graph_key)
    entities = {e["id"]: e for e in sg.get("local_entities", [])}
    ll_rels = {r["id"]: r for r in sg.get("local_local_relations", [])}
    lg_rels = {r["id"]: r for r in sg.get("local_global_relations", [])}
    t_rels = {t["id"]: t for t in sg.get("temporal_story", [])}
    all_rels = {**ll_rels, **lg_rels, **t_rels}

    bound_entity_ids = {x for vals in mm["bound_entities"].values() for x in vals if x in entities}
    bound_rel_ids = {x for x in mm["bound_relations"] if x in all_rels}

    sig = mm["scene_competition_signature"]
    if not sig["entities"]:
        sig["entities"] = sorted(bound_entity_ids)
    if not sig["relations"]:
        sig["relations"] = sorted(bound_rel_ids)
    if not sig["context"] or sig["context"] == "unknown":
        sig["context"] = style

    entity_conf = sum(float(entities[e].get("confidence", 0.0) or 0.0) for e in bound_entity_ids) / max(1, len(bound_entity_ids)) if bound_entity_ids else 0.0
    rel_conf = sum(float(all_rels[r].get("confidence", 0.0) or 0.0) for r in bound_rel_ids) / max(1, len(bound_rel_ids)) if bound_rel_ids else 0.0

    derived_binding = 0.20 * min(1.0, len(bound_entity_ids)) + 0.15 * min(1.0, len(bound_rel_ids)) + 0.35 * entity_conf + 0.30 * rel_conf
    binding = max(mm["binding_consistency"], _clamp01(derived_binding))

    anchor = max(mm["scene_anchor_support"], 0.55 * entity_conf + 0.45 * binding)
    relation = max(mm["scene_relation_support"], 0.55 * rel_conf + 0.25 * binding + 0.20 * (1.0 if bound_rel_ids else 0.0))
    lg_count = sum(1 for r in lg_rels.values() if (r.get("local") in bound_entity_ids or not bound_entity_ids))
    temporal_count = len(bound_rel_ids.intersection(t_rels.keys()))
    global_hint = 0.15 * min(1.0, lg_count) + 0.20 * min(1.0, temporal_count)
    if sg.get("global_context"):
        global_hint += 0.10
    if sg.get("scene_summary"):
        global_hint += 0.05
    global_support = max(mm["scene_global_support"], _clamp01(global_hint))

    if style == "distributed_crowd":
        anchor = max(anchor, 0.60 * relation + 0.20 * global_support)
    elif style == "phase_object":
        relation = max(relation, 0.40 * global_support + 0.20 * binding)
    elif style == "frame_wide":
        global_support = max(global_support, 0.65 * binding)

    return {
        "scene_anchor_support": _clamp01(anchor),
        "scene_relation_support": _clamp01(relation),
        "scene_global_support": _clamp01(global_support),
        "binding_consistency": _clamp01(binding),
        "binding_entities": tuple(sorted(bound_entity_ids or sig["entities"])),
        "binding_relations": tuple(sorted(bound_rel_ids or sig["relations"])),
        "graph_style": style,
        "competition_context": sig.get("context", style) or style,
    }


def binding_overlap(a_entities: Iterable[str], a_relations: Iterable[str], b_entities: Iterable[str], b_relations: Iterable[str]) -> float:
    aset = set(a_entities) | {f"R:{x}" for x in a_relations}
    bset = set(b_entities) | {f"R:{x}" for x in b_relations}
    if not aset or not bset:
        return 0.0
    inter = len(aset & bset)
    union = len(aset | bset)
    return _clamp01(inter / float(max(1, union)))
