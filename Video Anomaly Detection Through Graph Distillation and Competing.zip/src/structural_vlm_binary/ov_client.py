from __future__ import annotations

import threading
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Union


@dataclass(frozen=True)
class OVMatch:
    uri: str
    score: Optional[float] = None
    abstract: Optional[str] = None


def join_uri(base: str, *parts: str) -> str:
    base = str(base or "").rstrip("/")
    clean = [str(p).strip("/") for p in parts if str(p or "").strip("/")]
    return base + "/" + "/".join(clean) if clean else base + "/"


class OpenVikingStore:
    """Thin wrapper around OpenViking.

    This is intentionally small and similar to the v35 implementation the user referenced.
    """

    def __init__(
        self,
        *,
        mode: str = "embedded",
        data_path: str = "./.openviking_data",
        server_url: Optional[str] = None,
        server_api_key: Optional[str] = None,
    ) -> None:
        self.mode = str(mode or "embedded")
        self.data_path = str(data_path)
        self.server_url = server_url
        self.server_api_key = server_api_key
        self._client = None
        self._lock = threading.Lock()

    @property
    def client(self):
        if self._client is None:
            raise RuntimeError("OpenViking client is not initialized. Call initialize().")
        return self._client

    def initialize(self) -> None:
        try:
            import openviking as ov  # type: ignore
        except Exception as e:
            raise ImportError(
                "openviking is not installed. Please run: pip install openviking"
            ) from e

        if self.mode == "embedded":
            self._client = ov.OpenViking(path=self.data_path)
        elif self.mode == "http":
            if not self.server_url:
                raise ValueError("server_url is required for http mode")
            self._client = ov.SyncHTTPClient(url=self.server_url, api_key=self.server_api_key)
        else:
            raise ValueError(f"Unknown OpenViking mode: {self.mode}")
        self._client.initialize()

    def close(self) -> None:
        if self._client is not None:
            try:
                self._client.close()
            finally:
                self._client = None

    def ingest_context_repo(
        self,
        local_path: Union[str, Path],
        *,
        target_uri: str,
        reason: str,
        wait: bool = True,
    ) -> str:
        local_path = str(Path(local_path).resolve())
        with self._lock:
            res = self.client.add_resource(local_path, target=target_uri, reason=reason)
        root_uri = None
        if isinstance(res, dict):
            root_uri = res.get("root_uri") or res.get("result", {}).get("root_uri")
        if not root_uri:
            root_uri = target_uri
        if wait:
            with self._lock:
                self.client.wait_processed()
        return root_uri

    def find(
        self,
        query: str,
        *,
        target_uri: str,
        limit: int = 10,
        score_threshold: Optional[float] = None,
    ) -> List[OVMatch]:
        q = str(query or "").strip() or "criterion threshold"
        with self._lock:
            res = self.client.find(q, target_uri=target_uri, limit=int(limit), score_threshold=score_threshold)
        items = None
        if hasattr(res, "resources"):
            items = getattr(res, "resources")
        elif isinstance(res, dict):
            items = res.get("resources") or res.get("matches") or res.get("items")
        if not items:
            return []
        out: List[OVMatch] = []
        for it in items:
            if isinstance(it, dict):
                uri = it.get("uri") or it.get("path") or ""
                score = it.get("score")
                abstract = it.get("abstract")
            else:
                uri = getattr(it, "uri", "")
                score = getattr(it, "score", None)
                abstract = getattr(it, "abstract", None)
            if uri:
                out.append(OVMatch(uri=uri, score=score, abstract=abstract))
        return out

    def read(self, uri: str) -> str:
        with self._lock:
            return self.client.read(uri)
