from __future__ import annotations

from dataclasses import dataclass, asdict
import math
from typing import Any, Dict, Tuple

from .scene_graph import binding_overlap

STATUS_VALUE = {
    "full_match": 1.00,
    "anchored_partial": 0.72,
    "weak_fragment": 0.18,
    "none": 0.0,
}


@dataclass(frozen=True)
class EvidenceProfile:
    graph: str
    polarity: str
    status: str
    raw_confidence: float
    event_anchor_strength: float = 0.0
    prelude_strength: float = 0.0
    effect_strength: float = 0.0
    confound_anchor_strength: float = 0.0
    contradiction_strength: float = 0.0
    verified_fraction: float = 0.0
    direct_anchor_grounded: float = 0.0
    neutral_consistency: float = 0.5
    event_anchor_inferred: float = 0.0
    confound_anchor_inferred: float = 0.0
    direct_anchor_present: bool = False
    support_presence: float = 0.0
    node_count: int = 0
    scene_anchor_support: float = 0.0
    scene_relation_support: float = 0.0
    scene_global_support: float = 0.0
    binding_consistency: float = 0.0
    graph_style: str = "generic"
    binding_entities: Tuple[str, ...] = ()
    binding_relations: Tuple[str, ...] = ()
    competition_context: str = "generic"

    def to_dict(self) -> Dict[str, Any]:
        out = asdict(self)
        out["binding_entities"] = list(self.binding_entities)
        out["binding_relations"] = list(self.binding_relations)
        return out


@dataclass(frozen=True)
class CalibratedMatch:
    graph: str
    polarity: str
    status: str
    probability: float
    profile: EvidenceProfile
    phase_state: str

    def to_dict(self) -> Dict[str, Any]:
        out = asdict(self)
        out["profile"] = self.profile.to_dict()
        return out


@dataclass(frozen=True)
class GlobalCalibrator:
    abnormal_bias: float = -1.40
    abnormal_direct_w: float = 2.70
    abnormal_relation_w: float = 0.85
    abnormal_binding_w: float = 0.80
    abnormal_support_w: float = 0.28
    abnormal_conf_w: float = 0.18
    abnormal_verify_w: float = 0.12
    abnormal_neutral_w: float = 0.28
    abnormal_contra_w: float = 1.05

    normal_bias: float = -1.35
    normal_direct_w: float = 2.55
    normal_relation_w: float = 0.70
    normal_binding_w: float = 0.72
    normal_support_w: float = 0.22
    normal_conf_w: float = 0.16
    normal_verify_w: float = 0.10
    normal_neutral_w: float = 0.24
    normal_contra_w: float = 0.90

    positive_prob_threshold: float = 0.58
    normal_prob_threshold: float = 0.60
    ambiguous_prob_threshold: float = 0.40
    strong_direct_threshold: float = 0.42
    rescue_seed_direct_threshold: float = 0.14
    very_strong_direct_threshold: float = 0.76
    binding_threshold: float = 0.28
    direct_margin_abnormal: float = 0.05
    direct_margin_normal: float = 0.07
    phase_margin: float = 0.10
    prob_margin: float = 0.04
    overlap_threshold: float = 0.15

    @staticmethod
    def _sigmoid(x: float) -> float:
        return 1.0 / (1.0 + math.exp(-max(-12.0, min(12.0, x))))

    @staticmethod
    def _status_value(status: str) -> float:
        return STATUS_VALUE.get(status, 0.0)

    def _ab_phase_state(self, profile: EvidenceProfile, direct: float) -> str:
        if direct >= self.strong_direct_threshold:
            if profile.effect_strength >= 0.35 and profile.prelude_strength >= 0.35:
                return "event_plus_effect_and_prelude"
            if profile.effect_strength >= 0.35:
                return "event_plus_effect"
            if profile.prelude_strength >= 0.35:
                return "event_plus_prelude"
            return "event_only"
        if profile.effect_strength >= 0.35 and profile.prelude_strength >= 0.35:
            return "phase_mixed_without_event"
        if profile.effect_strength >= 0.35:
            return "effect_only"
        if profile.prelude_strength >= 0.35:
            return "prelude_only"
        return "weak"

    def _nm_phase_state(self, profile: EvidenceProfile, direct: float) -> str:
        if direct >= self.strong_direct_threshold:
            if max(profile.prelude_strength, profile.effect_strength) >= 0.35:
                return "confound_plus_context"
            return "confound_only"
        if max(profile.prelude_strength, profile.effect_strength) >= 0.35:
            return "context_only"
        return "weak"

    def _ab_corroborated(self, profile: EvidenceProfile, direct: float, status_v: float) -> bool:
        if direct >= self.very_strong_direct_threshold:
            return True
        return bool(
            profile.scene_relation_support >= 0.28
            or profile.binding_consistency >= 0.32
            or profile.effect_strength >= 0.28
            or profile.prelude_strength >= 0.28
            or status_v >= 0.72
        )

    def _nm_corroborated(self, profile: EvidenceProfile, direct: float, status_v: float) -> bool:
        if direct >= self.very_strong_direct_threshold:
            return True
        return bool(
            profile.scene_relation_support >= 0.28
            or profile.binding_consistency >= 0.32
            or profile.effect_strength >= 0.28
            or profile.prelude_strength >= 0.28
            or status_v >= 0.72
        )

    def score(self, profile: EvidenceProfile) -> CalibratedMatch:
        status_v = self._status_value(profile.status)
        support = max(profile.prelude_strength, profile.effect_strength)
        if profile.polarity == "abnormal":
            direct = float(profile.event_anchor_strength)
            logit = (
                self.abnormal_bias
                + self.abnormal_direct_w * direct
                + self.abnormal_relation_w * profile.scene_relation_support
                + self.abnormal_binding_w * profile.binding_consistency
                + self.abnormal_support_w * support
                + self.abnormal_conf_w * profile.raw_confidence
                + self.abnormal_verify_w * profile.verified_fraction
                + self.abnormal_neutral_w * (profile.neutral_consistency - 0.5)
                - self.abnormal_contra_w * profile.contradiction_strength
            )
            if profile.graph_style == "distributed_crowd":
                logit += 0.25 * profile.scene_global_support
            if profile.graph_style == "phase_object":
                logit += 0.18 * profile.scene_global_support
            phase_state = self._ab_phase_state(profile, direct)
            if direct < 0.18:
                logit -= 0.85
            if phase_state in {"prelude_only", "effect_only", "phase_mixed_without_event"}:
                logit -= 0.85
            if not self._ab_corroborated(profile, direct, status_v):
                logit -= 0.25
        else:
            direct = float(profile.confound_anchor_strength)
            logit = (
                self.normal_bias
                + self.normal_direct_w * direct
                + self.normal_relation_w * profile.scene_relation_support
                + self.normal_binding_w * profile.binding_consistency
                + self.normal_support_w * support
                + self.normal_conf_w * profile.raw_confidence
                + self.normal_verify_w * profile.verified_fraction
                + self.normal_neutral_w * (profile.neutral_consistency - 0.5)
                - self.normal_contra_w * profile.contradiction_strength
            )
            if profile.graph_style in {"distributed_crowd", "frame_wide"}:
                logit += 0.18 * profile.scene_global_support
            phase_state = self._nm_phase_state(profile, direct)
            if direct < 0.18:
                logit -= 0.75
            if phase_state == "context_only":
                logit -= 0.80
            if not self._nm_corroborated(profile, direct, status_v):
                logit -= 0.20
        return CalibratedMatch(
            graph=profile.graph,
            polarity=profile.polarity,
            status=profile.status,
            probability=self._sigmoid(logit),
            profile=profile,
            phase_state=phase_state,
        )

    def decide(self, best_abnormal: CalibratedMatch | None, best_normal: CalibratedMatch | None) -> Dict[str, Any]:
        ab = best_abnormal
        nm = best_normal
        ab_prob = float(ab.probability) if ab else 0.0
        nm_prob = float(nm.probability) if nm else 0.0
        ab_direct = float(ab.profile.event_anchor_strength) if ab else 0.0
        nm_direct = float(nm.profile.confound_anchor_strength) if nm else 0.0
        ab_support = float(max(ab.profile.prelude_strength, ab.profile.effect_strength)) if ab else 0.0
        nm_support = float(max(nm.profile.prelude_strength, nm.profile.effect_strength)) if nm else 0.0
        ab_status_v = self._status_value(ab.status) if ab else 0.0
        nm_status_v = self._status_value(nm.status) if nm else 0.0
        ab_corroborated = bool(ab and self._ab_corroborated(ab.profile, ab_direct, ab_status_v))
        nm_corroborated = bool(nm and self._nm_corroborated(nm.profile, nm_direct, nm_status_v))

        ab_has_direct = bool(ab and ab_direct >= self.strong_direct_threshold and ab.profile.binding_consistency >= self.binding_threshold)
        nm_has_direct = bool(nm and nm_direct >= self.strong_direct_threshold and nm.profile.binding_consistency >= self.binding_threshold)
        ab_ready = bool(ab_has_direct and ab_prob >= self.positive_prob_threshold and ab_corroborated)
        nm_ready = bool(nm_has_direct and nm_prob >= self.normal_prob_threshold and nm_corroborated)

        ab_phase_secondary = 0.45 * (ab.profile.effect_strength if ab else 0.0) + 0.20 * (ab.profile.prelude_strength if ab else 0.0) + 0.20 * (ab.profile.scene_relation_support if ab else 0.0) + 0.15 * (ab.profile.scene_global_support if ab else 0.0)
        nm_phase_secondary = 0.45 * (nm.profile.effect_strength if nm else 0.0) + 0.20 * (nm.profile.prelude_strength if nm else 0.0) + 0.20 * (nm.profile.scene_relation_support if nm else 0.0) + 0.15 * (nm.profile.scene_global_support if nm else 0.0)

        overlap = binding_overlap(
            ab.profile.binding_entities if ab else (),
            ab.profile.binding_relations if ab else (),
            nm.profile.binding_entities if nm else (),
            nm.profile.binding_relations if nm else (),
        )

        if not ab_has_direct and not nm_has_direct:
            decision = "uncertain"
            rescue_candidate = bool(
                (ab and (ab_support >= 0.35 or ab.profile.scene_relation_support >= 0.35 or ab_prob >= self.ambiguous_prob_threshold))
                or (nm and (nm_support >= 0.35 or nm.profile.scene_relation_support >= 0.35 or nm_prob >= self.ambiguous_prob_threshold))
            )
        elif ab_has_direct and not nm_has_direct:
            if ab_ready or (ab_direct >= self.very_strong_direct_threshold and ab_prob >= self.ambiguous_prob_threshold):
                decision = "abnormal"
                rescue_candidate = False
            else:
                decision = "uncertain"
                rescue_candidate = True
        elif nm_has_direct and not ab_has_direct:
            if nm_ready or (nm_direct >= self.very_strong_direct_threshold and nm_prob >= self.ambiguous_prob_threshold):
                decision = "normal"
                rescue_candidate = False
            else:
                decision = "uncertain"
                rescue_candidate = True
        else:
            if overlap < self.overlap_threshold:
                if ab_ready and not nm_ready:
                    decision = "abnormal"
                    rescue_candidate = False
                elif nm_ready and not ab_ready:
                    decision = "normal"
                    rescue_candidate = False
                else:
                    if ab_prob >= nm_prob + 0.10 and ab_direct >= nm_direct - 0.02:
                        decision = "abnormal"
                        rescue_candidate = False
                    elif nm_prob >= ab_prob + 0.12 and nm_direct >= ab_direct + 0.04:
                        decision = "normal"
                        rescue_candidate = False
                    else:
                        decision = "uncertain"
                        rescue_candidate = True
            else:
                if ab_direct >= nm_direct + self.direct_margin_abnormal and ab_prob >= nm_prob - self.prob_margin:
                    if ab_ready or ab_direct >= self.very_strong_direct_threshold:
                        decision = "abnormal"
                        rescue_candidate = False
                    else:
                        decision = "uncertain"
                        rescue_candidate = True
                elif nm_direct >= ab_direct + self.direct_margin_normal and nm_prob >= ab_prob + self.prob_margin:
                    if nm_ready or nm_direct >= self.very_strong_direct_threshold:
                        decision = "normal"
                        rescue_candidate = False
                    else:
                        decision = "uncertain"
                        rescue_candidate = True
                else:
                    if ab_ready and ab_phase_secondary >= nm_phase_secondary + self.phase_margin and ab.profile.binding_consistency >= nm.profile.binding_consistency - 0.05:
                        decision = "abnormal"
                        rescue_candidate = False
                    elif nm_ready and nm_phase_secondary >= ab_phase_secondary + self.phase_margin and nm.profile.binding_consistency >= ab.profile.binding_consistency - 0.02:
                        decision = "normal"
                        rescue_candidate = False
                    else:
                        decision = "uncertain"
                        rescue_candidate = True

        return {
            "decision": decision,
            "rescue_candidate": rescue_candidate,
            "ab_direct": ab_direct,
            "nm_direct": nm_direct,
            "ab_prob": ab_prob,
            "nm_prob": nm_prob,
            "ab_support": ab_support,
            "nm_support": nm_support,
            "ab_ready": ab_ready,
            "nm_ready": nm_ready,
            "ab_has_direct": ab_has_direct,
            "nm_has_direct": nm_has_direct,
            "ab_corroborated": ab_corroborated,
            "nm_corroborated": nm_corroborated,
            "ab_phase_secondary": ab_phase_secondary,
            "nm_phase_secondary": nm_phase_secondary,
            "ab_phase_state": ab.phase_state if ab else "none",
            "nm_phase_state": nm.phase_state if nm else "none",
            "structure_overlap": overlap,
            "ab_binding_consistency": float(ab.profile.binding_consistency) if ab else 0.0,
            "nm_binding_consistency": float(nm.profile.binding_consistency) if nm else 0.0,
            "ab_graph_style": ab.profile.graph_style if ab else "none",
            "nm_graph_style": nm.profile.graph_style if nm else "none",
        }
