from __future__ import annotations

import hashlib
import importlib
import inspect
import json
from pathlib import Path
from typing import Any, Dict

from . import __version__


def _sha1_text(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8", errors="ignore")).hexdigest()


def _safe_source(mod: Any) -> str:
    try:
        return inspect.getsource(mod)
    except Exception:
        try:
            p = Path(mod.__file__)
            return p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return repr(mod)


def collect_runtime_metadata() -> Dict[str, Any]:
    pkg_mod = importlib.import_module("structural_vlm_binary")
    agent_mod = importlib.import_module("structural_vlm_binary.agent")
    cli_mod = importlib.import_module("structural_vlm_binary.cli")
    graph_mod = importlib.import_module("structural_vlm_binary.graph_schema")
    prompts_mod = importlib.import_module("structural_vlm_binary.prompts")
    grounding_mod = importlib.import_module("structural_vlm_binary.grounding")
    calibration_mod = importlib.import_module("structural_vlm_binary.calibration")
    scene_graph_mod = importlib.import_module("structural_vlm_binary.scene_graph")
    criteria_mod = importlib.import_module("structural_vlm_binary.criteria")
    ov_mod = importlib.import_module("structural_vlm_binary.ov_client")
    video_labels_mod = importlib.import_module("structural_vlm_binary.data.video_labels")

    core = {
        "package": str(Path(pkg_mod.__file__).resolve()),
        "agent": str(Path(agent_mod.__file__).resolve()),
        "cli": str(Path(cli_mod.__file__).resolve()),
        "graph_schema": str(Path(graph_mod.__file__).resolve()),
        "prompts": str(Path(prompts_mod.__file__).resolve()),
        "grounding": str(Path(grounding_mod.__file__).resolve()),
        "calibration": str(Path(calibration_mod.__file__).resolve()),
        "scene_graph": str(Path(scene_graph_mod.__file__).resolve()),
        "criteria": str(Path(criteria_mod.__file__).resolve()),
        "ov_client": str(Path(ov_mod.__file__).resolve()),
        "video_labels": str(Path(video_labels_mod.__file__).resolve()),
    }
    hashes = {
        "agent": _sha1_text(_safe_source(agent_mod)),
        "cli": _sha1_text(_safe_source(cli_mod)),
        "graph_schema": _sha1_text(_safe_source(graph_mod)),
        "prompts": _sha1_text(_safe_source(prompts_mod)),
        "grounding": _sha1_text(_safe_source(grounding_mod)),
        "calibration": _sha1_text(_safe_source(calibration_mod)),
        "scene_graph": _sha1_text(_safe_source(scene_graph_mod)),
        "criteria": _sha1_text(_safe_source(criteria_mod)),
        "ov_client": _sha1_text(_safe_source(ov_mod)),
        "video_labels": _sha1_text(_safe_source(video_labels_mod)),
    }
    signature = _sha1_text(json.dumps(hashes, sort_keys=True))[:16]
    return {
        "package_version": __version__,
        "runtime_signature": signature,
        "core_files": core,
        "core_hashes": hashes,
        "schema_contract": {
            "decision_path": "segment -> unbiased structured scene graph -> cue grounding + scene-graph-conditioned structural_graph_prompt -> scene-graph-grounded competition -> optional OpenViking criterion override -> calibrated binary decision",
            "rescue_path": "uncertain base -> 3x/5x wider clip -> strengthen an already-seeded center-window scene-grounded anchor/binding only (no anchor creation from zero) -> optional OpenViking rescue gate",
        },
    }


def assert_run_runtime_compatible(run_dir: Path, runtime_metadata: Dict[str, Any]) -> None:
    runtime_path = Path(run_dir) / "runtime_metadata.json"
    pred_path = Path(run_dir) / "predictions.jsonl"
    if pred_path.exists() and not runtime_path.exists():
        raise RuntimeError(
            f"Refusing to resume {run_dir}: predictions.jsonl exists but runtime_metadata.json is missing. "
            "Create a fresh run instead."
        )
    if not runtime_path.exists():
        return
    prior = json.loads(runtime_path.read_text(encoding="utf-8"))
    if prior.get("runtime_signature") != runtime_metadata.get("runtime_signature"):
        raise RuntimeError(
            f"Run directory {run_dir} was created by a different runtime signature. "
            "Use --fresh-run or a new --run-dir."
        )
