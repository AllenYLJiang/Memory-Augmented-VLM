__version__ = "v40-11-openviking-score-criteria-high-reso-heatmapfix"
