from __future__ import annotations

import hashlib
import logging
import math
import re
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Sequence

import numpy as np

from .graph_schema import StructuralGraph, all_graphs
from .prompts import build_cue_verification_prompt
from .utils.video import _ensure_cv2

logger = logging.getLogger(__name__)

NodeState = Literal["seen", "probable", "not_visible_or_outside", "contradicted"]
VerificationLabel = Literal["yes", "no", "unverified"]


def _slug(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", str(s))
    s = re.sub(r"_+", "_", s).strip("._-")
    return s or "item"


@dataclass(frozen=True)
class CueGroundingConfig:
    enabled: bool = True
    backend: str = "clip_gradcam"
    model_name: str = "openai/clip-vit-base-patch32"
    sample_frames: int = 6
    phrase_limit_per_node: int = 6
    device: str = "auto"
    seen_threshold: float = 0.60
    probable_threshold: float = 0.46
    contradiction_threshold: float = 0.14
    focus_threshold: float = 0.45
    cache_model: bool = True
    artifact_dir: str = ".cache_grounding_visuals"
    verify_top_graphs_per_polarity: int = 2
    verify_max_nodes: int = 12


@dataclass(frozen=True)
class FrameMatch:
    frame_index: int
    phrase: str
    match_score: float
    heatmap_focus: float
    heatmap_concentration: float
    heatmap_compactness: float
    grounded_score: float
    heatmap: Any | None = None


@dataclass(frozen=True)
class GroundedNodeEvidence:
    graph: str
    graph_polarity: str
    node_key: str
    node_title: str
    state: NodeState
    best_phrase: str
    best_frame_index: int
    match_score: float
    heatmap_focus: float
    heatmap_concentration: float
    heatmap_compactness: float
    proposal_score: float
    grounded_score: float
    verification_label: VerificationLabel
    verification_confidence: float
    verification_reason: str
    anchor: bool
    required: bool
    time_role: str
    spatial_role: str
    evidence_image_path: str = ""


@dataclass(frozen=True)
class GraphGroundingSummary:
    graph: str
    polarity: str
    anchor_seen_or_probable: int
    anchor_total: int
    support_seen_or_probable: int
    support_total: int
    graph_grounded_score: float
    strongest_node_key: str
    strongest_phrase: str
    strongest_frame_index: int
    strongest_node_score: float
    verified_node_count: int = 0


@dataclass(frozen=True)
class GroundingResult:
    enabled: bool
    backend: str
    model_name: str
    sampled_frame_indices: Sequence[int]
    node_evidence: Sequence[GroundedNodeEvidence]
    graph_summaries: Sequence[GraphGroundingSummary]
    top_abnormal_graph: str
    top_abnormal_score: float
    top_normal_graph: str
    top_normal_score: float
    note: str = ""

    def to_prompt_text(self) -> str:
        if not self.enabled:
            return "GROUNDING DISABLED."
        lines: List[str] = []
        if self.note:
            lines.append(f"grounding note: {self.note}")
        lines.append(
            f"grounding backend={self.backend} model={self.model_name} sampled_frames={list(self.sampled_frame_indices)}"
        )
        lines.append(
            "Use the verified cue evidence below as the PRIMARY signal for whether a cue node is visually present. "
            "Each verified node was proposed by image-text heatmap grounding and then checked by the VLM on the highlighted region itself. "
            "Only use free-form reasoning for visibility, truncation, spatial binding, and temporal relation between grounded cues."
        )
        by_graph: Dict[str, List[GroundedNodeEvidence]] = {}
        for ev in self.node_evidence:
            by_graph.setdefault(ev.graph, []).append(ev)
        for gs in self.graph_summaries:
            lines.append(
                f"GRAPH {gs.graph} polarity={gs.polarity} grounded_score={gs.graph_grounded_score:.3f} "
                f"anchors={gs.anchor_seen_or_probable}/{gs.anchor_total} supports={gs.support_seen_or_probable}/{gs.support_total} "
                f"verified_nodes={gs.verified_node_count}"
            )
            for ev in sorted(by_graph.get(gs.graph, []), key=lambda x: (-x.grounded_score, x.node_key)):
                verify_txt = f"verify={ev.verification_label}:{ev.verification_confidence:.2f}" if ev.verification_label != "unverified" else "verify=proposal_only"
                lines.append(
                    f"- node={ev.node_key} state={ev.state} anchor={str(ev.anchor).lower()} frame={ev.best_frame_index} "
                    f"best_phrase=\"{ev.best_phrase}\" proposal={ev.proposal_score:.3f} {verify_txt} grounded={ev.grounded_score:.3f} "
                    f"focus={ev.heatmap_focus:.3f} concentration={ev.heatmap_concentration:.3f} compactness={ev.heatmap_compactness:.3f}"
                )
                if ev.verification_reason:
                    lines.append(f"  reason: {ev.verification_reason}")
        lines.append(
            "A verified YES is strong local evidence. A verified NO means the highlighted region did not match the cue phrase; treat it as not confirmed, not as proof that the whole event is impossible."
        )
        return "\n".join(lines)


def sample_video_frames(video_path: Path, sample_frames: int) -> List[tuple[int, Any]]:
    cv2 = _ensure_cv2()
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Unable to open video for grounding: {video_path}")
    try:
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        if frame_count <= 0:
            frames = []
            idx = 0
            while True:
                ok, frame = cap.read()
                if not ok or frame is None:
                    break
                frames.append((idx, frame))
                idx += 1
            if not frames:
                raise RuntimeError(f"No frames read from {video_path}")
            if len(frames) <= sample_frames:
                return frames
            sel = np.linspace(0, len(frames) - 1, num=sample_frames, dtype=int).tolist()
            return [frames[i] for i in sel]
        sample_frames = max(1, int(sample_frames))
        picks = sorted({int(x) for x in np.linspace(0, max(0, frame_count - 1), num=sample_frames, dtype=int).tolist()})
        out: List[tuple[int, Any]] = []
        for idx in picks:
            cap.set(cv2.CAP_PROP_POS_FRAMES, float(idx))
            ok, frame = cap.read()
            if ok and frame is not None:
                out.append((idx, frame))
        if not out:
            raise RuntimeError(f"No sampled frames could be read from {video_path}")
        return out
    finally:
        cap.release()


def _normalize_map(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    if x.size == 0 or not np.isfinite(x).any():
        return np.zeros((1, 1), dtype=np.float32)
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    lo = float(np.percentile(x, 1.0))
    hi = float(np.percentile(x, 99.0))
    if hi <= lo + 1e-8:
        lo = float(x.min())
        hi = float(x.max())
    if hi <= lo + 1e-8:
        return np.zeros_like(x, dtype=np.float32)
    x = np.clip(x, lo, hi)
    x = (x - lo) / max(1e-6, hi - lo)
    return x.astype(np.float32)


def _choose_hidden_state(hidden_states: Sequence[Any], layer_index: int) -> Any:
    if not hidden_states:
        raise RuntimeError('The CLIP vision model did not return hidden states')
    n = len(hidden_states)
    idx = layer_index if layer_index >= 0 else n + layer_index
    idx = max(0, min(n - 1, idx))
    return hidden_states[idx]


def _patch_grid_from_model(model: Any, pixel_values: Any, num_patch_tokens: int) -> tuple[int, int]:
    h = int(pixel_values.shape[-2])
    w = int(pixel_values.shape[-1])
    patch_size = int(getattr(model.vision_model.config, 'patch_size', 32))
    gh = max(1, h // max(1, patch_size))
    gw = max(1, w // max(1, patch_size))
    if gh * gw == num_patch_tokens:
        return gh, gw
    g = int(round(math.sqrt(max(1, num_patch_tokens))))
    if g * g == num_patch_tokens:
        return g, g
    g = int(math.floor(math.sqrt(max(1, num_patch_tokens))))
    return max(1, g), max(1, num_patch_tokens // max(1, g))


class _ClipGradCAMBackend:
    def __init__(self, model_name: str, device: str) -> None:
        try:
            import torch
            import torch.nn.functional as F
            from PIL import Image
            from transformers import AutoProcessor, CLIPModel
        except ImportError as e:
            raise RuntimeError(
                f"Grounding import failed in {__file__}: {e}. Install: pip install transformers torch pillow"
            ) from e
        self.torch = torch
        self.F = F
        self.Image = Image
        if device == "auto":
            if torch.cuda.is_available():
                device = "cuda"
            elif getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
                device = "mps"
            else:
                device = "cpu"
        self.device = torch.device(device)
        self.model_name = model_name
        self.processor = AutoProcessor.from_pretrained(model_name)
        self.model = CLIPModel.from_pretrained(model_name)
        self.model.eval().to(self.device)
        self._score_lock = threading.Lock()

    def _frame_to_pil(self, frame_bgr: Any):
        frame_rgb = frame_bgr[..., ::-1]
        return self.Image.fromarray(frame_rgb)

    def score_phrase(self, frame_bgr: Any, phrase: str) -> FrameMatch:
        torch = self.torch
        F = self.F
        with self._score_lock:
            image = self._frame_to_pil(frame_bgr)
            inputs = self.processor(text=[phrase], images=image, return_tensors="pt", padding=True)
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            for v in inputs.values():
                if hasattr(v, "requires_grad") and v.dtype.is_floating_point:
                    v.requires_grad_(False)
            self.model.zero_grad(set_to_none=True)
            outputs = self.model(**inputs, output_hidden_states=True, return_dict=True)
            score = outputs.logits_per_image[0, 0]
            vision_out = getattr(outputs, "vision_model_output", None)
            if vision_out is None or getattr(vision_out, 'hidden_states', None) is None:
                raise RuntimeError("CLIP outputs do not expose vision hidden states; cannot build heatmap")

            hidden = _choose_hidden_state(vision_out.hidden_states, -2)
            hidden.retain_grad()
            score.backward(retain_graph=False)

            grads = hidden.grad
            acts = hidden.detach()
            patch_acts = acts[:, 1:, :]
            if grads is not None:
                patch_grads = grads[:, 1:, :]
                raw = (patch_grads * patch_acts).sum(dim=-1)
                sal = raw.abs()[0]
            else:
                sal = patch_acts.norm(dim=-1)[0]

            sal_np = sal.detach().float().cpu().numpy()
            if not np.isfinite(sal_np).any() or np.allclose(sal_np, 0.0):
                sal_np = patch_acts.norm(dim=-1)[0].detach().float().cpu().numpy()

            num_patch_tokens = int(sal_np.shape[0])
            gh, gw = _patch_grid_from_model(self.model, inputs["pixel_values"], num_patch_tokens)
            use_n = gh * gw
            sal_np = sal_np[:use_n]
            heat = _normalize_map(sal_np.reshape(gh, gw))

            mass = heat.astype(np.float64)
            total = float(mass.sum())
            if total <= 0.0:
                focus = concentration = compactness = 0.0
            else:
                mass = mass / total
                eps = 1e-12
                focus = float(heat.max())
                entropy = float(-(mass * np.log(mass + eps)).sum() / math.log(mass.size + eps))
                concentration = max(0.0, 1.0 - entropy)
                thr = float(np.quantile(heat, 0.90)) if heat.size > 0 else 1.0
                thr = max(thr, 0.35)
                hot = heat >= thr
                if hot.any():
                    ys, xs = np.where(hot)
                    area = float((ys.max() - ys.min() + 1) * (xs.max() - xs.min() + 1))
                    fill = float(hot.mean())
                    compactness = max(0.0, min(1.0, fill / max(area / float(heat.size), 1e-6)))
                else:
                    compactness = 0.0

            img = outputs.image_embeds
            txt = outputs.text_embeds
            if img is not None and txt is not None:
                cos = float(F.cosine_similarity(img, txt).detach().cpu().item())
                match = max(0.0, min(1.0, 0.5 * (cos + 1.0)))
            else:
                match = float(torch.sigmoid(score / 10.0).detach().cpu().item())

            grounded = float(0.62 * match + 0.18 * focus + 0.12 * concentration + 0.08 * compactness)
            return FrameMatch(
                frame_index=-1,
                phrase=phrase,
                match_score=max(0.0, min(1.0, match)),
                heatmap_focus=max(0.0, min(1.0, focus)),
                heatmap_concentration=max(0.0, min(1.0, concentration)),
                heatmap_compactness=max(0.0, min(1.0, compactness)),
                grounded_score=max(0.0, min(1.0, grounded)),
                heatmap=heat,
            )


def _proposal_graph_score(evs: List[Dict[str, Any]]) -> float:
    anchors = [e for e in evs if bool(e["node"].anchor)]
    supports = [e for e in evs if not bool(e["node"].anchor)]
    anchor_score = float(sum(float(e["best"].grounded_score) for e in anchors) / max(1, len(anchors)))
    support_score = float(sum(float(e["best"].grounded_score) for e in supports) / max(1, len(supports))) if supports else 0.0
    return float(max(0.0, min(1.0, 0.70 * anchor_score + 0.30 * support_score)))


def _upsample_heatmap(heat: np.ndarray, out_h: int, out_w: int) -> np.ndarray:
    cv2 = _ensure_cv2()
    up = cv2.resize(heat.astype(np.float32), (int(out_w), int(out_h)), interpolation=cv2.INTER_CUBIC)
    up = np.clip(up, 0.0, 1.0)
    return up


def _hot_bbox(heat_up: np.ndarray) -> tuple[int, int, int, int]:
    h, w = heat_up.shape[:2]
    thr = max(float(np.quantile(heat_up, 0.90)) if heat_up.size > 0 else 1.0, 0.35)
    mask = heat_up >= thr
    if not bool(mask.any()):
        bw = max(8, int(w * 0.30))
        bh = max(8, int(h * 0.30))
        x0 = max(0, (w - bw) // 2)
        y0 = max(0, (h - bh) // 2)
        return x0, y0, min(w, x0 + bw), min(h, y0 + bh)
    ys, xs = np.where(mask)
    x0, x1 = int(xs.min()), int(xs.max())
    y0, y1 = int(ys.min()), int(ys.max())
    pad_x = max(4, int(0.15 * max(1, x1 - x0 + 1)))
    pad_y = max(4, int(0.15 * max(1, y1 - y0 + 1)))
    return max(0, x0 - pad_x), max(0, y0 - pad_y), min(w, x1 + pad_x + 1), min(h, y1 + pad_y + 1)


def _overlay_heat(frame_bgr: Any, heat_up: np.ndarray) -> Any:
    cv2 = _ensure_cv2()
    hm = np.clip((heat_up * 255.0).astype(np.uint8), 0, 255)
    colored = cv2.applyColorMap(hm, cv2.COLORMAP_JET)
    out = cv2.addWeighted(frame_bgr, 0.55, colored, 0.45, 0.0)
    return out


def _draw_candidate_panel(frame_bgr: Any, heat_small: np.ndarray, out_path: Path) -> Path:
    cv2 = _ensure_cv2()
    h, w = frame_bgr.shape[:2]
    heat_up = _upsample_heatmap(heat_small, h, w)
    x0, y0, x1, y1 = _hot_bbox(heat_up)
    orig = frame_bgr.copy()
    overlay = _overlay_heat(frame_bgr, heat_up)
    cv2.rectangle(orig, (x0, y0), (max(x0 + 1, x1 - 1), max(y0 + 1, y1 - 1)), (0, 0, 255), 2)
    cv2.rectangle(overlay, (x0, y0), (max(x0 + 1, x1 - 1), max(y0 + 1, y1 - 1)), (0, 0, 255), 2)
    crop_orig = orig[y0:y1, x0:x1].copy()
    crop_overlay = overlay[y0:y1, x0:x1].copy()
    if crop_orig.size == 0 or crop_overlay.size == 0:
        crop_orig = cv2.resize(orig, (w, h))
        crop_overlay = cv2.resize(overlay, (w, h))
    top = np.concatenate([orig, overlay], axis=1)
    crop_h = max(crop_orig.shape[0], crop_overlay.shape[0])
    crop_w = max(crop_orig.shape[1], crop_overlay.shape[1])
    crop_orig = cv2.resize(crop_orig, (crop_w, crop_h))
    crop_overlay = cv2.resize(crop_overlay, (crop_w, crop_h))
    bottom = np.concatenate([crop_orig, crop_overlay], axis=1)
    panel_w = max(top.shape[1], bottom.shape[1])
    if top.shape[1] != panel_w:
        top = cv2.copyMakeBorder(top, 0, 0, 0, panel_w - top.shape[1], cv2.BORDER_CONSTANT, value=(255, 255, 255))
    if bottom.shape[1] != panel_w:
        bottom = cv2.copyMakeBorder(bottom, 0, 0, 0, panel_w - bottom.shape[1], cv2.BORDER_CONSTANT, value=(255, 255, 255))
    panel = np.concatenate([top, bottom], axis=0)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    ok = cv2.imwrite(str(out_path), panel)
    if not ok:
        raise RuntimeError(f"Failed to write grounding panel to {out_path}")
    return out_path


class CueGrounder:
    def __init__(self, cfg: CueGroundingConfig) -> None:
        self.cfg = cfg
        self._backend_obj: Any | None = None
        self._backend_init_lock = threading.Lock()
        self._verify_lock = threading.Lock()

    def _backend(self):
        if self._backend_obj is not None and self.cfg.cache_model:
            return self._backend_obj
        with self._backend_init_lock:
            if self._backend_obj is not None and self.cfg.cache_model:
                return self._backend_obj
            backend_name = self.cfg.backend.lower().strip()
            if backend_name != "clip_gradcam":
                raise ValueError(f"Unsupported grounding backend: {self.cfg.backend}")
            obj = _ClipGradCAMBackend(self.cfg.model_name, self.cfg.device)
            if self.cfg.cache_model:
                self._backend_obj = obj
            return obj

    def _select_nodes_for_verification(self, provisional: List[Dict[str, Any]]) -> set[tuple[str, str]]:
        by_graph: Dict[str, List[Dict[str, Any]]] = {}
        for item in provisional:
            by_graph.setdefault(item["graph"].key, []).append(item)
        abnormal = []
        normal = []
        for gkey, items in by_graph.items():
            score = _proposal_graph_score(items)
            polarity = items[0]["graph"].polarity
            if polarity == "abnormal":
                abnormal.append((score, gkey, items))
            else:
                normal.append((score, gkey, items))
        abnormal.sort(key=lambda x: (-x[0], x[1]))
        normal.sort(key=lambda x: (-x[0], x[1]))
        chosen_graphs = abnormal[: max(1, int(self.cfg.verify_top_graphs_per_polarity))] + normal[: max(1, int(self.cfg.verify_top_graphs_per_polarity))]
        candidates: List[tuple[int, float, str, str]] = []
        for _, _, items in chosen_graphs:
            supports = sorted([it for it in items if not bool(it["node"].anchor)], key=lambda x: (-float(x["best"].grounded_score), x["node"].key))
            for it in items:
                rank = 0 if bool(it["node"].anchor) else 1
                candidates.append((rank, -float(it["best"].grounded_score), it["graph"].key, it["node"].key))
            for it in supports[:2]:
                candidates.append((1, -float(it["best"].grounded_score), it["graph"].key, it["node"].key))
        dedup: List[tuple[int, float, str, str]] = []
        seen: set[tuple[str, str]] = set()
        for c in sorted(candidates):
            key = (c[2], c[3])
            if key in seen:
                continue
            seen.add(key)
            dedup.append(c)
        limit = max(1, int(self.cfg.verify_max_nodes))
        return {(g, n) for _, _, g, n in dedup[:limit]}

    def _artifact_root(self, segment_path: Path) -> Path:
        sid = hashlib.sha1(str(Path(segment_path).resolve()).encode("utf-8", errors="ignore")).hexdigest()[:16]
        return Path(self.cfg.artifact_dir) / f"{_slug(segment_path.stem)}_{sid}"

    def _verify_candidate_with_vlm(
        self,
        *,
        vlm: Any,
        panel_path: Path,
        graph: StructuralGraph,
        node: Any,
        phrase: str,
    ) -> tuple[VerificationLabel, float, str]:
        prompt = build_cue_verification_prompt(
            graph_key=graph.key,
            graph_title=graph.title,
            node_key=node.key,
            node_title=node.title,
            phrase=phrase,
        )
        with self._verify_lock:
            obj = vlm.call_image_json(image_path=panel_path, prompt=prompt)
        label = str(obj.get("match", "no") or "no").strip().lower()
        if label not in {"yes", "no"}:
            label = "no"
        conf = float(obj.get("confidence", 0.0) or 0.0)
        conf = max(0.0, min(1.0, conf))
        reason = str(obj.get("reason", "") or "")
        return label, conf, reason

    def ground_segment(self, segment_path: Path, graphs: Sequence[StructuralGraph] | None = None, vlm: Any | None = None) -> GroundingResult:
        if not self.cfg.enabled:
            return GroundingResult(False, self.cfg.backend, self.cfg.model_name, [], [], [], "NONE", 0.0, "NONE", 0.0, "disabled")
        try:
            frames = sample_video_frames(Path(segment_path), self.cfg.sample_frames)
            frame_map = {idx: frame for idx, frame in frames}
            backend = self._backend()
            graphs = list(graphs or all_graphs())
            provisional: List[Dict[str, Any]] = []
            for g in graphs:
                for node in g.nodes:
                    phrases = list(node.cue_bundle)[: max(1, int(self.cfg.phrase_limit_per_node))]
                    best: FrameMatch | None = None
                    best_idx = 0
                    for frame_index, frame in frames:
                        for phrase in phrases:
                            fm = backend.score_phrase(frame, phrase)
                            fm = FrameMatch(
                                frame_index=frame_index,
                                phrase=phrase,
                                match_score=fm.match_score,
                                heatmap_focus=fm.heatmap_focus,
                                heatmap_concentration=fm.heatmap_concentration,
                                heatmap_compactness=fm.heatmap_compactness,
                                grounded_score=fm.grounded_score,
                                heatmap=fm.heatmap,
                            )
                            if best is None or fm.grounded_score > best.grounded_score:
                                best = fm
                                best_idx = frame_index
                    assert best is not None
                    provisional.append({"graph": g, "node": node, "best": best, "frame_index": best_idx})

            verify_keys = self._select_nodes_for_verification(provisional)
            artifact_root = self._artifact_root(Path(segment_path))
            verified: Dict[tuple[str, str], Dict[str, Any]] = {}
            verification_errors: List[str] = []
            if vlm is not None:
                for item in provisional:
                    g = item["graph"]
                    node = item["node"]
                    if (g.key, node.key) not in verify_keys:
                        continue
                    best: FrameMatch = item["best"]
                    frame = frame_map.get(int(best.frame_index))
                    if frame is None or best.heatmap is None:
                        continue
                    panel_path = artifact_root / f"{_slug(g.key)}__{_slug(node.key)}__f{int(best.frame_index)}.jpg"
                    try:
                        _draw_candidate_panel(frame, np.asarray(best.heatmap, dtype=np.float32), panel_path)
                        vlabel, vconf, vreason = self._verify_candidate_with_vlm(
                            vlm=vlm,
                            panel_path=panel_path,
                            graph=g,
                            node=node,
                            phrase=best.phrase,
                        )
                        verified[(g.key, node.key)] = {
                            "label": vlabel,
                            "confidence": vconf,
                            "reason": vreason,
                            "panel_path": str(panel_path),
                        }
                    except Exception as e:
                        verification_errors.append(f"{g.key}.{node.key}: {type(e).__name__}: {e}")
                        logger.warning("Cue verification failed for %s.%s on %s: %s", g.key, node.key, segment_path, e)

            node_evidence: List[GroundedNodeEvidence] = []
            by_graph: Dict[str, List[GroundedNodeEvidence]] = {}
            for item in provisional:
                g = item["graph"]
                node = item["node"]
                best: FrameMatch = item["best"]
                ver = verified.get((g.key, node.key))
                if ver is not None:
                    label = str(ver.get("label", "unverified"))
                    conf = float(ver.get("confidence", 0.0) or 0.0)
                    reason = str(ver.get("reason", "") or "")
                    panel_path = str(ver.get("panel_path", "") or "")
                    if label == "yes":
                        state: NodeState = "seen" if conf >= 0.60 else "probable"
                        eff = max(float(best.grounded_score), 0.58 + 0.35 * conf)
                    else:
                        state = "not_visible_or_outside"
                        eff = 0.10 * float(best.grounded_score)
                    verification_label: VerificationLabel = label if label in {"yes", "no"} else "unverified"
                else:
                    verification_label = "unverified"
                    conf = 0.0
                    reason = ""
                    panel_path = ""
                    if best.grounded_score >= self.cfg.seen_threshold and best.heatmap_focus >= self.cfg.focus_threshold:
                        state = "probable"
                        eff = min(float(best.grounded_score), 0.58)
                    elif best.grounded_score >= self.cfg.probable_threshold:
                        state = "probable"
                        eff = min(float(best.grounded_score), 0.48)
                    else:
                        state = "not_visible_or_outside"
                        eff = 0.10 * float(best.grounded_score)
                ev = GroundedNodeEvidence(
                    graph=g.key,
                    graph_polarity=g.polarity,
                    node_key=node.key,
                    node_title=node.title,
                    state=state,
                    best_phrase=best.phrase,
                    best_frame_index=int(best.frame_index),
                    match_score=float(best.match_score),
                    heatmap_focus=float(best.heatmap_focus),
                    heatmap_concentration=float(best.heatmap_concentration),
                    heatmap_compactness=float(best.heatmap_compactness),
                    proposal_score=float(best.grounded_score),
                    grounded_score=max(0.0, min(1.0, float(eff))),
                    verification_label=verification_label,
                    verification_confidence=float(conf),
                    verification_reason=reason,
                    anchor=bool(node.anchor),
                    required=bool(node.required),
                    time_role=str(node.time_role),
                    spatial_role=str(node.spatial_role),
                    evidence_image_path=panel_path,
                )
                node_evidence.append(ev)
                by_graph.setdefault(g.key, []).append(ev)

            graph_summaries: List[GraphGroundingSummary] = []
            top_ab_g = "NONE"
            top_ab_s = 0.0
            top_nm_g = "NONE"
            top_nm_s = 0.0
            for g in graphs:
                evs = by_graph.get(g.key, [])
                if not evs:
                    continue
                anchors = [e for e in evs if e.anchor]
                supports = [e for e in evs if not e.anchor]
                anchor_seen = sum(1 for e in anchors if e.state in {"seen", "probable"})
                support_seen = sum(1 for e in supports if e.state in {"seen", "probable"})
                anchor_score = sum(e.grounded_score for e in anchors) / max(1, len(anchors))
                support_score = sum(e.grounded_score for e in supports) / max(1, len(supports)) if supports else 0.0
                graph_score = float(max(0.0, min(1.0, 0.72 * anchor_score + 0.28 * support_score)))
                strongest = max(evs, key=lambda x: x.grounded_score)
                gs = GraphGroundingSummary(
                    graph=g.key,
                    polarity=g.polarity,
                    anchor_seen_or_probable=anchor_seen,
                    anchor_total=len(anchors),
                    support_seen_or_probable=support_seen,
                    support_total=len(supports),
                    graph_grounded_score=graph_score,
                    strongest_node_key=strongest.node_key,
                    strongest_phrase=strongest.best_phrase,
                    strongest_frame_index=strongest.best_frame_index,
                    strongest_node_score=strongest.grounded_score,
                    verified_node_count=sum(1 for e in evs if e.verification_label != "unverified"),
                )
                graph_summaries.append(gs)
                if g.polarity == "abnormal" and gs.graph_grounded_score > top_ab_s:
                    top_ab_s, top_ab_g = gs.graph_grounded_score, gs.graph
                if g.polarity == "normal" and gs.graph_grounded_score > top_nm_s:
                    top_nm_s, top_nm_g = gs.graph_grounded_score, gs.graph
            graph_summaries.sort(key=lambda x: (0 if x.polarity == "abnormal" else 1, -x.graph_grounded_score, x.graph))
            note = (
                "Cue presence comes from phrase-level CLIP heatmap proposals plus VLM verification on the highlighted region itself; "
                "unverified proposal-only nodes are capped at probable."
            )
            if verification_errors:
                note += f" Some node verifications failed: {len(verification_errors)}"
            return GroundingResult(
                enabled=True,
                backend=self.cfg.backend,
                model_name=self.cfg.model_name,
                sampled_frame_indices=[idx for idx, _ in frames],
                node_evidence=node_evidence,
                graph_summaries=graph_summaries,
                top_abnormal_graph=top_ab_g,
                top_abnormal_score=top_ab_s,
                top_normal_graph=top_nm_g,
                top_normal_score=top_nm_s,
                note=note,
            )
        except Exception as e:
            logger.exception("Cue grounding disabled for %s", segment_path)
            return GroundingResult(
                enabled=False,
                backend=self.cfg.backend,
                model_name=self.cfg.model_name,
                sampled_frame_indices=[],
                node_evidence=[],
                graph_summaries=[],
                top_abnormal_graph="NONE",
                top_abnormal_score=0.0,
                top_normal_graph="NONE",
                top_normal_score=0.0,
                note=f"grounding unavailable: {e}",
            )
