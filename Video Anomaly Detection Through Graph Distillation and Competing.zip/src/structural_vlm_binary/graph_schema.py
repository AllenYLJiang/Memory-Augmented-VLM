from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Literal, Sequence


Polarity = Literal["abnormal", "normal"]
RelationType = Literal["cooccur", "precedes", "causes", "supports"]
EvidenceClass = Literal["event_anchor", "prelude", "effect", "confound_anchor"]


@dataclass(frozen=True)
class GraphNode:
    key: str
    title: str
    cue_bundle: Sequence[str]
    anchor: bool = False
    required: bool = True
    time_role: str = "same"
    spatial_role: str = "linked"
    visibility_note: str = "If this cue is outside the crop or outside the 96-frame span, mark it as not_visible_or_outside, not absent."


@dataclass(frozen=True)
class GraphEdge:
    src: str
    dst: str
    relation: RelationType
    required: bool = True
    note: str = ""


@dataclass(frozen=True)
class StructuralGraph:
    key: str
    title: str
    polarity: Polarity
    summary: str
    nodes: Sequence[GraphNode]
    edges: Sequence[GraphEdge]
    normal_competitors: Sequence[str]
    partial_support_sets: Sequence[Sequence[str]]
    full_support_sets: Sequence[Sequence[str]]
    decision_note: str = ""

    def required_nodes(self) -> List[GraphNode]:
        return [n for n in self.nodes if n.required]

    def required_edges(self) -> List[GraphEdge]:
        return [e for e in self.edges if e.required]

    def anchor_nodes(self) -> List[GraphNode]:
        return [n for n in self.nodes if n.anchor]


ABNORMAL_GRAPHS: List[StructuralGraph] = [
    StructuralGraph(
        key="localized_discharge_chain",
        title="Localized discharge / emission chain",
        polarity="abnormal",
        summary=(
            "One localized source produces a gunshot-like or discharge-like flash/smoke, and the same moment is tied to "
            "either aiming context or an immediate target / crowd reaction."
        ),
        nodes=[
            GraphNode(
                key="point_flash_or_smoke",
                title="point flash or point smoke at one source",
                cue_bundle=[
                    "tiny bright flash at hand level or barrel tip",
                    "brief white-yellow puff of smoke from a held object",
                    "single-point spark or flash from one actor, not the whole screen",
                    "short flash from one source with a clear local origin",
                ],
                anchor=True,
                required=True,
                time_role="onset",
                spatial_role="same source",
                visibility_note="This may be only 1-2 frames. If the flash is partly missed because of frame sampling, use probable rather than absent.",
            ),
            GraphNode(
                key="aim_or_held_object",
                title="aiming posture or held object",
                cue_bundle=[
                    "arm extended toward a target",
                    "small object or long object aligned like a weapon",
                    "person clearly pointing or aiming before / during the flash",
                ],
                anchor=False,
                required=False,
                time_role="before_or_same",
                spatial_role="same actor",
            ),
            GraphNode(
                key="instant_reaction_or_impact",
                title="instant reaction or impact consequence",
                cue_bundle=[
                    "hand / arm / object snaps backward right after the flash",
                    "person nearby flinches, ducks, jerks, falls, or recoils immediately",
                    "small localized impact near the line of fire",
                    "nearby crowd instantly reacts at the same moment",
                ],
                anchor=False,
                required=False,
                time_role="immediate_after",
                spatial_role="same source or nearby target",
            ),
        ],
        edges=[
            GraphEdge("point_flash_or_smoke", "aim_or_held_object", "supports", False, "optional object/aiming context"),
            GraphEdge("point_flash_or_smoke", "instant_reaction_or_impact", "precedes", False, "flash followed by immediate consequence"),
        ],
        normal_competitors=["camera_flash_or_edit", "stage_effect_or_fireworks"],
        partial_support_sets=[("aim_or_held_object",), ("instant_reaction_or_impact",)],
        full_support_sets=[("aim_or_held_object", "instant_reaction_or_impact")],
        decision_note="Do not require all nodes inside 96 frames. A strong local flash plus either aiming context or immediate reaction is already meaningful; missing the other node is often a visibility/truncation issue.",
    ),
    StructuralGraph(
        key="source_centered_blast_chain",
        title="Source-centered blast chain",
        polarity="abnormal",
        summary="A bright source-centered onset rapidly grows outward into a larger bloom, ejecta, smoke front, or blast aftermath.",
        nodes=[
            GraphNode(
                key="source_bloom",
                title="source-centered bright bloom",
                cue_bundle=[
                    "bright bloom begins at one origin point",
                    "sudden fireball-like or ignition-like bright source",
                    "one source becomes much brighter than surrounding scene in a single moment",
                ],
                anchor=True,
                required=True,
                time_role="onset",
                spatial_role="single source",
            ),
            GraphNode(
                key="outward_expansion_or_ejecta",
                title="outward expansion or ejecta",
                cue_bundle=[
                    "bright region expands outward from the same source",
                    "radial smoke, dust, debris, or blast front grows outward",
                    "expansion larger than a tiny muzzle-like flash",
                ],
                anchor=False,
                required=True,
                time_role="immediate_after",
                spatial_role="same source",
            ),
            GraphNode(
                key="smoke_or_damage_aftermath",
                title="smoke or damage aftermath",
                cue_bundle=[
                    "lingering smoke or dust cloud remains after the burst",
                    "damaged ground, fragments, fire, or broken environment after the blast",
                ],
                anchor=False,
                required=False,
                time_role="after",
                spatial_role="same area",
            ),
        ],
        edges=[
            GraphEdge("source_bloom", "outward_expansion_or_ejecta", "causes", True, "onset grows outward from same origin"),
            GraphEdge("outward_expansion_or_ejecta", "smoke_or_damage_aftermath", "precedes", False, "optional aftermath"),
        ],
        normal_competitors=["camera_flash_or_edit", "stage_effect_or_fireworks"],
        partial_support_sets=[("outward_expansion_or_ejecta",)],
        full_support_sets=[("outward_expansion_or_ejecta", "smoke_or_damage_aftermath")],
        decision_note="If you see the source bloom and the outward expansion but aftermath is outside the segment, mark aftermath as not_visible_or_outside, not absent.",
    ),
    StructuralGraph(
        key="vehicle_collision_chain",
        title="Vehicle collision chain",
        polarity="abnormal",
        summary="A visible vehicle or traffic object shows a hard trajectory break or direct impact, and this is supported by debris, deformation, stop, or crash aftermath.",
        nodes=[
            GraphNode(
                key="vehicle_or_traffic_object",
                title="vehicle or traffic object visible",
                cue_bundle=[
                    "car, bus, truck, motorcycle, bicycle, or clear traffic scene visible",
                    "moving road vehicle or large traffic object is in frame",
                ],
                anchor=True,
                required=True,
                time_role="before_or_same",
                spatial_role="same object",
            ),
            GraphNode(
                key="impact_or_trajectory_break",
                title="impact or hard trajectory break",
                cue_bundle=[
                    "vehicle suddenly jerks, swerves, rotates, or stops unnaturally",
                    "vehicle visibly hits another object or another object hits it",
                    "hard crash-like motion discontinuity, not smooth driving",
                ],
                anchor=True,
                required=True,
                time_role="onset",
                spatial_role="same vehicle or collision pair",
            ),
            GraphNode(
                key="collision_aftermath",
                title="collision aftermath",
                cue_bundle=[
                    "vehicle remains stopped in damaged pose",
                    "visible debris, broken parts, crumpling, smoke, or overturned aftermath",
                    "people/objects scatter from the impact zone after contact",
                ],
                anchor=False,
                required=False,
                time_role="after",
                spatial_role="same collision area",
            ),
        ],
        edges=[
            GraphEdge("vehicle_or_traffic_object", "impact_or_trajectory_break", "supports", True, "impact is grounded by vehicle presence"),
            GraphEdge("impact_or_trajectory_break", "collision_aftermath", "precedes", False, "optional aftermath"),
        ],
        normal_competitors=["vehicle_motion_disturbance", "camera_flash_or_edit"],
        partial_support_sets=[("impact_or_trajectory_break",)],
        full_support_sets=[("impact_or_trajectory_break", "collision_aftermath")],
        decision_note="If the crash aftermath is out of frame or slightly later, the chain can still be strong when vehicle presence and hard impact / trajectory break are clearly visible.",
    ),
    StructuralGraph(
        key="reciprocal_conflict_chain",
        title="Reciprocal conflict chain",
        polarity="abnormal",
        summary="Two or more people engage in forceful contact and the other side visibly resists, strikes back, or grapples back.",
        nodes=[
            GraphNode(
                key="forceful_interpersonal_contact",
                title="forceful interpersonal contact",
                cue_bundle=[
                    "clear punch, kick, shove, strike, tackle, or hard grapple",
                    "one person forcefully hits or pushes another person",
                ],
                anchor=True,
                required=True,
                time_role="same_or_onset",
                spatial_role="same pair",
            ),
            GraphNode(
                key="return_action_or_resistance",
                title="return action or resistance",
                cue_bundle=[
                    "other person strikes back, grapples back, or actively resists",
                    "mutual exchange rather than carrying, supporting, or calm contact",
                ],
                anchor=True,
                required=True,
                time_role="same_or_after",
                spatial_role="same pair",
            ),
            GraphNode(
                key="imbalance_or_fall",
                title="imbalance or fall caused by the clash",
                cue_bundle=[
                    "one person stumbles, falls, is thrown, or loses balance because of the clash",
                    "body recoils or collapses immediately around the exchange",
                ],
                anchor=False,
                required=False,
                time_role="after",
                spatial_role="same pair",
            ),
        ],
        edges=[
            GraphEdge("forceful_interpersonal_contact", "return_action_or_resistance", "cooccur", True, "two-way conflict"),
            GraphEdge("forceful_interpersonal_contact", "imbalance_or_fall", "causes", False, "optional consequence"),
        ],
        normal_competitors=["sports_or_ceremonial_contact", "rescue_or_assist_interaction"],
        partial_support_sets=[("return_action_or_resistance",)],
        full_support_sets=[("return_action_or_resistance", "imbalance_or_fall")],
        decision_note="Reciprocity is the key anchor. Do not demand a complete fall if the segment only shows the exchange itself.",
    ),
    StructuralGraph(
        key="unilateral_control_chain",
        title="Unilateral control / blocked escape chain",
        polarity="abnormal",
        summary="One actor forcefully controls another, and the victim shows distress, defensive posture, or blocked movement rather than mutual fighting.",
        nodes=[
            GraphNode(
                key="one_sided_control",
                title="one-sided control or restraint",
                cue_bundle=[
                    "one person pins, drags, grabs, holds down, or forcibly restrains another",
                    "interaction looks one-sided rather than mutual exchange",
                ],
                anchor=True,
                required=True,
                time_role="same_or_before",
                spatial_role="same pair",
            ),
            GraphNode(
                key="victim_distress_or_defense",
                title="victim distress or defensive posture",
                cue_bundle=[
                    "victim cowers, shields face, pulls away, curls up, or looks frightened",
                    "clear avoidance, distress, or defensive reaction",
                ],
                anchor=True,
                required=True,
                time_role="same_or_after",
                spatial_role="same pair",
            ),
            GraphNode(
                key="blocked_escape_or_confinement",
                title="blocked escape or confinement",
                cue_bundle=[
                    "victim tries to move away but path is blocked",
                    "held against wall, floor, seat, corner, or otherwise unable to leave",
                ],
                anchor=False,
                required=False,
                time_role="same_or_after",
                spatial_role="same pair",
            ),
        ],
        edges=[
            GraphEdge("one_sided_control", "victim_distress_or_defense", "supports", True, "control aligns with victim fear/defense"),
            GraphEdge("one_sided_control", "blocked_escape_or_confinement", "causes", False, "optional blocked escape"),
        ],
        normal_competitors=["rescue_or_assist_interaction", "sports_or_ceremonial_contact"],
        partial_support_sets=[("victim_distress_or_defense",)],
        full_support_sets=[("victim_distress_or_defense", "blocked_escape_or_confinement")],
        decision_note="For short windows, one-sided control plus clear distress can already be strong. Blocked escape may be partially outside the crop or seen only with wider context.",
    ),
    StructuralGraph(
        key="crowd_escalation_chain",
        title="Crowd escalation chain",
        polarity="abnormal",
        summary="A dense crowd shows opposing or panicked motion that escalates into disorder, chase, throwing, or visibly chaotic scatter.",
        nodes=[
            GraphNode(
                key="opposing_crowd_motion",
                title="opposing or aggressive crowd motion",
                cue_bundle=[
                    "many people push against each other, chase, rush, or surge in opposite directions",
                    "crowd movement looks hostile, panicked, or conflict-driven rather than orderly",
                ],
                anchor=True,
                required=True,
                time_role="same_or_before",
                spatial_role="crowd",
            ),
            GraphNode(
                key="visible_disorder_or_scatter",
                title="visible disorder or panicked scatter",
                cue_bundle=[
                    "people scatter, run, duck, or break formation suddenly",
                    "objects thrown, barriers struck, or crowd becomes visibly chaotic",
                ],
                anchor=True,
                required=True,
                time_role="same_or_after",
                spatial_role="same crowd scene",
            ),
            GraphNode(
                key="damage_or_debris",
                title="damage or debris aftermath",
                cue_bundle=[
                    "broken objects, debris, overturned items, or disturbed scene after escalation",
                ],
                anchor=False,
                required=False,
                time_role="after",
                spatial_role="same area",
            ),
        ],
        edges=[
            GraphEdge("opposing_crowd_motion", "visible_disorder_or_scatter", "causes", True, "opposition escalates into visible disorder"),
            GraphEdge("visible_disorder_or_scatter", "damage_or_debris", "precedes", False, "optional aftermath"),
        ],
        normal_competitors=["ceremonial_crowd_gathering", "sports_or_ceremonial_contact"],
        partial_support_sets=[("visible_disorder_or_scatter",)],
        full_support_sets=[("visible_disorder_or_scatter", "damage_or_debris")],
        decision_note="Require antagonistic or panicked structure, not just 'many people moving'. Damage is helpful but often not visible in a short segment.",
    ),
]


NORMAL_GRAPHS: List[StructuralGraph] = [
    StructuralGraph(
        key="text_card_non_scene",
        title="Text card / non-scene",
        polarity="normal",
        summary="The frame is mostly text, logo, subtitle card, credits, scoreboard, or edited graphic rather than a real scene.",
        nodes=[
            GraphNode(
                key="frame_dominated_by_text_or_graphic",
                title="frame dominated by text or graphics",
                cue_bundle=[
                    "large centered title or credits",
                    "subtitles or graphic panels covering much of the frame",
                    "scoreboard, logo, poster, or non-scene graphic dominates what is visible",
                ],
                anchor=True,
                required=True,
                time_role="same",
                spatial_role="frame-wide",
            )
        ],
        edges=[],
        normal_competitors=[],
        partial_support_sets=[()],
        full_support_sets=[()],
        decision_note="This confound wins when the actual scene is too obscured to ground any event chain.",
    ),
    StructuralGraph(
        key="camera_flash_or_edit",
        title="Camera flash / edit confound",
        polarity="normal",
        summary="A bright change is better explained by editing, exposure shift, camera flash, or global lighting flicker than by a local event source.",
        nodes=[
            GraphNode(
                key="frame_wide_or_source_unclear_flash",
                title="frame-wide or source-unclear flash",
                cue_bundle=[
                    "whole frame brightens at once",
                    "flash has no clear local origin point",
                    "brightness change resembles edit transition or exposure change",
                ],
                anchor=True,
                required=True,
                time_role="onset",
                spatial_role="frame-wide or source-unclear",
            ),
            GraphNode(
                key="no_local_consequence",
                title="no local consequence",
                cue_bundle=[
                    "no local smoke, impact, recoil, or human reaction tied to a source",
                    "after the flash, the scene continues without an event chain",
                ],
                anchor=False,
                required=True,
                time_role="after",
                spatial_role="same scene",
            ),
        ],
        edges=[GraphEdge("frame_wide_or_source_unclear_flash", "no_local_consequence", "precedes", True)],
        normal_competitors=[],
        partial_support_sets=[("no_local_consequence",)],
        full_support_sets=[("no_local_consequence",)],
        decision_note="Use this only when the flash is global or source-unclear. A local point flash with local consequences should not be absorbed into this confound.",
    ),
    StructuralGraph(
        key="sports_or_ceremonial_contact",
        title="Sports / ceremonial contact",
        polarity="normal",
        summary="People make contact, but the context is sports, training, ceremony, rehearsal, or staged performance rather than harmful conflict.",
        nodes=[
            GraphNode(
                key="contact_present",
                title="contact present",
                cue_bundle=[
                    "people grapple, strike, or collide bodily",
                ],
                anchor=True,
                required=True,
            ),
            GraphNode(
                key="structured_nonviolent_context",
                title="structured nonviolent context",
                cue_bundle=[
                    "ring, court, mat, uniforms, gloves, referee, coach, practice hall, staged performance",
                    "organized sports or ceremonial setting",
                ],
                anchor=False,
                required=True,
            ),
        ],
        edges=[GraphEdge("contact_present", "structured_nonviolent_context", "supports", True)],
        normal_competitors=[],
        partial_support_sets=[("structured_nonviolent_context",)],
        full_support_sets=[("structured_nonviolent_context",)],
        decision_note="Do not use this confound from vague background hints alone; there should be visible organized context.",
    ),
    StructuralGraph(
        key="rescue_or_assist_interaction",
        title="Rescue / assist interaction",
        polarity="normal",
        summary="One-sided contact is better explained by helping, lifting, carrying, stabilizing, evacuating, or guiding someone.",
        nodes=[
            GraphNode(
                key="one_sided_contact",
                title="one-sided contact",
                cue_bundle=["one person holds, lifts, drags, or supports another"],
                anchor=True,
                required=True,
            ),
            GraphNode(
                key="assistive_direction",
                title="assistive direction",
                cue_bundle=[
                    "movement looks like helping up, carrying to safety, steadying, or escorting",
                    "interaction lacks visible victim fear, active resistance, or blocked escape",
                ],
                anchor=False,
                required=True,
            ),
        ],
        edges=[GraphEdge("one_sided_contact", "assistive_direction", "supports", True)],
        normal_competitors=[],
        partial_support_sets=[("assistive_direction",)],
        full_support_sets=[("assistive_direction",)],
        decision_note="Use this confound only when the direction of motion looks supportive rather than coercive.",
    ),
    StructuralGraph(
        key="vehicle_motion_disturbance",
        title="Vehicle motion disturbance without collision",
        polarity="normal",
        summary="A vehicle scene shows camera shake, rough motion, or a hard turn, but there is no grounded collision chain.",
        nodes=[
            GraphNode(
                key="vehicle_scene",
                title="vehicle scene",
                cue_bundle=["vehicle or traffic scene visible"],
                anchor=True,
                required=True,
            ),
            GraphNode(
                key="motion_disturbance_only",
                title="motion disturbance only",
                cue_bundle=[
                    "camera shake, road bump, fast driving, or hard turn without visible hit",
                    "no debris, deformation, stopped crash pose, or collision pair",
                ],
                anchor=False,
                required=True,
            ),
        ],
        edges=[GraphEdge("vehicle_scene", "motion_disturbance_only", "supports", True)],
        normal_competitors=[],
        partial_support_sets=[("motion_disturbance_only",)],
        full_support_sets=[("motion_disturbance_only",)],
        decision_note="This confound exists to stop generic jolts from becoming crash chains.",
    ),
    StructuralGraph(
        key="ceremonial_crowd_gathering",
        title="Ceremonial / calm crowd gathering",
        polarity="normal",
        summary="A crowd is present, but motion is organized, same-direction, or spectator-like rather than antagonistic escalation.",
        nodes=[
            GraphNode(
                key="crowd_presence",
                title="crowd present",
                cue_bundle=["dense crowd or many people visible"],
                anchor=True,
                required=True,
            ),
            GraphNode(
                key="organized_or_calm_pattern",
                title="organized or calm pattern",
                cue_bundle=[
                    "spectators watching, marching in order, waving flags, standing in rows, or calmly gathering",
                    "crowd moves mostly together rather than opposing or scattering",
                ],
                anchor=False,
                required=True,
            ),
        ],
        edges=[GraphEdge("crowd_presence", "organized_or_calm_pattern", "supports", True)],
        normal_competitors=[],
        partial_support_sets=[("organized_or_calm_pattern",)],
        full_support_sets=[("organized_or_calm_pattern",)],
        decision_note="Do not call a calm crowd 'riot' just because there are many people and motion.",
    ),
    StructuralGraph(
        key="stage_effect_or_fireworks",
        title="Stage effect / fireworks confound",
        polarity="normal",
        summary="Bright energetic effects are better explained by fireworks, stage pyrotechnics, celebratory effects, or show lighting.",
        nodes=[
            GraphNode(
                key="show_like_bright_effect",
                title="show-like bright effect",
                cue_bundle=[
                    "bright streak, spark shower, fireworks burst, or stage pyrotechnic-like emission",
                    "light effect appears celebratory or decorative rather than destructive",
                ],
                anchor=True,
                required=True,
            ),
            GraphNode(
                key="celebration_or_stage_context",
                title="celebration or stage context",
                cue_bundle=[
                    "audience, stage, concert, festival, night sky fireworks, or show setting",
                ],
                anchor=False,
                required=True,
            ),
        ],
        edges=[GraphEdge("show_like_bright_effect", "celebration_or_stage_context", "supports", True)],
        normal_competitors=[],
        partial_support_sets=[("celebration_or_stage_context",)],
        full_support_sets=[("celebration_or_stage_context",)],
        decision_note="Use this when the bright effect is decorative/show-like, not when it is source-centered damage or panic causing.",
    ),
]



GRAPH_NODE_EVIDENCE_CLASS: dict[str, dict[str, EvidenceClass]] = {
    "localized_discharge_chain": {
        "point_flash_or_smoke": "event_anchor",
        "aim_or_held_object": "prelude",
        "instant_reaction_or_impact": "effect",
    },
    "source_centered_blast_chain": {
        "source_bloom": "event_anchor",
        "outward_expansion_or_ejecta": "effect",
        "smoke_or_damage_aftermath": "effect",
    },
    "vehicle_collision_chain": {
        "vehicle_or_traffic_object": "prelude",
        "impact_or_trajectory_break": "event_anchor",
        "collision_aftermath": "effect",
    },
    "reciprocal_conflict_chain": {
        "forceful_interpersonal_contact": "event_anchor",
        "return_action_or_resistance": "event_anchor",
        "imbalance_or_fall": "effect",
    },
    "unilateral_control_chain": {
        "one_sided_control": "event_anchor",
        "victim_distress_or_defense": "effect",
        "blocked_escape_or_confinement": "event_anchor",
    },
    "crowd_escalation_chain": {
        "opposing_crowd_motion": "event_anchor",
        "visible_disorder_or_scatter": "effect",
        "damage_or_debris": "effect",
    },
    "text_card_non_scene": {
        "frame_dominated_by_text_or_graphic": "confound_anchor",
    },
    "camera_flash_or_edit": {
        "frame_wide_or_source_unclear_flash": "confound_anchor",
        "no_local_consequence": "effect",
    },
    "sports_or_ceremonial_contact": {
        "contact_present": "prelude",
        "structured_nonviolent_context": "confound_anchor",
    },
    "rescue_or_assist_interaction": {
        "one_sided_contact": "prelude",
        "assistive_direction": "confound_anchor",
    },
    "vehicle_motion_disturbance": {
        "vehicle_scene": "prelude",
        "motion_disturbance_only": "confound_anchor",
    },
    "ceremonial_crowd_gathering": {
        "crowd_presence": "prelude",
        "organized_or_calm_pattern": "confound_anchor",
    },
    "stage_effect_or_fireworks": {
        "show_like_bright_effect": "prelude",
        "celebration_or_stage_context": "confound_anchor",
    },
}


def graph_lookup() -> dict[str, StructuralGraph]:
    return {g.key: g for g in all_graphs()}


def node_evidence_class(graph_key: str, node_key: str, default: EvidenceClass = "prelude") -> EvidenceClass:
    return GRAPH_NODE_EVIDENCE_CLASS.get(str(graph_key), {}).get(str(node_key), default)


def graph_direct_anchor_class(polarity: str) -> EvidenceClass:
    return "event_anchor" if str(polarity) == "abnormal" else "confound_anchor"


def all_graphs() -> List[StructuralGraph]:
    return [*ABNORMAL_GRAPHS, *NORMAL_GRAPHS]


def render_graphs_for_prompt(graphs: Iterable[StructuralGraph]) -> str:
    parts: List[str] = []
    for g in graphs:
        parts.append(f"GRAPH {g.key} | polarity={g.polarity}")
        parts.append(f"summary: {g.summary}")
        if g.decision_note:
            parts.append(f"decision note: {g.decision_note}")
        parts.append("nodes:")
        for n in g.nodes:
            cues = "; ".join(n.cue_bundle)
            req = "required" if n.required else "optional"
            anc = "anchor" if n.anchor else "support"
            parts.append(
                f"- {n.key} [{req}, {anc}, evidence_class={node_evidence_class(g.key, n.key)}] time={n.time_role} space={n.spatial_role}: {n.title}; concrete visual cues: {cues}; visibility: {n.visibility_note}"
            )
        if g.edges:
            parts.append("edges:")
            for e in g.edges:
                req = "required" if e.required else "optional"
                note = f"; note: {e.note}" if e.note else ""
                parts.append(f"- {e.src} --{e.relation}/{req}--> {e.dst}{note}")
        else:
            parts.append("edges: none")
        if g.partial_support_sets:
            parts.append("anchored partial patterns:")
            for ss in g.partial_support_sets:
                if ss:
                    parts.append("- anchors + " + " + ".join(ss))
                else:
                    parts.append("- anchors alone")
        if g.full_support_sets:
            parts.append("full patterns:")
            for ss in g.full_support_sets:
                if ss:
                    parts.append("- anchors + " + " + ".join(ss))
                else:
                    parts.append("- anchors alone")
        if g.normal_competitors:
            parts.append("normal competitors: " + ", ".join(g.normal_competitors))
        parts.append("")
    return "\n".join(parts).strip()
