from __future__ import annotations

import json
from typing import Any, Dict, Sequence

from .graph_schema import ABNORMAL_GRAPHS, NORMAL_GRAPHS, render_graphs_for_prompt
from .scene_graph import graph_reasoning_style

LOW_LEVEL_OBSERVABLES = [
    "tiny local flash at one source",
    "global frame-wide brightening",
    "small local smoke puff",
    "large smoke cloud growth",
    "debris / fragments / broken pieces",
    "forceful person-to-person contact",
    "mutual striking / grappling / resisting",
    "one-sided restraint / dragging / pinning",
    "blocked escape / cornering / unable to move away",
    "distress / cowering / defensive posture / fear",
    "vehicle or traffic object present",
    "hard jolt / abrupt trajectory break / sudden stop",
    "visible impact contact",
    "crowd surge / crowd scatter / opposing crowd motion",
    "large non-scene text or graphics",
    "sports / ring / referee / training / ceremony context",
    "rescue / assist / helping context",
    "camera flash / edit / fireworks / stage effect context",
]

NODE_STATE_RULE = "seen | probable | not_visible_or_outside | contradicted"
EDGE_STATE_RULE = "seen | plausible | not_visible_or_outside | contradicted"
STATUS_RULE = "full_match | anchored_partial | weak_fragment | none"


def _json_schema_example() -> str:
    example = {
        "observations": [
            {
                "cue": "tiny local flash at one source",
                "evidence": "small white-yellow flash at the tip of an object held by one person",
                "time_region": "early|middle|late|throughout",
                "spatial_anchor": "same source / same actor / same pair / crowd / vehicle / frame-wide / unclear",
                "confidence": 0.0,
            }
        ],
        "graph_matches": [
            {
                "graph": "localized_discharge_chain",
                "polarity": "abnormal",
                "graph_scope": "local_source",
                "status": "anchored_partial",
                "confidence": 0.0,
                "neutral_consistency": 0.0,
                "scene_anchor_support": 0.0,
                "scene_relation_support": 0.0,
                "scene_global_support": 0.0,
                "binding_consistency": 0.0,
                "bound_entities": {
                    "point_flash_or_smoke": ["L1"],
                    "aim_or_held_object": ["L1"],
                    "instant_reaction_or_impact": ["L2"],
                },
                "bound_relations": ["R2", "T1"],
                "scene_competition_signature": {
                    "entities": ["L1", "L2"],
                    "relations": ["R2", "T1"],
                    "context": "local_source",
                },
                "neutral_supporting_facts": [
                    "L1 is a person with an extended arm and a held object",
                    "T1 says the bright flash happens before the crowd reaction",
                ],
                "neutral_conflicting_facts": ["the target reaction is partly outside the crop"],
                "node_states": {
                    "point_flash_or_smoke": "seen",
                    "aim_or_held_object": "probable",
                    "instant_reaction_or_impact": "not_visible_or_outside",
                },
                "edge_states": {
                    "point_flash_or_smoke->instant_reaction_or_impact": "not_visible_or_outside"
                },
                "anchors_seen": ["point_flash_or_smoke"],
                "support_seen_or_probable": ["aim_or_held_object"],
                "missing_due_to_visibility_or_time": ["instant_reaction_or_impact"],
                "contradicted_nodes": [],
                "why": "The local source flash is clear. The consequence may be outside the short segment, so this is an anchored partial rather than a full match.",
            }
        ],
        "best_abnormal_graph": "localized_discharge_chain or NONE",
        "best_abnormal_status": STATUS_RULE,
        "best_abnormal_confidence": 0.0,
        "best_normal_graph": "camera_flash_or_edit or NONE",
        "best_normal_status": STATUS_RULE,
        "best_normal_confidence": 0.0,
        "binary_decision": "abnormal | normal | uncertain",
        "rescue_candidate": True,
        "rationale": "short explanation based on bound entities / relations and explicit anchors",
    }
    return json.dumps(example, ensure_ascii=False, indent=2)


def _neutral_inference_schema_example() -> str:
    example = {
        "scene_summary": "One-sentence neutral description of what the segment is mainly about.",
        "global_context": "overall setting, stage of action, and whether the scene feels calm, tense, aftermath-like, or unclear",
        "local_entities": [
            {
                "id": "L1",
                "location": "left foreground / center / right background / frame-wide",
                "what_is_visible": "person / vehicle / crowd / smoke / text / object / terrain / unclear",
                "role_or_function": "driver / restrained person / striking person / bystander / vehicle / crowd member / object / unclear",
                "state_or_action": "standing / aiming / lying down / moving / colliding / helping / resisting / scattering / unclear",
                "confidence": 0.0,
            }
        ],
        "local_local_relations": [
            {
                "id": "R1",
                "a": "L1",
                "relation": "contacts / restrains / carries / faces / aims at / collides with / moves away from / no direct relation / unclear",
                "b": "L2",
                "evidence": "short concrete visual evidence",
                "confidence": 0.0,
            }
        ],
        "local_global_relations": [
            {
                "id": "G1",
                "local": "L1",
                "relation": "drives the main action / is aftermath of the main action / is only background context / is possible confound context",
                "global_context": "short phrase",
                "confidence": 0.0,
            }
        ],
        "temporal_story": [
            {
                "id": "T1",
                "phase": "before | current | immediate_after | longer_aftermath | unknown",
                "statement": "short neutral event fragment",
                "confidence": 0.0,
            }
        ],
        "salient_concrete_cues": [
            "tiny local flash at one source",
            "vehicle stopped in damaged pose",
            "two people exchanging forceful contact",
        ],
        "most_likely_event_fragments": [
            "short neutral fragment without labeling it abnormal or normal"
        ],
        "visibility_limits": [
            "important cue may be outside crop / too brief / occluded / low resolution"
        ],
        "uncertainties_or_contradictions": [
            "what remains ambiguous or internally contradictory"
        ],
    }
    return json.dumps(example, ensure_ascii=False, indent=2)


def build_unbiased_inference_prompt() -> str:
    observables = "\n".join(f"- {x}" for x in LOW_LEVEL_OBSERVABLES)
    return f"""
You are doing a FIRST-PASS, UNBIASED scene understanding of the CURRENT VIDEO SEGMENT.

IMPORTANT:
- Do NOT start from anomaly labels or normal/confound labels.
- Do NOT force the segment into any pre-defined event type.
- First understand what the scene is about in neutral language.
- Build one LOCAL-GLOBAL scene graph: entities, roles, relations, and temporal fragments.
- Distinguish what is directly visible from what is uncertain or outside the crop/time span.
- Use concrete visible descriptions, not abstract judgments.

Your job:
1. Summarize the scene in one sentence.
2. Identify the main local entities/regions and assign them stable IDs.
3. Describe the important local-local interactions with stable relation IDs.
4. Describe the local-global relations: which locals drive the main scene and which are only background context.
5. Give a short temporal story with stable IDs for before/current/after fragments.
6. List the most salient concrete cues actually visible.
7. State what is uncertain because of visibility, truncation, or ambiguity.

LOW-LEVEL OBSERVABLES TO KEEP IN MIND:
{observables}

Rules:
- Prefer "person crouches and shields face" over abstract terms like "victimization".
- Prefer "vehicle lies overturned and smoking" over abstract terms like "accident semantics".
- Prefer assigning entity and relation IDs that can later be reused by graph judgment.
- If you are unsure, say so explicitly.
- Return JSON only.

JSON SCHEMA EXAMPLE:
{_neutral_inference_schema_example()}
""".strip()


def build_base_prompt(*, grounding_text: str = "", allowed_abnormal_graph_keys: Sequence[str] | None = None, neutral_scene_text: str = "") -> str:
    allowed = set(allowed_abnormal_graph_keys or [])
    abnormal_graphs = [g for g in ABNORMAL_GRAPHS if (not allowed or g.key in allowed)]
    abnormal_text = render_graphs_for_prompt(abnormal_graphs)
    normal_text = render_graphs_for_prompt(NORMAL_GRAPHS)
    scope_text = "\n".join(f"- {g.key}: scope={graph_reasoning_style(g.key)}" for g in [*abnormal_graphs, *NORMAL_GRAPHS])
    observables = "\n".join(f"- {x}" for x in LOW_LEVEL_OBSERVABLES)
    return f"""
You are judging whether the CURRENT VIDEO SEGMENT contains an abnormal event.

CANONICAL SHARED SCENE GRAPH (generated before any abnormal/normal graph was shown):
{neutral_scene_text or "No neutral scene inference available."}

THIS TIME THE SHARED SCENE GRAPH IS OPERATIVE, NOT JUST DESCRIPTIVE:
- Every abnormal or normal/confound graph must bind itself to the SAME shared scene graph above.
- For every graph match, bind graph nodes to entity IDs and relation IDs from the shared scene graph.
- If a graph cannot bind its anchors to the shared scene graph, its binding_consistency must be low.
- If two competing graphs explain the same entities/relations, make them compete over those same bindings.
- If a normal/confound graph only explains broad scene context but cannot bind explicit confound anchors to the same local entities/relations, it must stay weak.

CORE IDEA:
- Do NOT classify from a single cue word.
- Do NOT require every graph node to appear in this short segment.
- Match the segment against STRUCTURAL GRAPHS using CONCRETE VISUAL CUES + SHARED SCENE GRAPH BINDINGS.
- Some graph nodes may be outside the crop, outside the 96-frame span, or hidden by visibility limits.
- Therefore every node and edge must be labeled as one of:
  node_state = {NODE_STATE_RULE}
  edge_state = {EDGE_STATE_RULE}
- "not_visible_or_outside" is NOT the same as absent.

MATCHING PRINCIPLES:
1. Each graph node belongs to one evidence class: event_anchor, prelude, effect, or confound_anchor.
2. FULL MATCH = at least one direct anchor class is seen/probable and the main chain is supported.
3. ANCHORED PARTIAL = a direct anchor class is seen/probable, but some expected prelude/effect evidence is not_visible_or_outside rather than contradicted.
4. WEAK FRAGMENT = only context / prelude / aftermath-like evidence is present, or the graph is too vague to trust.
5. A segment can be ABNORMAL only when the best abnormal graph contains a center-window EVENT_ANCHOR.
6. A strong abnormal event_anchor/full match must NOT be canceled by a merely plausible scene-level normal context graph.
7. A normal/confound graph can win only when it has EXPLICIT CONFOUND_ANCHOR evidence bound to the shared scene graph.
8. Use UNCERTAIN only for TRUE ambiguity: both abnormal and normal/confound bind direct competing anchors to the same shared scene structure at similar strength, OR neither side has a direct anchor but there is still non-trivial incomplete evidence.
9. Prelude/setup alone and aftermath alone are not enough for final abnormal. They are candidate evidence only.
10. If the filename prior restricts the allowed abnormal graphs for this video, only consider those abnormal graphs.
11. Treat the pre-computed cue grounding as one evidence channel for node presence. Do NOT let it act as the only decision maker.
12. For each graph match, report scene_anchor_support, scene_relation_support, scene_global_support, and binding_consistency. These must come from the SHARED SCENE GRAPH.

LOW-LEVEL OBSERVABLES TO LOOK FOR:
{observables}

VIDEO-LEVEL ALLOWED ABNORMAL GRAPHS (from filename prior):
{", ".join(sorted(allowed)) if allowed else "no filename prior; all abnormal graphs are allowed"}

PRE-COMPUTED CUE GROUNDING (soft node evidence only):
{grounding_text or "No grounding summary available."}

GRAPH REASONING STYLES:
{scope_text}

ABNORMAL GRAPHS TO CONSIDER FOR THIS VIDEO:
{abnormal_text}

NORMAL / CONFOUND GRAPHS:
{normal_text}

IMPORTANT REMINDERS:
- A 96-frame segment may show only the onset, only the immediate consequence, or only the aftermath.
- If the missing parts are plausibly just outside the segment or outside the visible crop, mark them as not_visible_or_outside.
- Do NOT demote a strong abnormal anchored fragment to normal merely because one later node is not visible in this short segment.
- Do NOT let a generic context graph beat a concrete local event chain unless the normal graph itself is explicitly bound and supported.
- Concrete cues are better than abstract labels.
- Return JSON only.

JSON SCHEMA EXAMPLE:
{_json_schema_example()}
""".strip()


def build_rescue_prompt(*, factor: int, base_result: Dict[str, Any], grounding_text: str = "", allowed_abnormal_graph_keys: Sequence[str] | None = None, neutral_scene_text: str = "", wider_neutral_scene_text: str = "") -> str:
    allowed = set(allowed_abnormal_graph_keys or [])
    abnormal_graphs = [g for g in ABNORMAL_GRAPHS if (not allowed or g.key in allowed)]
    abnormal_text = render_graphs_for_prompt(abnormal_graphs)
    normal_text = render_graphs_for_prompt(NORMAL_GRAPHS)
    prior = {
        "best_abnormal_graph": base_result.get("best_abnormal_graph"),
        "best_abnormal_status": base_result.get("best_abnormal_status"),
        "best_abnormal_confidence": base_result.get("best_abnormal_confidence"),
        "best_normal_graph": base_result.get("best_normal_graph"),
        "best_normal_status": base_result.get("best_normal_status"),
        "best_normal_confidence": base_result.get("best_normal_confidence"),
        "binary_decision": base_result.get("binary_decision"),
        "rationale": base_result.get("rationale"),
    }
    return f"""
You are re-checking an uncertain or weak case using a wider clip.

The video you see is a {factor}x wider clip centered on the ORIGINAL decision window.
The ORIGINAL decision window is only the CENTER {'THIRD' if factor == 3 else 'FIFTH'} of the wider clip.

ORIGINAL CENTER-WINDOW SHARED SCENE GRAPH:
{neutral_scene_text or "No neutral scene inference available for the original segment."}

WIDER-CLIP SHARED SCENE GRAPH:
{wider_neutral_scene_text or "No neutral scene inference available for the wider clip."}

GOAL:
- Use the wider clip only to resolve whether nodes/edges missing in the original segment were simply outside the short span or outside the crop.
- Final judgment must still be about whether the ORIGINAL CENTER WINDOW itself supports an abnormal graph.
- Do NOT mark abnormal if the chain happens only outside the center window.
- Rescue may strengthen an existing center-window anchor or relation binding. It must NOT create a brand-new center-window event anchor from zero.
- Use the wider-clip grounding as supportive evidence, not as an automatic hard gate.
- Respect the shared scene graphs above when reasoning about local-local and local-global roles.
- If you update a graph, report which entity IDs / relation IDs in the center window are now better supported.

Prior base result:
{json.dumps(prior, ensure_ascii=False, indent=2)}

VIDEO-LEVEL ALLOWED ABNORMAL GRAPHS (from filename prior):
{", ".join(sorted(allowed)) if allowed else "no filename prior; all abnormal graphs are allowed"}

PRE-COMPUTED CUE GROUNDING FOR THE WIDER CLIP:
{grounding_text or "No grounding summary available."}

ABNORMAL GRAPHS TO CONSIDER FOR THIS VIDEO:
{abnormal_text}

NORMAL / CONFOUND GRAPHS:
{normal_text}

Return JSON only with this schema:
{json.dumps({
    "center_window_best_abnormal_graph": "graph or NONE",
    "center_window_best_abnormal_status": STATUS_RULE,
    "center_window_best_abnormal_confidence": 0.0,
    "center_window_best_normal_graph": "graph or NONE",
    "center_window_best_normal_status": STATUS_RULE,
    "center_window_best_normal_confidence": 0.0,
    "center_window_binary_decision": "abnormal | normal | uncertain",
    "context_effect": "strengthens_existing_binding | supports_normal_confound | neutral",
    "updated_nodes_now_supported_in_center": ["node ids now supported for the center window"],
    "updated_edges_now_supported_in_center": ["edge ids now supported for the center window"],
    "updated_bound_entities": ["entity ids in the center window now better supported"],
    "updated_bound_relations": ["relation ids in the center window now better supported"],
    "remaining_not_visible_or_outside": ["node or edge ids still missing because of visibility/time"],
    "neutral_consistency": 0.0,
    "scene_anchor_support": 0.0,
    "scene_relation_support": 0.0,
    "scene_global_support": 0.0,
    "binding_consistency": 0.0,
    "neutral_supporting_facts": ["facts from the shared scene graph that support the rescue conclusion"],
    "neutral_conflicting_facts": ["facts from the shared scene graph that conflict with the rescue conclusion"],
    "reason": "short explanation"
}, ensure_ascii=False, indent=2)}
""".strip()


def build_cue_verification_prompt(*, graph_key: str, graph_title: str, node_key: str, node_title: str, phrase: str) -> str:
    return f"""
You are verifying whether a highlighted image region matches a concrete visual phrase.

The image is a 2x2 panel of the SAME video frame:
- top-left: original frame with a red box around the candidate region
- top-right: the same frame with a heatmap overlay
- bottom-left: cropped candidate region
- bottom-right: cropped region with the same heatmap overlay

Target graph: {graph_key} ({graph_title})
Target node: {node_key} ({node_title})
Target phrase: "{phrase}"

Judge ONLY whether the HIGHLIGHTED / BOXED region visually contains the target phrase.
Do not rely on the rest of the frame outside the highlighted area.

Rules:
- Answer yes only when the highlighted region itself clearly depicts the phrase.
- Answer no when the highlighted region is vague, generic, dispersed, or better explained by something else.
- Small, brief, blurry, or partially cropped evidence can still be yes if the local semantics are truly visible.
- Do not infer missing objects or actions outside the highlighted region.

Return JSON only:
{{
  "match": "yes" or "no",
  "confidence": 0.0,
  "reason": "short explanation focused on the highlighted region"
}}
""".strip()
