from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .prompts import build_base_prompt, build_rescue_prompt, build_unbiased_inference_prompt
from .graph_schema import ABNORMAL_GRAPHS, NORMAL_GRAPHS, graph_lookup, node_evidence_class
from .data.video_labels import allowed_abnormal_graphs_from_video_name, extract_label_codes
from .runtime_meta import collect_runtime_metadata
from .calibration import EvidenceProfile, GlobalCalibrator
from .criteria import CriterionManager
from .ov_client import OpenVikingStore
from .grounding import CueGrounder, CueGroundingConfig, GroundingResult
from .scene_graph import normalize_scene_graph, normalize_match_scene_fields, derive_scene_support
from .utils.video import SegmentCache, ffprobe_meta
from .vlm.dashscope_backend import DashScopeVLM, DashScopeVLMConfig


CONTEXT_NORMAL_GRAPHS = {
    "camera_flash_or_edit",
    "sports_or_ceremonial_contact",
    "rescue_or_assist_interaction",
    "vehicle_motion_disturbance",
    "ceremonial_crowd_gathering",
    "stage_effect_or_fireworks",
    "text_card_non_scene",
}

ABNORMAL_STATUS_WEIGHT = {
    "full_match": 1.00,
    "anchored_partial": 0.82,
    "weak_fragment": 0.18,
    "none": 0.00,
}

NORMAL_STATUS_WEIGHT = {
    "full_match": 0.95,
    "anchored_partial": 0.55,
    "weak_fragment": 0.10,
    "none": 0.00,
}


@dataclass
class AgentConfig:
    model: str = "qwen-vl-max"
    fps: float = 2.0
    vl_high_resolution_images: bool = True
    api_key_env: str = "DASHSCOPE_API_KEY"
    cache_dir: str = ".cache_segments"
    enable_rescue: bool = True
    rescue_factors: Tuple[int, int] = (3, 5)
    enable_grounding: bool = True
    grounding_backend: str = "clip_gradcam"
    grounding_model: str = "openai/clip-vit-base-patch32"
    grounding_sample_frames: int = 6
    grounding_phrase_limit_per_node: int = 6
    grounding_device: str = "auto"
    enable_unbiased_scene_inference: bool = True
    scene_inference_on_rescue: bool = True
    enable_criteria: bool = False
    criterion_repo: str = ""
    criterion_root_uri: str = ""
    criterion_root_uri_file: str = "./.ov_criterion_root_uri"
    criterion_ov_mode: str = "embedded"
    criterion_ov_data: str = "./.openviking_criteria_data"
    criterion_ov_url: str = ""
    criterion_ov_api_key: str = ""


class StructuralBinaryAgent:
    def __init__(self, cfg: AgentConfig) -> None:
        self.cfg = cfg
        self.vlm = DashScopeVLM(DashScopeVLMConfig(model=cfg.model, fps=cfg.fps, api_key_env=cfg.api_key_env, vl_high_resolution_images=cfg.vl_high_resolution_images))
        self.seg_cache = SegmentCache(Path(cfg.cache_dir))
        self.grounder = CueGrounder(CueGroundingConfig(
            enabled=cfg.enable_grounding,
            backend=cfg.grounding_backend,
            model_name=cfg.grounding_model,
            sample_frames=cfg.grounding_sample_frames,
            phrase_limit_per_node=cfg.grounding_phrase_limit_per_node,
            device=cfg.grounding_device,
        ))
        self._runtime = collect_runtime_metadata()
        self._graph_lookup = graph_lookup()
        self._calibrator = GlobalCalibrator()
        self._criterion_store = None
        self._criterion_manager = None
        self._criterion_source = None
        if cfg.enable_criteria or cfg.criterion_repo or cfg.criterion_root_uri or Path(cfg.criterion_root_uri_file).exists():
            repo = Path(cfg.criterion_repo).resolve() if str(cfg.criterion_repo or '').strip() else None
            if repo is not None and repo.exists():
                try:
                    self._criterion_manager = CriterionManager.from_local_repo(repo)
                    self._criterion_source = f"local:{repo}"
                except Exception:
                    self._criterion_manager = None
            if self._criterion_manager is None:
                root_uri = str(cfg.criterion_root_uri or '').strip()
                if not root_uri:
                    p = Path(cfg.criterion_root_uri_file)
                    if p.exists():
                        root_uri = p.read_text(encoding='utf-8').strip()
                if root_uri:
                    store = OpenVikingStore(mode=cfg.criterion_ov_mode, data_path=cfg.criterion_ov_data, server_url=(cfg.criterion_ov_url or None), server_api_key=(cfg.criterion_ov_api_key or None))
                    try:
                        store.initialize()
                        self._criterion_manager = CriterionManager.from_openviking(store, root_uri)
                        self._criterion_store = store
                        self._criterion_source = f"openviking:{root_uri}"
                    except Exception:
                        try:
                            store.close()
                        except Exception:
                            pass
                        self._criterion_store = None
                        self._criterion_manager = None

    def _criteria_enabled(self) -> bool:
        return self._criterion_manager is not None

    def _apply_learned_competition_criteria(self, out: Dict[str, Any]) -> Dict[str, Any]:
        if self._criterion_manager is None:
            return out
        comp = out.get("competition_debug") if isinstance(out.get("competition_debug"), dict) else {}
        best_ab = comp.get("best_abnormal") if isinstance(comp.get("best_abnormal"), dict) else None
        best_nm = comp.get("best_normal") if isinstance(comp.get("best_normal"), dict) else None
        decision_debug = comp.get("decision_debug") if isinstance(comp.get("decision_debug"), dict) else {}
        if not best_ab:
            return out
        ab_prof = best_ab.get("profile") if isinstance(best_ab.get("profile"), dict) else {}
        nm_prof = best_nm.get("profile") if isinstance(best_nm, dict) and isinstance(best_nm.get("profile"), dict) else {}
        graph = str(best_ab.get("graph", out.get("best_abnormal_graph", "NONE")) or "NONE")
        if graph == "NONE":
            return out
        ok, dbg = self._criterion_manager.maybe_force_abnormal(
            graph=graph,
            ab_direct=float(ab_prof.get("event_anchor_strength", 0.0) or 0.0),
            nm_direct=float(nm_prof.get("confound_anchor_strength", 0.0) or 0.0),
            ab_prob=float(best_ab.get("probability", 0.0) or 0.0),
            nm_prob=float(best_nm.get("probability", 0.0) or 0.0) if best_nm else 0.0,
            ab_binding=float(ab_prof.get("binding_consistency", 0.0) or 0.0),
            decision=str(out.get("binary_decision", "uncertain") or "uncertain"),
        )
        out = dict(out)
        out.setdefault("criteria_debug", {})["competition"] = dbg
        out["criteria_source"] = self._criterion_source
        if ok:
            out["binary_decision"] = "abnormal"
            out["rescue_candidate"] = False
            note = f" OpenViking criterion forced abnormal for {graph}: stronger abnormal should conquer normal/context here."
            out["rationale"] = (str(out.get("rationale", "") or "") + note).strip()
        return out

    def _criteria_accept_rescue(self, base: Dict[str, Any], graph: str, final_ab_direct: float) -> Tuple[bool, Dict[str, Any]]:
        if self._criterion_manager is None or not graph or graph == "NONE":
            return True, {"criterion_kind": "rescue_gate", "graph": graph, "skipped": True}
        comp = base.get("competition_debug") if isinstance(base.get("competition_debug"), dict) else {}
        best_ab = comp.get("best_abnormal") if isinstance(comp.get("best_abnormal"), dict) else None
        ab_prof = best_ab.get("profile") if isinstance(best_ab, dict) and isinstance(best_ab.get("profile"), dict) else {}
        return self._criterion_manager.should_accept_rescue(
            graph=graph,
            base_ab_graph=str(best_ab.get("graph", base.get("best_abnormal_graph", "NONE")) if isinstance(best_ab, dict) else base.get("best_abnormal_graph", "NONE") or "NONE"),
            base_ab_direct=float(ab_prof.get("event_anchor_strength", 0.0) or 0.0),
            base_ab_binding=float(ab_prof.get("binding_consistency", 0.0) or 0.0),
            base_ab_scene_relation=float(ab_prof.get("scene_relation_support", 0.0) or 0.0),
            final_ab_direct=float(final_ab_direct),
        )

    def runtime_metadata(self) -> Dict[str, Any]:
        return dict(self._runtime)

    def predict_segment(
        self,
        *,
        segment_path: Path,
        video_id: Optional[str] = None,
        full_video_path: Optional[Path] = None,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        fps: Optional[float] = None,
    ) -> Dict[str, Any]:
        segment_path = Path(segment_path)
        prior_name = str(video_id or (full_video_path.stem if full_video_path is not None else segment_path.stem))
        allowed_abnormal_graphs = self._allowed_abnormal_graphs(prior_name)
        active_graphs = self._active_graphs(allowed_abnormal_graphs)

        neutral_scene = self._run_neutral_inference(segment_path) if self.cfg.enable_unbiased_scene_inference else {}
        grounding = self.grounder.ground_segment(segment_path, graphs=active_graphs, vlm=self.vlm)
        base_prompt = build_base_prompt(
            grounding_text=grounding.to_prompt_text(),
            allowed_abnormal_graph_keys=sorted(allowed_abnormal_graphs),
            neutral_scene_text=self._neutral_scene_prompt_text(neutral_scene),
        )
        raw_base = self._normalize_base_result(
            self.vlm.call_json(video_path=segment_path, prompt=base_prompt),
            allowed_abnormal_graphs=allowed_abnormal_graphs,
        )
        raw_base["_neutral_scene_graph"] = normalize_scene_graph(neutral_scene)
        grounded_base = self._fuse_grounding_into_base(dict(raw_base), grounding, allowed_abnormal_graphs=allowed_abnormal_graphs)
        grounded_base = self._apply_learned_competition_criteria(grounded_base)
        rescue_info: Dict[str, Any] = {"triggered": False, "attempts": [], "final_from": "base"}
        final = dict(grounded_base)

        can_rescue = (
            self.cfg.enable_rescue
            and full_video_path is not None
            and start_frame is not None
            and end_frame is not None
            and fps is not None
            and self._needs_rescue(grounded_base)
        )
        if can_rescue:
            rescue_info["triggered"] = True
            meta = ffprobe_meta(Path(full_video_path))
            for factor in self.cfg.rescue_factors:
                es, ee = self._expand_window(start_frame, end_frame, meta.num_frames, factor)
                if es == start_frame and ee == end_frame:
                    continue
                wider = self.seg_cache.get_segment(video_path=Path(full_video_path), start_frame=es, end_frame=ee, fps=float(fps))
                rescue_neutral_scene = self._run_neutral_inference(wider) if self.cfg.enable_unbiased_scene_inference and self.cfg.scene_inference_on_rescue else {}
                rescue_grounding = self.grounder.ground_segment(wider, graphs=active_graphs, vlm=self.vlm)
                raw = self.vlm.call_json(
                    video_path=wider,
                    prompt=build_rescue_prompt(
                        factor=factor,
                        base_result=grounded_base,
                        grounding_text=rescue_grounding.to_prompt_text(),
                        allowed_abnormal_graph_keys=sorted(allowed_abnormal_graphs),
                        neutral_scene_text=self._neutral_scene_prompt_text(neutral_scene),
                        wider_neutral_scene_text=self._neutral_scene_prompt_text(rescue_neutral_scene),
                    ),
                )
                r = self._normalize_rescue_result(raw, allowed_abnormal_graphs=allowed_abnormal_graphs)
                r["grounding"] = self._grounding_payload(rescue_grounding)
                rescue_info["attempts"].append({
                    "factor": factor,
                    "expanded_start_frame": es,
                    "expanded_end_frame": ee,
                    "neutral_scene_inference": rescue_neutral_scene,
                    "result": r,
                })
                final = self._apply_rescue(grounded_base, final, r, allowed_abnormal_graphs=allowed_abnormal_graphs)
                rescue_info["final_from"] = f"rescue_{factor}x"
                if final.get("binary_decision") in {"abnormal", "normal"}:
                    break

        out = {
            "video_id": video_id,
            "segment_path": str(segment_path),
            "binary_decision": str(final.get("binary_decision", "uncertain")),
            "best_abnormal_graph": final.get("best_abnormal_graph", "NONE"),
            "best_abnormal_status": final.get("best_abnormal_status", "none"),
            "best_abnormal_confidence": float(final.get("best_abnormal_confidence", 0.0) or 0.0),
            "best_normal_graph": final.get("best_normal_graph", "NONE"),
            "best_normal_status": final.get("best_normal_status", "none"),
            "best_normal_confidence": float(final.get("best_normal_confidence", 0.0) or 0.0),
            "observations": grounded_base.get("observations", []),
            "graph_matches": grounded_base.get("graph_matches", []),
            "grounding": self._grounding_payload(grounding),
            "neutral_scene_inference": neutral_scene,
            "raw_base_result": raw_base,
            "base_result": grounded_base,
            "final_result": final,
            "stage_trace": {
                "raw_vlm_decision": raw_base.get("binary_decision"),
                "after_grounding_decision": grounded_base.get("binary_decision"),
                "final_decision": final.get("binary_decision"),
                "rescue_final_from": rescue_info.get("final_from"),
            },
            "rescue": rescue_info,
            "video_label_codes": sorted(extract_label_codes(prior_name)),
            "allowed_abnormal_graphs": sorted(allowed_abnormal_graphs),
            "runtime_metadata": self.runtime_metadata(),
            "criteria_source": self._criterion_source,
            "criteria_debug": final.get("criteria_debug", grounded_base.get("criteria_debug")),
        }
        return out

    def predict_window(self, *, video_path: Path, start_frame: int, end_frame: int) -> Dict[str, Any]:
        video_path = Path(video_path)
        meta = ffprobe_meta(video_path)
        seg = self.seg_cache.get_segment(video_path=video_path, start_frame=start_frame, end_frame=end_frame, fps=meta.fps)
        return self.predict_segment(
            segment_path=seg,
            video_id=video_path.stem,
            full_video_path=video_path,
            start_frame=start_frame,
            end_frame=end_frame,
            fps=meta.fps,
        )

    def _allowed_abnormal_graphs(self, name: str) -> set[str]:
        return set(allowed_abnormal_graphs_from_video_name(name))

    def _active_graphs(self, allowed_abnormal_graphs: set[str]) -> List[Any]:
        abnormal = [g for g in ABNORMAL_GRAPHS if (not allowed_abnormal_graphs or g.key in allowed_abnormal_graphs)]
        return [*abnormal, *NORMAL_GRAPHS]

    def _grounding_payload(self, grounding: GroundingResult) -> Dict[str, Any]:
        return {
            "enabled": bool(grounding.enabled),
            "backend": grounding.backend,
            "model_name": grounding.model_name,
            "sampled_frame_indices": list(grounding.sampled_frame_indices),
            "top_abnormal_graph": grounding.top_abnormal_graph,
            "top_abnormal_score": float(grounding.top_abnormal_score),
            "top_normal_graph": grounding.top_normal_graph,
            "top_normal_score": float(grounding.top_normal_score),
            "graph_summaries": [
                {
                    "graph": gs.graph,
                    "polarity": gs.polarity,
                    "anchor_seen_or_probable": int(gs.anchor_seen_or_probable),
                    "anchor_total": int(gs.anchor_total),
                    "support_seen_or_probable": int(gs.support_seen_or_probable),
                    "support_total": int(gs.support_total),
                    "graph_grounded_score": float(gs.graph_grounded_score),
                    "strongest_node_key": gs.strongest_node_key,
                    "strongest_phrase": gs.strongest_phrase,
                    "strongest_frame_index": int(gs.strongest_frame_index),
                    "strongest_node_score": float(gs.strongest_node_score),
                    "verified_node_count": int(gs.verified_node_count),
                }
                for gs in grounding.graph_summaries
            ],
            "node_evidence": [
                {
                    "graph": ev.graph,
                    "graph_polarity": ev.graph_polarity,
                    "node_key": ev.node_key,
                    "node_title": ev.node_title,
                    "state": ev.state,
                    "best_phrase": ev.best_phrase,
                    "best_frame_index": int(ev.best_frame_index),
                    "match_score": float(ev.match_score),
                    "heatmap_focus": float(ev.heatmap_focus),
                    "heatmap_concentration": float(ev.heatmap_concentration),
                    "heatmap_compactness": float(ev.heatmap_compactness),
                    "proposal_score": float(ev.proposal_score),
                    "grounded_score": float(ev.grounded_score),
                    "verification_label": ev.verification_label,
                    "verification_confidence": float(ev.verification_confidence),
                    "verification_reason": ev.verification_reason,
                    "anchor": bool(ev.anchor),
                    "required": bool(ev.required),
                    "time_role": ev.time_role,
                    "spatial_role": ev.spatial_role,
                    "evidence_image_path": ev.evidence_image_path,
                }
                for ev in grounding.node_evidence
            ],
            "note": grounding.note,
        }

    def _run_neutral_inference(self, segment_path: Path) -> Dict[str, Any]:
        try:
            raw = self.vlm.call_json(video_path=segment_path, prompt=build_unbiased_inference_prompt())
            return self._normalize_neutral_inference(raw)
        except Exception as e:
            return normalize_scene_graph({
                "scene_summary": "neutral scene inference unavailable",
                "global_context": "unknown",
                "local_entities": [],
                "local_local_relations": [],
                "local_global_relations": [],
                "temporal_story": [],
                "salient_concrete_cues": [],
                "most_likely_event_fragments": [],
                "visibility_limits": [f"neutral inference failed: {e}"],
                "uncertainties_or_contradictions": ["neutral inference unavailable"],
            })

    def _normalize_neutral_inference(self, obj: Dict[str, Any]) -> Dict[str, Any]:
        return normalize_scene_graph(obj or {})

    def _neutral_scene_prompt_text(self, neutral: Dict[str, Any]) -> str:
        if not isinstance(neutral, dict) or not neutral:
            return "No neutral scene inference available."
        try:
            return json.dumps(neutral, ensure_ascii=False, indent=2)
        except Exception:
            return str(neutral)

    def _fuse_grounding_into_base(self, base: Dict[str, Any], grounding: GroundingResult, allowed_abnormal_graphs: set[str] | None = None) -> Dict[str, Any]:
        out = dict(base)
        if not grounding.enabled:
            out["grounding_note"] = grounding.note
            return self._calibrate_graph_competition(out, allowed_abnormal_graphs or set(), grounding_payload=None)

        out["grounding_note"] = grounding.note
        out["grounding_top_abnormal_graph"] = grounding.top_abnormal_graph
        out["grounding_top_abnormal_score"] = float(grounding.top_abnormal_score)
        out["grounding_top_normal_graph"] = grounding.top_normal_graph
        out["grounding_top_normal_score"] = float(grounding.top_normal_score)

        abnormal_gate = float(grounding.top_abnormal_score)
        normal_gate = float(grounding.top_normal_score)

        # Grounding is one evidence channel, not the sole gate.
        out["best_abnormal_confidence"] = float(max(0.0, min(1.0, 0.85 * float(out.get("best_abnormal_confidence", 0.0) or 0.0) + 0.15 * abnormal_gate)))
        out["best_normal_confidence"] = float(max(0.0, min(1.0, 0.85 * float(out.get("best_normal_confidence", 0.0) or 0.0) + 0.15 * normal_gate)))
        out["_base_grounding_payload"] = self._grounding_payload(grounding)
        out["_neutral_scene_graph"] = normalize_scene_graph(out.get("_neutral_scene_graph", {}) or {})
        return self._calibrate_graph_competition(out, allowed_abnormal_graphs or set(), grounding_payload=out["_base_grounding_payload"], scene_graph=out.get("_neutral_scene_graph"))

    def _needs_rescue(self, base: Dict[str, Any]) -> bool:
        decision = str(base.get("binary_decision", "uncertain"))
        if decision == "uncertain":
            return True
        if bool(base.get("rescue_candidate", False)):
            return True
        a = float(base.get("best_abnormal_confidence", 0.0) or 0.0)
        n = float(base.get("best_normal_confidence", 0.0) or 0.0)
        return abs(a - n) < 0.12

    def _apply_rescue(self, base: Dict[str, Any], current: Dict[str, Any], rescue: Dict[str, Any], allowed_abnormal_graphs: set[str] | None = None) -> Dict[str, Any]:
        decision = str(rescue.get("center_window_binary_decision", "uncertain") or "uncertain")
        a_graph = str(rescue.get("center_window_best_abnormal_graph", current.get("best_abnormal_graph", base.get("best_abnormal_graph", "NONE"))) or "NONE")
        a_status = str(rescue.get("center_window_best_abnormal_status", current.get("best_abnormal_status", base.get("best_abnormal_status", "none"))) or "none")
        a_conf = float(rescue.get("center_window_best_abnormal_confidence", current.get("best_abnormal_confidence", base.get("best_abnormal_confidence", 0.0))) or 0.0)
        n_graph = str(rescue.get("center_window_best_normal_graph", current.get("best_normal_graph", base.get("best_normal_graph", "NONE"))) or "NONE")
        n_status = str(rescue.get("center_window_best_normal_status", current.get("best_normal_status", base.get("best_normal_status", "none"))) or "none")
        n_conf = float(rescue.get("center_window_best_normal_confidence", current.get("best_normal_confidence", base.get("best_normal_confidence", 0.0))) or 0.0)
        if decision not in {"abnormal", "normal", "uncertain"}:
            decision = "uncertain"

        updated_nodes = rescue.get("updated_nodes_now_supported_in_center", []) if isinstance(rescue.get("updated_nodes_now_supported_in_center", []), list) else []
        ab_update_counts = self._rescue_update_class_counts(a_graph, updated_nodes) if a_graph != "NONE" else {"event_anchor": 0, "prelude": 0, "effect": 0, "confound_anchor": 0}
        nm_update_counts = self._rescue_update_class_counts(n_graph, updated_nodes) if n_graph != "NONE" else {"event_anchor": 0, "prelude": 0, "effect": 0, "confound_anchor": 0}

        # Use the original center-window competition profiles as the rescue seed source.
        # Rescue must not bootstrap itself from a previously synthesized rescue anchor.
        base_comp = base.get("competition_debug") if isinstance(base.get("competition_debug"), dict) else {}
        if not base_comp:
            base_comp = current.get("competition_debug") if isinstance(current.get("competition_debug"), dict) else {}
        candidate_profiles = base_comp.get("candidate_profiles") if isinstance(base_comp.get("candidate_profiles"), dict) else {}
        ab_profile_map = candidate_profiles.get("abnormal") if isinstance(candidate_profiles.get("abnormal"), dict) else {}
        nm_profile_map = candidate_profiles.get("normal") if isinstance(candidate_profiles.get("normal"), dict) else {}
        base_ab_prof = ab_profile_map.get(a_graph) if isinstance(ab_profile_map.get(a_graph), dict) else {}
        base_nm_prof = nm_profile_map.get(n_graph) if isinstance(nm_profile_map.get(n_graph), dict) else {}
        base_ab_event_strength = float((((base_ab_prof.get("profile") if isinstance(base_ab_prof.get("profile"), dict) else {}) or {}).get("event_anchor_strength", 0.0)) or 0.0)
        base_ab_event_inferred = float((((base_ab_prof.get("profile") if isinstance(base_ab_prof.get("profile"), dict) else {}) or {}).get("event_anchor_inferred", 0.0)) or 0.0)
        base_nm_confound_strength = float((((base_nm_prof.get("profile") if isinstance(base_nm_prof.get("profile"), dict) else {}) or {}).get("confound_anchor_strength", 0.0)) or 0.0)
        base_nm_confound_inferred = float((((base_nm_prof.get("profile") if isinstance(base_nm_prof.get("profile"), dict) else {}) or {}).get("confound_anchor_inferred", 0.0)) or 0.0)

        # Rescue may strengthen an already-seeded direct anchor only; it must not create one from zero.
        if (ab_update_counts.get("event_anchor", 0) <= 0 or base_ab_event_strength < self._calibrator.rescue_seed_direct_threshold):
            if decision == "abnormal":
                decision = "uncertain"
                a_conf = min(a_conf, max(float(current.get("best_abnormal_confidence", 0.0) or 0.0), 0.55))
        if (nm_update_counts.get("confound_anchor", 0) <= 0 or base_nm_confound_strength < self._calibrator.rescue_seed_direct_threshold):
            if decision == "normal":
                decision = "uncertain"
                n_conf = min(n_conf, max(float(current.get("best_normal_confidence", 0.0) or 0.0), 0.55))

        updated = dict(current)
        updated.setdefault("rescue_updates", []).append(rescue)
        base_ab_binding = float((((base_ab_prof.get("profile") if isinstance(base_ab_prof.get("profile"), dict) else {}) or {}).get("binding_consistency", 0.0)) or 0.0)
        base_nm_binding = float((((base_nm_prof.get("profile") if isinstance(base_nm_prof.get("profile"), dict) else {}) or {}).get("binding_consistency", 0.0)) or 0.0)
        base_ab_scene_relation = float((((base_ab_prof.get("profile") if isinstance(base_ab_prof.get("profile"), dict) else {}) or {}).get("scene_relation_support", 0.0)) or 0.0)
        base_nm_scene_relation = float((((base_nm_prof.get("profile") if isinstance(base_nm_prof.get("profile"), dict) else {}) or {}).get("scene_relation_support", 0.0)) or 0.0)
        base_ab_entities = tuple((((base_ab_prof.get("profile") if isinstance(base_ab_prof.get("profile"), dict) else {}) or {}).get("binding_entities", []) or []))
        base_ab_relations = tuple((((base_ab_prof.get("profile") if isinstance(base_ab_prof.get("profile"), dict) else {}) or {}).get("binding_relations", []) or []))
        base_nm_entities = tuple((((base_nm_prof.get("profile") if isinstance(base_nm_prof.get("profile"), dict) else {}) or {}).get("binding_entities", []) or []))
        base_nm_relations = tuple((((base_nm_prof.get("profile") if isinstance(base_nm_prof.get("profile"), dict) else {}) or {}).get("binding_relations", []) or []))
        base_ab_style = str((((base_ab_prof.get("profile") if isinstance(base_ab_prof.get("profile"), dict) else {}) or {}).get("graph_style", "generic")) or "generic")
        base_nm_style = str((((base_nm_prof.get("profile") if isinstance(base_nm_prof.get("profile"), dict) else {}) or {}).get("graph_style", "generic")) or "generic")
        updated["rescue_context"] = {
            "abnormal_graph": a_graph,
            "abnormal_status": a_status,
            "abnormal_confidence": a_conf,
            "abnormal_update_counts": ab_update_counts,
            "normal_graph": n_graph,
            "normal_status": n_status,
            "normal_confidence": n_conf,
            "normal_update_counts": nm_update_counts,
            "base_ab_event_strength": base_ab_event_strength,
            "base_ab_event_inferred": base_ab_event_inferred,
            "base_nm_confound_strength": base_nm_confound_strength,
            "base_nm_confound_inferred": base_nm_confound_inferred,
            "base_ab_binding": base_ab_binding,
            "base_nm_binding": base_nm_binding,
            "base_ab_scene_relation": base_ab_scene_relation,
            "base_nm_scene_relation": base_nm_scene_relation,
            "base_ab_entities": list(base_ab_entities),
            "base_ab_relations": list(base_ab_relations),
            "base_nm_entities": list(base_nm_entities),
            "base_nm_relations": list(base_nm_relations),
            "base_ab_style": base_ab_style,
            "base_nm_style": base_nm_style,
            "rescue_reason": str(rescue.get("reason", "") or ""),
            "context_effect": str(rescue.get("context_effect", "neutral") or "neutral"),
            "neutral_consistency": float(rescue.get("neutral_consistency", 0.5) or 0.5),
            "scene_anchor_support": float(rescue.get("scene_anchor_support", 0.0) or 0.0),
            "scene_relation_support": float(rescue.get("scene_relation_support", 0.0) or 0.0),
            "scene_global_support": float(rescue.get("scene_global_support", 0.0) or 0.0),
            "binding_consistency": float(rescue.get("binding_consistency", 0.0) or 0.0),
        }
        updated["binary_decision"] = decision
        # Rescue must be anchor-only: do not feed wider-window generic grounding/support back into
        # the center-window graph competition. Keep the original center-window grounding only.
        base_grounding_payload = current.get("_base_grounding_payload") if isinstance(current.get("_base_grounding_payload"), dict) else None
        if base_grounding_payload is None:
            base_grounding_payload = base.get("_base_grounding_payload") if isinstance(base.get("_base_grounding_payload"), dict) else None
        if base_grounding_payload is not None:
            updated["_base_grounding_payload"] = base_grounding_payload
        recalibrated = self._calibrate_graph_competition(updated, allowed_abnormal_graphs or set(), grounding_payload=base_grounding_payload, scene_graph=updated.get("_neutral_scene_graph") or base.get("_neutral_scene_graph"))
        final_comp = recalibrated.get("competition_debug") if isinstance(recalibrated.get("competition_debug"), dict) else {}
        best_ab = final_comp.get("best_abnormal") if isinstance(final_comp.get("best_abnormal"), dict) else None
        final_ab_prof = best_ab.get("profile") if isinstance(best_ab, dict) and isinstance(best_ab.get("profile"), dict) else {}
        final_ab_graph = str(best_ab.get("graph", recalibrated.get("best_abnormal_graph", a_graph)) if isinstance(best_ab, dict) else recalibrated.get("best_abnormal_graph", a_graph) or a_graph)
        final_ab_direct = float(final_ab_prof.get("event_anchor_strength", 0.0) or 0.0)
        accept_rescue, dbg = self._criteria_accept_rescue(base, final_ab_graph, final_ab_direct)
        recalibrated = dict(recalibrated)
        recalibrated.setdefault("criteria_debug", {})["rescue"] = dbg
        recalibrated["criteria_source"] = self._criterion_source
        if not accept_rescue and str(recalibrated.get("binary_decision", "uncertain")) == "abnormal":
            reverted = dict(base)
            reverted.setdefault("criteria_debug", {})["rescue"] = dbg
            reverted["criteria_source"] = self._criterion_source
            reverted["rationale"] = (str(reverted.get("rationale", "") or "") + f" OpenViking rescue criterion blocked neighboring-window influence for {final_ab_graph}.").strip()
            return reverted
        recalibrated = self._apply_learned_competition_criteria(recalibrated)
        return recalibrated

    def _normalize_base_result(self, obj: Dict[str, Any], allowed_abnormal_graphs: set[str] | None = None) -> Dict[str, Any]:
        out = dict(obj or {})
        out["observations"] = out.get("observations", []) if isinstance(out.get("observations", []), list) else []
        out["graph_matches"] = out.get("graph_matches", []) if isinstance(out.get("graph_matches", []), list) else []
        out["best_abnormal_graph"] = str(out.get("best_abnormal_graph", "NONE") or "NONE")
        out["best_abnormal_status"] = str(out.get("best_abnormal_status", "none") or "none").lower()
        if out["best_abnormal_status"] not in {"full_match", "anchored_partial", "weak_fragment", "none"}:
            out["best_abnormal_status"] = "none"
        out["best_normal_graph"] = str(out.get("best_normal_graph", "NONE") or "NONE")
        out["best_normal_status"] = str(out.get("best_normal_status", "none") or "none").lower()
        if out["best_normal_status"] not in {"full_match", "anchored_partial", "weak_fragment", "none"}:
            out["best_normal_status"] = "none"
        out["best_abnormal_confidence"] = float(out.get("best_abnormal_confidence", 0.0) or 0.0)
        out["best_normal_confidence"] = float(out.get("best_normal_confidence", 0.0) or 0.0)
        dec = str(out.get("binary_decision", "uncertain") or "uncertain").lower()
        out["binary_decision"] = dec if dec in {"abnormal", "normal", "uncertain"} else "uncertain"
        out["rescue_candidate"] = bool(out.get("rescue_candidate", False))
        out["rationale"] = str(out.get("rationale", "") or "")
        norm_matches = []
        for m in out["graph_matches"]:
            if not isinstance(m, dict):
                continue
            mm = dict(m)
            try:
                mm["neutral_consistency"] = float(mm.get("neutral_consistency", 0.5) or 0.5)
            except Exception:
                mm["neutral_consistency"] = 0.5
            mm["neutral_consistency"] = max(0.0, min(1.0, mm["neutral_consistency"]))
            for k in ["neutral_supporting_facts", "neutral_conflicting_facts", "anchors_seen", "support_seen_or_probable", "missing_due_to_visibility_or_time", "contradicted_nodes"]:
                if not isinstance(mm.get(k, []), list):
                    mm[k] = []
            mm = normalize_match_scene_fields(mm)
            norm_matches.append(mm)
        out["graph_matches"] = norm_matches
        return self._apply_video_name_graph_filter(out, allowed_abnormal_graphs or set())

    def _normalize_rescue_result(self, obj: Dict[str, Any], allowed_abnormal_graphs: set[str] | None = None) -> Dict[str, Any]:
        out = dict(obj or {})
        out["center_window_best_abnormal_graph"] = str(out.get("center_window_best_abnormal_graph", "NONE") or "NONE")
        out["center_window_best_abnormal_status"] = str(out.get("center_window_best_abnormal_status", "none") or "none").lower()
        if out["center_window_best_abnormal_status"] not in {"full_match", "anchored_partial", "weak_fragment", "none"}:
            out["center_window_best_abnormal_status"] = "none"
        out["center_window_best_normal_graph"] = str(out.get("center_window_best_normal_graph", "NONE") or "NONE")
        out["center_window_best_normal_status"] = str(out.get("center_window_best_normal_status", "none") or "none").lower()
        if out["center_window_best_normal_status"] not in {"full_match", "anchored_partial", "weak_fragment", "none"}:
            out["center_window_best_normal_status"] = "none"
        out["center_window_best_abnormal_confidence"] = float(out.get("center_window_best_abnormal_confidence", 0.0) or 0.0)
        out["center_window_best_normal_confidence"] = float(out.get("center_window_best_normal_confidence", 0.0) or 0.0)
        dec = str(out.get("center_window_binary_decision", "uncertain") or "uncertain").lower()
        out["center_window_binary_decision"] = dec if dec in {"abnormal", "normal", "uncertain"} else "uncertain"
        out["context_effect"] = str(out.get("context_effect", "neutral") or "neutral")
        out["updated_required_nodes"] = out.get("updated_required_nodes", []) if isinstance(out.get("updated_required_nodes", []), list) else []
        out["updated_required_edges"] = out.get("updated_required_edges", []) if isinstance(out.get("updated_required_edges", []), list) else []
        out["updated_nodes_now_supported_in_center"] = out.get("updated_nodes_now_supported_in_center", []) if isinstance(out.get("updated_nodes_now_supported_in_center", []), list) else []
        out["updated_edges_now_supported_in_center"] = out.get("updated_edges_now_supported_in_center", []) if isinstance(out.get("updated_edges_now_supported_in_center", []), list) else []
        out["remaining_not_visible_or_outside"] = out.get("remaining_not_visible_or_outside", []) if isinstance(out.get("remaining_not_visible_or_outside", []), list) else []
        out["reason"] = str(out.get("reason", "") or "")
        try:
            out["neutral_consistency"] = float(out.get("neutral_consistency", 0.5) or 0.5)
        except Exception:
            out["neutral_consistency"] = 0.5
        out["neutral_consistency"] = max(0.0, min(1.0, out["neutral_consistency"]))
        out["neutral_supporting_facts"] = out.get("neutral_supporting_facts", []) if isinstance(out.get("neutral_supporting_facts", []), list) else []
        out["neutral_conflicting_facts"] = out.get("neutral_conflicting_facts", []) if isinstance(out.get("neutral_conflicting_facts", []), list) else []
        out = normalize_match_scene_fields(out)
        return self._apply_video_name_graph_filter_to_rescue(out, allowed_abnormal_graphs or set())

    def _apply_video_name_graph_filter(self, out: Dict[str, Any], allowed_abnormal_graphs: set[str]) -> Dict[str, Any]:
        if not allowed_abnormal_graphs:
            return out
        out = dict(out)
        gm = out.get("graph_matches", [])
        if isinstance(gm, list):
            filtered = []
            for m in gm:
                if not isinstance(m, dict):
                    continue
                pol = str(m.get("polarity", ""))
                g = str(m.get("graph", ""))
                if pol == "abnormal" and g and g not in allowed_abnormal_graphs:
                    continue
                filtered.append(m)
            out["graph_matches"] = filtered
        bad_graph = str(out.get("best_abnormal_graph", "NONE") or "NONE")
        if bad_graph != "NONE" and bad_graph not in allowed_abnormal_graphs:
            out["best_abnormal_graph_disallowed_by_video_name"] = bad_graph
            out["best_abnormal_graph"] = "NONE"
            out["best_abnormal_status"] = "none"
            out["best_abnormal_confidence"] = 0.0
            if str(out.get("binary_decision", "uncertain")) == "abnormal":
                out["binary_decision"] = "uncertain"
                out["rescue_candidate"] = False
                note = " Abnormal graph suppressed because it is not included in the video-name anomaly labels."
                out["rationale"] = (str(out.get("rationale", "") or "") + note).strip()
        return out

    def _apply_video_name_graph_filter_to_rescue(self, out: Dict[str, Any], allowed_abnormal_graphs: set[str]) -> Dict[str, Any]:
        if not allowed_abnormal_graphs:
            return out
        out = dict(out)
        bad_graph = str(out.get("center_window_best_abnormal_graph", "NONE") or "NONE")
        if bad_graph != "NONE" and bad_graph not in allowed_abnormal_graphs:
            out["center_window_best_abnormal_graph_disallowed_by_video_name"] = bad_graph
            out["center_window_best_abnormal_graph"] = "NONE"
            out["center_window_best_abnormal_status"] = "none"
            out["center_window_best_abnormal_confidence"] = 0.0
            if str(out.get("center_window_binary_decision", "uncertain")) == "abnormal":
                out["center_window_binary_decision"] = "uncertain"
                out["reason"] = (str(out.get("reason", "") or "") + " Abnormal graph suppressed because it is not included in the video-name anomaly labels.").strip()
        return out

    def _grounding_summary_map(self, grounding_payload: Optional[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        if not isinstance(grounding_payload, dict):
            return {}
        items = grounding_payload.get("graph_summaries", [])
        out: Dict[str, Dict[str, Any]] = {}
        if isinstance(items, list):
            for item in items:
                if isinstance(item, dict) and str(item.get("graph", "")):
                    out[str(item["graph"])] = item
        return out

    def _grounding_node_map(self, grounding_payload: Optional[Dict[str, Any]]) -> Dict[str, Dict[str, Dict[str, Any]]]:
        if not isinstance(grounding_payload, dict):
            return {}
        items = grounding_payload.get("node_evidence", [])
        out: Dict[str, Dict[str, Dict[str, Any]]] = {}
        if isinstance(items, list):
            for item in items:
                if not isinstance(item, dict):
                    continue
                g = str(item.get("graph", "") or "")
                n = str(item.get("node_key", "") or "")
                if g and n:
                    out.setdefault(g, {})[n] = item
        return out

    @staticmethod
    def _state_strength(state: str) -> float:
        state = str(state or "").lower()
        if state == "seen":
            return 1.0
        if state == "probable":
            return 0.60
        if state == "contradicted":
            return -0.80
        return 0.0

    def _grounding_node_strength(self, node_ev: Optional[Dict[str, Any]]) -> float:
        if not isinstance(node_ev, dict):
            return 0.0
        state = str(node_ev.get("state", "") or "")
        proposal = float(node_ev.get("grounded_score", 0.0) or 0.0)
        verify_label = str(node_ev.get("verification_label", "unverified") or "unverified")
        verify_conf = float(node_ev.get("verification_confidence", 0.0) or 0.0)
        if state == "contradicted":
            return 0.0
        if verify_label == "yes":
            base = 0.45 + 0.30 * verify_conf
            if state == "seen":
                base += 0.10
            elif state == "probable":
                base += 0.05
            return max(0.0, min(1.0, base))
        if verify_label == "no":
            return max(0.0, min(0.12, 0.12 * proposal))
        return max(0.0, min(1.0, 0.40 * proposal + 0.18 * max(0.0, self._state_strength(state))))

    def _match_profile(self, graph_key: str, polarity: str, match: Dict[str, Any], grounding_payload: Optional[Dict[str, Any]], scene_graph: Optional[Dict[str, Any]]) -> EvidenceProfile:
        graph = self._graph_lookup.get(graph_key)
        if graph is None:
            return EvidenceProfile(graph=graph_key, polarity=polarity, status=str(match.get("status", "none") or "none"), raw_confidence=float(match.get("confidence", 0.0) or 0.0), neutral_consistency=float(match.get("neutral_consistency", 0.5) or 0.5))

        match = normalize_match_scene_fields(match)
        node_states = match.get("node_states", {}) if isinstance(match.get("node_states", {}), dict) else {}
        grounding_nodes = self._grounding_node_map(grounding_payload).get(graph_key, {})
        scene_support = derive_scene_support(match, scene_graph or {}, graph_key)

        cls_combined_max = {"event_anchor": 0.0, "prelude": 0.0, "effect": 0.0, "confound_anchor": 0.0}
        cls_grounded_max = {"event_anchor": 0.0, "prelude": 0.0, "effect": 0.0, "confound_anchor": 0.0}
        cls_inferred_max = {"event_anchor": 0.0, "prelude": 0.0, "effect": 0.0, "confound_anchor": 0.0}
        cls_counts = {"event_anchor": 0, "prelude": 0, "effect": 0, "confound_anchor": 0}
        contradicted = 0
        verified_yes = 0

        for node in graph.nodes:
            cls = node_evidence_class(graph.key, node.key)
            cls_counts[cls] += 1
            base_state = str(node_states.get(node.key, "") or "")
            base_strength = max(0.0, self._state_strength(base_state))
            g_ev = grounding_nodes.get(node.key)
            grounded_strength = self._grounding_node_strength(g_ev)
            combined_strength = max(0.65 * grounded_strength + 0.35 * base_strength, base_strength * 0.85)

            cls_combined_max[cls] = max(cls_combined_max[cls], combined_strength)
            cls_grounded_max[cls] = max(cls_grounded_max[cls], grounded_strength)
            cls_inferred_max[cls] = max(cls_inferred_max[cls], base_strength)

            if base_state == "contradicted" or str((g_ev or {}).get("state", "") or "") == "contradicted":
                contradicted += 1
            if str((g_ev or {}).get("verification_label", "unverified") or "unverified") == "yes":
                verified_yes += 1

        event_grounded_raw = cls_grounded_max["event_anchor"]
        event_inferred = cls_inferred_max["event_anchor"]
        confound_grounded_raw = cls_grounded_max["confound_anchor"]
        confound_inferred = cls_inferred_max["confound_anchor"]
        prelude_strength = max(cls_combined_max["prelude"], 0.55 * scene_support["scene_relation_support"])
        effect_strength = max(cls_combined_max["effect"], 0.45 * scene_support["scene_relation_support"])
        node_count = max(1, sum(cls_counts.values()))
        contradiction_strength = min(1.0, contradicted / float(node_count))
        verified_fraction = min(1.0, verified_yes / float(node_count))
        neutral_consistency = max(0.0, min(1.0, float(match.get("neutral_consistency", 0.5) or 0.5)))
        raw_conf = max(0.0, min(1.0, 0.65 * float(match.get("confidence", 0.0) or 0.0) + 0.20 * neutral_consistency + 0.15 * scene_support["binding_consistency"]))
        if neutral_consistency < 0.45:
            contradiction_strength = min(1.0, contradiction_strength + 0.50 * (0.45 - neutral_consistency) / 0.45)

        style = scene_support["graph_style"]
        if polarity == "abnormal":
            if style == "local_pair":
                event_direct = 0.35 * event_grounded_raw + 0.35 * scene_support["scene_anchor_support"] + 0.20 * scene_support["binding_consistency"] + 0.10 * scene_support["scene_relation_support"]
            elif style == "local_source":
                event_direct = 0.45 * event_grounded_raw + 0.25 * scene_support["scene_anchor_support"] + 0.20 * scene_support["scene_relation_support"] + 0.10 * scene_support["binding_consistency"]
            elif style == "distributed_crowd":
                event_direct = 0.20 * event_grounded_raw + 0.35 * scene_support["scene_anchor_support"] + 0.25 * scene_support["scene_relation_support"] + 0.20 * scene_support["scene_global_support"]
            elif style == "phase_object":
                event_direct = 0.25 * event_grounded_raw + 0.25 * scene_support["scene_anchor_support"] + 0.25 * scene_support["scene_relation_support"] + 0.15 * scene_support["binding_consistency"] + 0.10 * scene_support["scene_global_support"]
            else:
                event_direct = 0.35 * event_grounded_raw + 0.30 * scene_support["scene_anchor_support"] + 0.20 * scene_support["scene_relation_support"] + 0.15 * scene_support["binding_consistency"]
            confound_direct = 0.0
            direct_anchor_grounded = event_direct
        else:
            if style == "local_pair":
                confound_direct = 0.35 * confound_grounded_raw + 0.35 * scene_support["scene_anchor_support"] + 0.20 * scene_support["binding_consistency"] + 0.10 * scene_support["scene_relation_support"]
            elif style == "local_source":
                confound_direct = 0.45 * confound_grounded_raw + 0.25 * scene_support["scene_anchor_support"] + 0.20 * scene_support["scene_relation_support"] + 0.10 * scene_support["binding_consistency"]
            elif style in {"distributed_crowd", "frame_wide"}:
                confound_direct = 0.20 * confound_grounded_raw + 0.30 * scene_support["scene_anchor_support"] + 0.20 * scene_support["scene_relation_support"] + 0.30 * scene_support["scene_global_support"]
            elif style == "phase_object":
                confound_direct = 0.25 * confound_grounded_raw + 0.25 * scene_support["scene_anchor_support"] + 0.25 * scene_support["scene_relation_support"] + 0.15 * scene_support["binding_consistency"] + 0.10 * scene_support["scene_global_support"]
            else:
                confound_direct = 0.35 * confound_grounded_raw + 0.30 * scene_support["scene_anchor_support"] + 0.20 * scene_support["scene_relation_support"] + 0.15 * scene_support["binding_consistency"]
            event_direct = 0.0
            direct_anchor_grounded = confound_direct

        support_presence = max(prelude_strength, effect_strength, scene_support["scene_relation_support"], 0.6 * scene_support["scene_global_support"])
        direct_anchor_present = direct_anchor_grounded >= self._calibrator.strong_direct_threshold and scene_support["binding_consistency"] >= self._calibrator.binding_threshold

        return EvidenceProfile(
            graph=graph_key,
            polarity=polarity,
            status=str(match.get("status", "none") or "none"),
            raw_confidence=raw_conf,
            neutral_consistency=neutral_consistency,
            event_anchor_strength=event_direct,
            prelude_strength=prelude_strength,
            effect_strength=effect_strength,
            confound_anchor_strength=confound_direct,
            contradiction_strength=contradiction_strength,
            verified_fraction=verified_fraction,
            direct_anchor_grounded=direct_anchor_grounded,
            event_anchor_inferred=event_inferred,
            confound_anchor_inferred=confound_inferred,
            direct_anchor_present=direct_anchor_present,
            support_presence=support_presence,
            node_count=node_count,
            scene_anchor_support=scene_support["scene_anchor_support"],
            scene_relation_support=scene_support["scene_relation_support"],
            scene_global_support=scene_support["scene_global_support"],
            binding_consistency=scene_support["binding_consistency"],
            graph_style=scene_support["graph_style"],
            binding_entities=scene_support["binding_entities"],
            binding_relations=scene_support["binding_relations"],
            competition_context=scene_support["competition_context"],
        )

    def _rescue_update_class_counts(self, graph_key: str, node_ids: List[str]) -> Dict[str, int]:
        out = {"event_anchor": 0, "prelude": 0, "effect": 0, "confound_anchor": 0}
        for node_id in node_ids:
            if not isinstance(node_id, str):
                continue
            cls = node_evidence_class(graph_key, node_id)
            out[cls] = out.get(cls, 0) + 1
        return out

    def _synthetic_rescue_profile(self, rescue_ctx: Dict[str, Any], *, polarity: str) -> EvidenceProfile | None:
        if not isinstance(rescue_ctx, dict):
            return None
        if polarity == "abnormal":
            graph = str(rescue_ctx.get("abnormal_graph", "NONE") or "NONE")
            if graph == "NONE":
                return None
            cls_counts = rescue_ctx.get("abnormal_update_counts", {}) if isinstance(rescue_ctx.get("abnormal_update_counts", {}), dict) else {}
            event_updates = int(cls_counts.get("event_anchor", 0) or 0)
            base_seed = float(rescue_ctx.get("base_ab_event_strength", 0.0) or 0.0)
            base_inferred = float(rescue_ctx.get("base_ab_event_inferred", 0.0) or 0.0)
            if event_updates <= 0 or base_seed < self._calibrator.rescue_seed_direct_threshold:
                return None
            event_strength = min(1.0, max(base_seed, base_seed + 0.12 * min(event_updates, 3)))
            return EvidenceProfile(
                graph=graph,
                polarity="abnormal",
                status=str(rescue_ctx.get("abnormal_status", "none") or "none"),
                raw_confidence=float(rescue_ctx.get("abnormal_confidence", 0.0) or 0.0),
                neutral_consistency=float(rescue_ctx.get("neutral_consistency", 0.5) or 0.5),
                event_anchor_strength=event_strength,
                prelude_strength=0.0,
                effect_strength=0.0,
                direct_anchor_grounded=event_strength,
                event_anchor_inferred=max(base_inferred, event_strength),
                direct_anchor_present=event_strength >= self._calibrator.strong_direct_threshold,
                support_presence=0.0,
                node_count=max(1, event_updates),
                scene_anchor_support=float(rescue_ctx.get("scene_anchor_support", 0.0) or 0.0),
                scene_relation_support=max(float(rescue_ctx.get("base_ab_scene_relation", 0.0) or 0.0), float(rescue_ctx.get("scene_relation_support", 0.0) or 0.0)),
                scene_global_support=float(rescue_ctx.get("scene_global_support", 0.0) or 0.0),
                binding_consistency=max(float(rescue_ctx.get("base_ab_binding", 0.0) or 0.0), float(rescue_ctx.get("binding_consistency", 0.0) or 0.0)),
                graph_style=str(rescue_ctx.get("base_ab_style", "generic") or "generic"),
                binding_entities=tuple(rescue_ctx.get("base_ab_entities", []) or []),
                binding_relations=tuple(rescue_ctx.get("base_ab_relations", []) or []),
                competition_context=str(rescue_ctx.get("base_ab_style", "generic") or "generic"),
            )
        graph = str(rescue_ctx.get("normal_graph", "NONE") or "NONE")
        if graph == "NONE":
            return None
        cls_counts = rescue_ctx.get("normal_update_counts", {}) if isinstance(rescue_ctx.get("normal_update_counts", {}), dict) else {}
        confound_updates = int(cls_counts.get("confound_anchor", 0) or 0)
        base_seed = float(rescue_ctx.get("base_nm_confound_strength", 0.0) or 0.0)
        base_inferred = float(rescue_ctx.get("base_nm_confound_inferred", 0.0) or 0.0)
        if confound_updates <= 0 or base_seed < self._calibrator.rescue_seed_direct_threshold:
            return None
        confound_strength = min(1.0, max(base_seed, base_seed + 0.12 * min(confound_updates, 3)))
        return EvidenceProfile(
            graph=graph,
            polarity="normal",
            status=str(rescue_ctx.get("normal_status", "none") or "none"),
            raw_confidence=float(rescue_ctx.get("normal_confidence", 0.0) or 0.0),
            neutral_consistency=float(rescue_ctx.get("neutral_consistency", 0.5) or 0.5),
            prelude_strength=0.0,
            effect_strength=0.0,
            confound_anchor_strength=confound_strength,
            direct_anchor_grounded=confound_strength,
            confound_anchor_inferred=max(base_inferred, confound_strength),
            direct_anchor_present=confound_strength >= self._calibrator.strong_direct_threshold,
            support_presence=0.0,
            node_count=max(1, confound_updates),
            scene_anchor_support=float(rescue_ctx.get("scene_anchor_support", 0.0) or 0.0),
            scene_relation_support=max(float(rescue_ctx.get("base_nm_scene_relation", 0.0) or 0.0), float(rescue_ctx.get("scene_relation_support", 0.0) or 0.0)),
            scene_global_support=float(rescue_ctx.get("scene_global_support", 0.0) or 0.0),
            binding_consistency=max(float(rescue_ctx.get("base_nm_binding", 0.0) or 0.0), float(rescue_ctx.get("binding_consistency", 0.0) or 0.0)),
            graph_style=str(rescue_ctx.get("base_nm_style", "generic") or "generic"),
            binding_entities=tuple(rescue_ctx.get("base_nm_entities", []) or []),
            binding_relations=tuple(rescue_ctx.get("base_nm_relations", []) or []),
            competition_context=str(rescue_ctx.get("base_nm_style", "generic") or "generic"),
        )

    def _calibrate_graph_competition(self, out: Dict[str, Any], allowed_abnormal_graphs: set[str], grounding_payload: Optional[Dict[str, Any]], scene_graph: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        out = self._apply_video_name_graph_filter(dict(out), allowed_abnormal_graphs)
        graph_matches = out.get("graph_matches", []) if isinstance(out.get("graph_matches", []), list) else []

        abnormal_candidates = []
        normal_candidates = []
        for m in graph_matches:
            if not isinstance(m, dict):
                continue
            polarity = str(m.get("polarity", "") or "")
            graph_key = str(m.get("graph", "") or "")
            if not graph_key or polarity not in {"abnormal", "normal"}:
                continue
            if polarity == "abnormal" and allowed_abnormal_graphs and graph_key not in allowed_abnormal_graphs:
                continue
            prof = self._match_profile(graph_key, polarity, m, grounding_payload, scene_graph)
            cal = self._calibrator.score(prof)
            if polarity == "abnormal":
                abnormal_candidates.append(cal)
            else:
                normal_candidates.append(cal)

        rescue_ctx = out.get("rescue_context") if isinstance(out.get("rescue_context"), dict) else None
        if rescue_ctx:
            syn_ab = self._synthetic_rescue_profile(rescue_ctx, polarity="abnormal")
            if syn_ab is not None and (not allowed_abnormal_graphs or syn_ab.graph in allowed_abnormal_graphs):
                abnormal_candidates.append(self._calibrator.score(syn_ab))
            syn_nm = self._synthetic_rescue_profile(rescue_ctx, polarity="normal")
            if syn_nm is not None:
                normal_candidates.append(self._calibrator.score(syn_nm))

        # Strict class-matched competition starts from the matching direct evidence class.
        abnormal_candidates.sort(
            key=lambda x: (
                x.profile.event_anchor_strength,
                x.probability,
                x.profile.event_anchor_inferred,
                x.profile.raw_confidence,
            ),
            reverse=True,
        )
        normal_candidates.sort(
            key=lambda x: (
                x.profile.confound_anchor_strength,
                x.probability,
                x.profile.confound_anchor_inferred,
                x.profile.raw_confidence,
            ),
            reverse=True,
        )
        best_ab = abnormal_candidates[0] if abnormal_candidates else None
        best_nm = normal_candidates[0] if normal_candidates else None

        comp = self._calibrator.decide(best_ab, best_nm)
        ab_graph = best_ab.graph if best_ab else "NONE"
        ab_status = best_ab.status if best_ab else "none"
        ab_score = float(best_ab.probability) if best_ab else 0.0
        nm_graph = best_nm.graph if best_nm else "NONE"
        nm_status = best_nm.status if best_nm else "none"
        nm_score = float(best_nm.probability) if best_nm else 0.0

        if allowed_abnormal_graphs and ab_graph != "NONE" and ab_graph not in allowed_abnormal_graphs:
            comp["decision"] = "normal" if nm_score >= self._calibrator.ambiguous_prob_threshold else "uncertain"
            comp["rescue_candidate"] = False

        out["best_abnormal_graph"] = ab_graph
        out["best_abnormal_status"] = ab_status
        out["best_abnormal_confidence"] = ab_score
        out["best_normal_graph"] = nm_graph
        out["best_normal_status"] = nm_status
        out["best_normal_confidence"] = nm_score
        out["binary_decision"] = str(comp["decision"])
        out["rescue_candidate"] = bool(comp["rescue_candidate"])

        rationale_parts = []
        if best_ab:
            rationale_parts.append(
                f"abnormal={best_ab.graph}:{best_ab.status}:{best_ab.probability:.3f}:event_grounded={best_ab.profile.event_anchor_strength:.2f}:event_inferred={best_ab.profile.event_anchor_inferred:.2f}:prelude={best_ab.profile.prelude_strength:.2f}:effect={best_ab.profile.effect_strength:.2f}:phase={best_ab.phase_state}"
            )
        if best_nm:
            rationale_parts.append(
                f"normal={best_nm.graph}:{best_nm.status}:{best_nm.probability:.3f}:confound_grounded={best_nm.profile.confound_anchor_strength:.2f}:confound_inferred={best_nm.profile.confound_anchor_inferred:.2f}:prelude={best_nm.profile.prelude_strength:.2f}:effect={best_nm.profile.effect_strength:.2f}:phase={best_nm.phase_state}"
            )
        comp_note = (
            "competition recalibrated with grounded direct anchors and explicit phase states: "
            + "; ".join(rationale_parts)
            + "; final abnormal/normal requires grounded direct anchor; rescue may only strengthen a seeded anchor; phase-only evidence stays candidate/uncertain"
        ).strip()
        base_rationale = str(out.get("rationale", "") or "").strip()
        out["rationale"] = (base_rationale + (" " if base_rationale else "") + comp_note).strip()
        out["competition_debug"] = {
            "best_abnormal": best_ab.to_dict() if best_ab else None,
            "best_normal": best_nm.to_dict() if best_nm else None,
            "decision_debug": comp,
            "top_abnormal_candidates": [c.to_dict() for c in abnormal_candidates[:3]],
            "top_normal_candidates": [c.to_dict() for c in normal_candidates[:3]],
            "candidate_profiles": {
                "abnormal": {c.graph: c.to_dict() for c in abnormal_candidates},
                "normal": {c.graph: c.to_dict() for c in normal_candidates},
            },
            "allowed_abnormal_graphs": sorted(allowed_abnormal_graphs),
            "rescue_context": rescue_ctx,
        }
        return out

    def _expand_window(self, start: int, end: int, num_frames: int, factor: int) -> Tuple[int, int]:
        cur_len = max(1, int(end) - int(start) + 1)
        target_len = min(int(num_frames), cur_len * int(factor))
        center = (int(start) + int(end)) / 2.0
        new_start = int(round(center - (target_len - 1) / 2.0))
        new_end = new_start + target_len - 1
        if new_start < 0:
            new_end += -new_start
            new_start = 0
        if new_end >= int(num_frames):
            shift = new_end - int(num_frames) + 1
            new_start = max(0, new_start - shift)
            new_end = int(num_frames) - 1
        return int(new_start), int(new_end)
