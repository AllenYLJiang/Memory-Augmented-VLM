#!/usr/bin/env bash
set -euo pipefail

# WSL launcher for the native-Windows GPU process. The current WSL installation cannot
# access NVML/CUDA on this machine, so powershell.exe owns the CUDA models and Windows paths.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PS_SCRIPT="$(wslpath -w "${ROOT}/run_ot_graph_advantage_combined_v4_local_qwen.ps1")"

TAG="${TAG:-conditional_ot_v4_local_qwen3vl8b}"
VIDEO_SAMPLE_FRACTION="${VIDEO_SAMPLE_FRACTION:-0.3}"
VIDEO_SAMPLE_SEED="${VIDEO_SAMPLE_SEED:-20260725}"
MAX_WINDOWS_PER_VIDEO="${MAX_WINDOWS_PER_VIDEO:-1}"
MAX_TOTAL_WINDOWS="${MAX_TOTAL_WINDOWS:-0}"
TOP_K_ABNORMAL_GRAPHS="${TOP_K_ABNORMAL_GRAPHS:-4}"
TOP_K_NORMAL_GRAPHS="${TOP_K_NORMAL_GRAPHS:-6}"
ASYNC_WORKERS="${ASYNC_WORKERS:-3}"
MATCHING_PROFILE="${MATCHING_PROFILE:-full}"
RETRIEVAL_MODE="${RETRIEVAL_MODE:-clip}"
MAX_PIXELS="${MAX_PIXELS:-147456}"
MAX_VLM_BATCH_SIZE="${MAX_VLM_BATCH_SIZE:-24}"

ARGS=(
  -NoProfile -ExecutionPolicy Bypass -File "${PS_SCRIPT}"
  -Tag "${TAG}"
  -VideoSampleFraction "${VIDEO_SAMPLE_FRACTION}"
  -VideoSampleSeed "${VIDEO_SAMPLE_SEED}"
  -MaxWindowsPerVideo "${MAX_WINDOWS_PER_VIDEO}"
  -MaxTotalWindows "${MAX_TOTAL_WINDOWS}"
  -TopKAbnormalGraphs "${TOP_K_ABNORMAL_GRAPHS}"
  -TopKNormalGraphs "${TOP_K_NORMAL_GRAPHS}"
  -Workers "${ASYNC_WORKERS}"
  -MatchingProfile "${MATCHING_PROFILE}"
  -RetrievalMode "${RETRIEVAL_MODE}"
  -MaxPixels "${MAX_PIXELS}"
  -MaxVlmBatchSize "${MAX_VLM_BATCH_SIZE}"
)
[[ "${DISCOVER_GRAPHS:-0}" == "1" ]] && ARGS+=(
  -DiscoverGraphs
  -MaxDiscoveryCases "${MAX_DISCOVERY_CASES:-30}"
  -DiscoveryCasesPerVideo "${DISCOVERY_CASES_PER_VIDEO:-1}"
)
[[ "${RUN_BLIND_VERIFIER:-0}" == "1" ]] && ARGS+=(-RunBlindVerifier)
[[ "${RUN_LEAVE_ONE_OUT:-0}" == "1" ]] && ARGS+=(-RunLeaveOneOut)
[[ "${NO_IMAGES:-0}" == "1" ]] && ARGS+=(-NoImages)
[[ "${MOCK:-0}" == "1" ]] && ARGS+=(-Mock)

powershell.exe "${ARGS[@]}"
