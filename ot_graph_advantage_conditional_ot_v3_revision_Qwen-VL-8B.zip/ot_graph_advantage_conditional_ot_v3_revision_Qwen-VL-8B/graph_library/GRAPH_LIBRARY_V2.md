# Conditional-OT Active Discovered Graph Library

- Original graphs: 27
- Added unique discovered graphs: 12
- Consolidated duplicate proposals: 1
- Final abnormal graphs: 17
- Final normal graphs: 22
- Legacy explicit edges: not used
- Evaluation: discovery-source videos are excluded by default

## Abnormal graphs

### Weapon discharge in civilian context

- key: `civilian_weapon_discharge`
- origin: `test_derived_v3_discovery`
- semantics: one coherent visible episode of a firearm being discharged by a person in a civilian environment, clearly not part of military activity
- nodes: `weapon_discharge_smoke`, `civilian_environment`

### Crowd escalation chain

- key: `crowd_escalation_chain`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Crowd escalation chain
- nodes: `opposing_crowd_motion`, `visible_disorder_or_scatter`, `damage_or_debris`

### Destructive fire aftermath

- key: `destructive_fire_aftermath`
- origin: `test_derived_v3_discovery`
- semantics: one coherent visible episode of a destructive aftermath scene featuring a stationary ground fire, scattered debris, and rising smoke in an outdoor setting
- nodes: `ground_fire_or_burning`, `debris_or_damage_scene`, `smoke_or_dust_plume`

### Localized discharge / emission chain

- key: `localized_discharge_chain`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Localized discharge / emission chain
- nodes: `point_flash_or_smoke`, `aim_or_held_object`, `instant_reaction_or_impact`

### News branded crowd disorder

- key: `news_branded_crowd_disorder`
- origin: `test_derived_v3_discovery`
- semantics: the node set should describe one coherent episode of news footage showing real-world civil unrest or crowd dispersal, indicated by persistent on-screen branding and a chaotic crowd event
- nodes: `news_branding_persistent`, `crowd_disorder_flight`

### News reported violent aftermath

- key: `news_reported_violent_aftermath`
- origin: `test_derived_discovery_v1`
- semantics: A news chyron or overlay explicitly mentions a violent incident, while the live scene shows a disorganized, chaotic group consistent with the aftermath of a conflict or disturbance.
- nodes: `chyron_mentioning_violence`, `crowd_disorder_or_dispersal`

### Obscured-source explosion / large destructive blast

- key: `obscured_source_explosion`
- origin: `test_derived_v3_discovery`
- semantics: the node set should describe one coherent episode of a large destructive blast or explosion where the initial ignition source is not directly visible, but the outward expansion and aftermath are clearly shown
- nodes: `outward_expansion_or_ejecta`, `smoke_or_damage_aftermath`

### Post-collision aftermath (no impact visible)

- key: `post_collision_aftermath`
- origin: `test_derived_v3_discovery`
- semantics: one coherent visible episode of a vehicle collision aftermath where the impact itself is not seen
- nodes: `damaged_vehicle_in_scene`, `post_crash_debris_or_context`

### Protest confrontation scene

- key: `protest_confrontation_scene`
- origin: `test_derived_v3_discovery`
- semantics: one coherent visible episode of a street protest or confrontation involving a crowd and visible authority response or disorder
- nodes: `visible_crowd`, `authority_vehicle_or_response`, `disorder_evidence`

### Protest fire and crowd escalation

- key: `protest_fire_crowd_escalation`
- origin: `test_derived_v3_discovery`
- semantics: the node set should describe one coherent visible episode of a protest or riot that prominently features a large fire (e.g., burning vehicle, structure) and an escalating, disorderly crowd
- nodes: `large_fire_or_burning_object`, `disorderly_crowd_or_protest`, `smoke_or_haze_aftermath`

### Street protest with visible spray paint vandalism

- key: `protest_with_spray_paint_vandalism`
- origin: `test_derived_v3_discovery`
- semantics: a crowd occupies a road or public space, and visible spray paint graffiti on surfaces indicates property defacement or vandalism
- nodes: `crowd_occupying_road`, `visible_spray_paint_markings`

### Reciprocal conflict chain

- key: `reciprocal_conflict_chain`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Reciprocal conflict chain
- nodes: `forceful_interpersonal_contact`, `return_action_or_resistance`, `imbalance_or_fall`

### Reckless vehicle occupation by crowd

- key: `reckless_vehicle_occupation`
- origin: `test_derived_v3_discovery`
- semantics: one coherent visible episode of a crowd recklessly occupying a vehicle, with individuals climbing or standing on the roof and a surrounding crowd
- nodes: `person_on_vehicle_roof`, `crowd_surrounding_vehicle`

### Source-centered blast chain

- key: `source_centered_blast_chain`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Source-centered blast chain
- nodes: `source_bloom`, `outward_expansion_or_ejecta`, `smoke_or_damage_aftermath`

### Street destruction aftermath

- key: `street_destruction_aftermath`
- origin: `test_derived_v3_discovery`
- semantics: the node set should describe one coherent visible episode of street‑level destruction aftermath, showing damaged traffic/street infrastructure and concurrent fire or smoke, without requiring an active collision or explosion
- nodes: `damaged_traffic_infrastructure`, `fire_or_smoke_on_street`

### Unilateral control / blocked escape chain

- key: `unilateral_control_chain`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Unilateral control / blocked escape chain
- nodes: `one_sided_control`, `victim_distress_or_defense`, `blocked_escape_or_confinement`

### Vehicle collision chain

- key: `vehicle_collision_chain`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Vehicle collision chain
- nodes: `vehicle_or_traffic_object`, `impact_or_trajectory_break`, `collision_aftermath`

## Normal graphs

### Armed threat without physical contact or discharge

- key: `armed_threat_without_discharge`
- origin: `test_derived_v3_discovery`
- semantics: one coherent visible episode of at least one person pointing a firearm at another person, causing visible fear or submission, but without any actual discharge, physical contact, or overt fight
- nodes: `weapon_pointed_at_person`, `victim_submission_or_fear`, `no_discharge_or_contact`

### Brief sports scuffle with referee intervention

- key: `basketball_conflict`
- origin: `test_derived_discovery_v1`
- semantics: Players engage in a brief shoving match that is immediately broken up by a referee, typical of routine physical fouls in basketball.
- nodes: `referee_physical_intervention`, `brief_player_shoving_cluster`

### Camera flash / edit confound

- key: `camera_flash_or_edit`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Camera flash / edit confound
- nodes: `frame_wide_or_source_unclear_flash`, `no_local_consequence`

### Ceremonial / calm crowd gathering

- key: `ceremonial_crowd_gathering`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Ceremonial / calm crowd gathering
- nodes: `crowd_presence`, `organized_or_calm_pattern`

### Game / simulation footage

- key: `game_simulation_footage`
- origin: `test_derived_discovery_v1`
- semantics: one coherent visible episode of a video game or simulation environment, not real-world footage
- nodes: `persistent_game_hud_or_minimap`, `vehicle_with_simulation_livery`

### Industrial hazard scene without explosion

- key: `industrial_hazard_without_blast`
- origin: `test_derived_v3_discovery`
- semantics: one coherent visible episode of an industrial or factory setting with persistent sparks, small ground fires, and visible machinery, where a character moves through the environment without any signs of explosion, combat, or deliberate violence
- nodes: `industrial_factory_environment`, `persistent_sparks_and_fire`, `character_moving_through_scene`

### News branded footage of dramatic event

- key: `news_branded_footage`
- origin: `test_derived_discovery_v1`
- semantics: the node set should describe one coherent visible episode of a news broadcast containing real‑world footage, as indicated by persistent branding and an event scene
- nodes: `news_logo_or_bug`, `scene_footage`

### Non-violent dust cloud or smoke plume

- key: `non_violent_dust_cloud`
- origin: `test_derived_v3_discovery`
- semantics: one coherent visible episode of a large, dense dust or smoke cloud that is not accompanied by open violence, fire, or explosive effects; the cloud may originate from a vehicle, construction, training exercise, or controlled demolition, and the surrounding context lacks fighting or visible destruction.
- nodes: `dense_dust_cloud`, `non_violent_context`

### Non-violent standoff with ground assistance

- key: `non_violent_standoff_with_assistance`
- origin: `test_derived_v3_discovery`
- semantics: one coherent visible episode of a tense but non-violent group standoff, where at least one person lies on the ground and receives non-aggressive physical attention, without any actual exchange of blows
- nodes: `tense_group_facing`, `ground_person_physical_interaction`, `no_visible_fight`

### Normal driving sequence

- key: `normal_driving`
- origin: `test_derived_discovery_v1`
- semantics: one coherent visible episode of normal road traffic driving without collision
- nodes: `vehicle_or_road_scene`, `smooth_driving_motion`

### Normal driving flow

- key: `normal_driving_flow`
- origin: `test_derived_discovery_v1`
- semantics: one coherent visible episode of steady road driving with no safety events
- nodes: `road_driving_scene`, `steady_forward_motion`

### Orderly crowd watching an event

- key: `orderly_crowd_watching`
- origin: `test_derived_discovery_v1`
- semantics: people standing behind a barrier, calmly watching an event
- nodes: `crowd_behind_barrier`, `calm_behavior`

### Regular traffic scene

- key: `regular_traffic_scene`
- origin: `test_derived_discovery_v1`
- semantics: the node set should describe one coherent regular traffic scene without violence
- nodes: `moving_vehicle`, `road_environment`

### Regulated Ice Hockey Game

- key: `regulated_ice_hockey_game`
- origin: `test_derived_discovery_v1`
- semantics: a structured ice hockey game with players, rink environment, and officials, indicating physical contact is part of normal play
- nodes: `ice_hockey_rink`, `referee_on_ice`

### Rescue / assist interaction

- key: `rescue_or_assist_interaction`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Rescue / assist interaction
- nodes: `one_sided_contact`, `assistive_direction`

### Legal sports body check

- key: `sports_body_check_normal`
- origin: `test_derived_discovery_v1`
- semantics: one coherent legal sports body check occurring within a recognized sports environment
- nodes: `forceful_player_contact`, `sports_environment`

### Sports / ceremonial contact

- key: `sports_or_ceremonial_contact`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Sports / ceremonial contact
- nodes: `contact_present`, `structured_nonviolent_context`

### Stage effect / fireworks confound

- key: `stage_effect_or_fireworks`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Stage effect / fireworks confound
- nodes: `show_like_bright_effect`, `celebration_or_stage_context`

### Stationary traffic scene normal confound

- key: `stationary_traffic_scene_normal_confound`
- origin: `test_derived_discovery_v1`
- semantics: one coherent visible episode of vehicles being stopped or moving slowly in a normal traffic context, without any live collision or violent motion
- nodes: `multiple_vehicles_present`, `no_active_impact_motion`

### Text card / non-scene

- key: `text_card_non_scene`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Text card / non-scene
- nodes: `frame_dominated_by_text_or_graphic`

### Vehicle driving in dusty quarry/construction environment

- key: `vehicle_in_dusty_construction_environment`
- origin: `test_derived_v3_discovery`
- semantics: one coherent visible episode of a vehicle driving through a dusty, off-road construction or quarry environment with earthmoving equipment, without any collision or crash
- nodes: `vehicle_in_dusty_environment`, `earthmoving_equipment_present`

### Vehicle motion disturbance without collision

- key: `vehicle_motion_disturbance`
- origin: `original_partac_graph`
- semantics: the node set should describe one coherent Vehicle motion disturbance without collision
- nodes: `vehicle_scene`, `motion_disturbance_only`
