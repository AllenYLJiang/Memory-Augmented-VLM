# Revised Inference-Cost Estimate: Optimized M2 Unary OT with an 8B VLM on A100 80GB

## 0. Purpose and scope

This note revises `INFERENCE_COST_ESTIMATE_8B_VLM_A100.md` under the following requested assumptions:

1. The inference images are **not treated as 1280×720 inputs**. A production resize/token cap is applied.
2. The VLM scores nodes only for the selected **4 abnormal + 6 normal graph shortlist**. The other 13 abnormal and 16 normal graphs are considered only by a cheap local retriever and are not sent through node-level VLM scoring.
3. Inference uses **M2 Unary OT**, not M3 conditional refinement.
4. The production optimizations in Sections 10.1–10.5 of the earlier estimate are all applied:
   - retain M2;
   - disable research-only calls;
   - replace VLM graph retrieval with local retrieval/caching;
   - encode the eight images once and reuse the visual prefix;
   - batch independent-node prompts with continuous batching.
5. For CGSGM, one structured VLM pass for each temporal unit returns **all five semantic components for all visible subjects together**.

The values below are planning estimates, not measured benchmarks of the exact local 8B VLM. The final section gives a short benchmark procedure for replacing them with measured values.

---

## 1. Direct corrections to the previous assumptions

### 1.1 Image resolution: the revised estimate does not use 1280×720

The current v3 code extracts eight native-resolution JPEG frames and invokes the backend with high-resolution-image mode:

```text
tools/vlm_runtime.py
    cv2.imwrite(... original decoded frame ...)
    vl_high_resolution_images=True
```

Therefore, **the current code as written does not enforce a resize**. If the source video is 1280×720, it can indeed send approximately 1280×720 imagery to the processor. That is slower than the production configuration estimated here.

For the revised estimate, add a deterministic resize before JPEG encoding or configure the VLM processor's `max_pixels`:

```text
central fast setting: 448 × 252, aspect ratio 16:9
```

Both dimensions are multiples of 28. For Qwen2.5-VL-style dynamic resolution, this is approximately:

\[
N_{\text{vis/image}}
=\frac{448\times252}{28\times28}
=144\ \text{visual tokens/image}.
\]

For eight frames:

\[
N_{\text{vis/window}}=8\times144=1152.
\]

This is far below 1280×720:

\[
\frac{1280\times720}{28^2}\approx1176
\quad\text{visual tokens/image},
\]

or about 9,408 visual tokens for eight frames. Thus the revised central input has about **8.2× fewer visual tokens** than native 1280×720 frames.

A slightly more conservative accuracy-oriented setting is:

```text
588 × 336 ≈ 252 visual tokens/image ≈ 2,016 tokens/eight frames
```

The main estimates below use **448×252**. The 588×336 alternative is reported separately.

> Implementation requirement: the speed estimates are not valid until resizing or `max_pixels` is explicitly enforced. Merely setting `vl_high_resolution_images=True` does not guarantee the smaller input.

---

### 1.2 Only shortlisted graphs receive node-level VLM scoring

The active catalog contains:

```text
17 abnormal graphs
22 normal graphs
39 total graphs
```

The active wrapper uses:

```text
4 abnormal graphs
6 normal graphs
10 shortlisted graphs/window
```

Therefore the remaining graphs are:

```text
13 abnormal graphs
16 normal graphs
```

They are **not** passed through independent node VLM scoring after the shortlist has been chosen.

Under the production optimization, all 39 graph descriptions may be compared cheaply by a local CLIP/text retriever or cached scene-level retriever, but the expensive 8B VLM evaluates only the nodes belonging to the final 4+6 shortlist.

From the current active catalog, a random 4-abnormal + 6-normal shortlist has approximately:

```text
mean graph-node instances: 22.12
mean unique semantic nodes: 21.97
10th / median / 90th percentile unique nodes: 20 / 22 / 23
```

The revised central estimate therefore uses:

```text
22 unique node evaluations/window
```

No cost is assigned to VLM scoring of the other 29 graphs, because it does not occur.

---

## 2. Optimized M2 inference path

The production path is:

```text
one 96-frame window
    ↓
select eight exact frames
    ↓
resize each frame to 448×252
    ↓
encode the eight images once
    ↓
local retrieval chooses 4 abnormal + 6 normal graphs
    ↓
collect approximately 22 unique nodes
    ↓
batch 22 independent node prompts against one shared visual prefix
    ↓
construct U_ij from presence, location and evidence quality
    ↓
run local dustbin Sinkhorn OT for each shortlisted graph
    ↓
aggregate abnormal graphs and normal graphs
    ↓
compute anomaly margin/score
```

The following are disabled:

```text
VLM graph selector
conditional graph-refinement calls
M3a/M3b/M3c
blind verifier
leave-one-node-out analysis
DeepSeek graph discovery
heatmap grounding
```

Wider-window rescue is treated separately in Section 8.

---

## 3. Number of VLM calls per window

### 3.1 Logical semantic calls

For the central shortlist:

\[
N_{\text{logical}}=N_{\text{unique shortlisted nodes}}\approx22.
\]

Thus:

| Component | Logical VLM calls/window |
|---|---:|
| Local graph retrieval over all 39 graphs | **0** |
| Independent node scoring for final shortlist | **≈22** |
| M2 Unary OT | **0** |
| Abnormal-vs-normal aggregation | **0** |
| LLM/DeepSeek | **0** |
| **Total** | **≈22** |

The practical range caused by shortlist overlap is approximately:

```text
20–23 logical node calls/window
```

### 3.2 Physical execution after batching and prefix reuse

“22 VLM calls” does not mean 22 serial image encodings.

With all requested optimizations:

```text
vision-encoder passes/window:     1
shared multimodal-prefix builds:  1
batched decoder groups/window:    1, or 2 if max batch size is 16
logical node outputs:             approximately 22
```

The 22 prompts remain semantically independent, but they are executed as one continuous batch. This preserves the node-only definition while avoiding 22 serial passes through the vision encoder.

### 3.3 Why M2 does not add VLM calls

M0, M1 and M2 use exactly the same node outputs:

```text
p_i
L_ij
Q_ij
```

M2 adds only a local Sinkhorn allocation over small matrices. Therefore:

```text
M0 node matching: approximately 22 logical VLM calls
M2 graph matching: approximately 22 logical VLM calls
```

The difference is local mathematics, not VLM invocation count.

---

## 4. Visual and text workload

### 4.1 Shared visual prefix

At 448×252:

```text
144 visual tokens/image
8 images/window
1,152 visual tokens/shared prefix
```

The eight images are encoded once. Their projected multimodal prefix and, ideally, their decoder KV prefix are reused by all node prompts.

### 4.2 Per-node text

A compact independent-node request contains:

```text
node title and a small cue bundle
presence probability
8-value location distribution
8-value evidence-quality vector
short visible-evidence text
```

Reasonable planning values are:

```text
node-specific input tail:  180–280 text tokens
node output:               100–160 tokens
central output estimate:   approximately 130 tokens/node
```

For 22 nodes:

```text
total generated tokens/window: approximately 2,200–3,520
central estimate:               approximately 2,860
```

Because the requests are batched, aggregate token throughput—not 22× batch-1 latency—is the relevant quantity.

---

## 5. Revised latency estimate on one A100 80GB

### 5.1 Assumed inference stack

```text
model class:       Qwen2.5-VL-7B / comparable 8B VLM
weights:           BF16/FP16
GPU:               A100-SXM4-80GB, TP=1
attention:         FlashAttention 2 or equivalent
server:            optimized vLLM, SGLang, or TensorRT-style runtime
state:             warm model and warm kernels
visual input:      8 × 448×252
node batch:        approximately 22
output mode:       compact JSON
```

Official Qwen documentation supports explicit visual-token caps and recommends FlashAttention 2 for multi-image/video efficiency. NVIDIA reports more than 6,000 aggregate tokens/s for an optimized FP16 Llama-3.1-8B workload on A100 under high load; a real VLM workload is slower because it includes vision encoding and multimodal prefill. The estimates below therefore use a deliberately lower effective throughput.

### 5.2 Per-window latency breakdown

| Stage | Estimated time/window |
|---|---:|
| Decode eight frames, resize, JPEG/cache lookup | 0.05–0.20 s |
| One batched vision-encoder pass | 0.25–0.70 s |
| Shared multimodal prefix prefill/cache | 0.15–0.45 s |
| Batched node-tail prefill and JSON generation | 1.8–4.0 s |
| Parse outputs, build affinities, 10 small OT solves, aggregate | 0.01–0.05 s |
| Scheduling/IPC variation | 0.20–0.60 s |
| **Total optimized M2** | **2.5–6.0 s/window** |

Central planning value:

```text
approximately 3.8–4.2 seconds/window
```

A safe project-planning value is:

```text
5 seconds/window
```

### 5.3 Resolution sensitivity

| Visual setting | Visual tokens/eight frames | Estimated M2 latency/window |
|---|---:|---:|
| **448×252** | **1,152** | **2.5–6.0 s** |
| 588×336 | 2,016 | 3.0–7.0 s |
| Native 1280×720 | ≈9,408 | roughly 7–18 s, highly implementation-dependent |

The native-resolution row is shown only to explain why an explicit resize is important. It is **not** used in the revised central estimate.

### 5.4 Current code versus optimized implementation

The current code performs separate backend requests and does not expose a production visual-prefix-reuse interface. Therefore, running the archive without the 10.3–10.5 engineering changes can remain much slower.

The 2.5–6.0-second estimate applies only when:

```text
local retrieval is used;
all node prompts are batched;
vision features are reused;
the decoder prefix is cached/reused where supported;
compact JSON is enforced.
```

---

## 6. Revised GPU-memory estimate

### 6.1 Resident model memory

For an approximately 7–8B BF16 VLM:

```text
raw BF16 parameters:             approximately 15–17 GB
vision/projector/runtime weights included
practical resident model range:  approximately 18–22 GB
```

### 6.2 KV cache

For a Qwen2.5-7B-like decoder with 28 layers, four KV heads, head dimension 128 and BF16 KV:

\[
\text{KV bytes/token}
=28\times2\times4\times128\times2
=57{,}344\ \text{bytes}
\approx56\ \text{KiB}.
\]

Shared visual prefix:

\[
1152\times56\ \text{KiB}\approx63\ \text{MiB}.
\]

Assuming approximately 320–440 node-specific input/output tokens per node:

\[
22\times(320\text{ to }440)\times56\ \text{KiB}
\approx385\text{ to }530\ \text{MiB}.
\]

After padding, allocator fragmentation and batching metadata, a practical KV allowance is:

```text
approximately 0.6–1.2 GB/window
```

### 6.3 Peak memory

| Memory component | Estimate |
|---|---:|
| Model and runtime-resident weights | 18–22 GB |
| Vision encoder activations/workspace | 0.8–2.0 GB |
| Batched decoder activations/workspace | 1.0–2.5 GB |
| KV cache for one 22-node window batch | 0.6–1.2 GB |
| CUDA/runtime/fragmentation allowance | 1–2 GB |
| **Estimated process peak** | **22–29 GB** |

The **incremental active memory attributable to one window** is approximately:

```text
1.5–3.5 GB/window
```

This is not the same as the memory displayed by a serving engine. vLLM may reserve 60–72GB of an 80GB GPU for its KV-cache pool even when one request uses only a small fraction of that reservation.

### 6.4 Concurrent windows

A100 80GB can normally hold several optimized windows concurrently. A practical starting point is:

```text
2–4 concurrent windows
22 node sequences/window
microbatch node prompts if needed
```

Expected peak for three active windows is roughly:

```text
26–36 GB of actually required model/workload memory
```

although the server may pre-reserve more.

---

## 7. Graph matching versus node matching cost

### 7.1 M0 independent nodes

```text
VLM logical calls:      approximately 22
vision passes:          1 with reuse
batched decoder groups: 1–2
latency:                2.5–6.0 s/window
peak memory:            22–29 GB process total
```

### 7.2 M2 Unary OT graph matching

```text
VLM logical calls:      approximately 22
vision passes:          1 with reuse
batched decoder groups: 1–2
additional OT work:     ten tiny local Sinkhorn problems
latency:                2.5–6.0 s/window
peak memory:            22–29 GB process total
```

The OT matrices are tiny. With approximately two to three nodes per graph and 16 evidence slots plus NULL, all ten solves normally take well below the VLM scheduling noise:

```text
OT latency increment:   approximately 1–10 ms/window
OT memory increment:    much less than 10 MB
```

Therefore:

\[
\frac{\text{cost(M2)}}{\text{cost(M0)}}\approx1.00\text{–}1.01.
\]

The essential conclusion remains:

> Once independent node scores exist, M2 graph matching is nearly free. It changes how the evidence is jointly allocated, not how many VLM node evaluations are made.

---

## 8. Wider-window rescue

The base production estimate above excludes rescue.

If a 3× or 5× wider window is processed, that wider window requires a new eight-frame evidence set and another M2 node batch. Local graph retrieval remains negligible.

Let:

```text
r3 = fraction of windows that run 3× rescue
r5 = fraction of all windows that also run 5× rescue
```

Then:

\[
E[N_{\text{logical}}]
=22(1+r_3+r_5).
\]

Approximate latency:

\[
E[T]\approx T_{M2}(1+r_3+r_5).
\]

Examples:

| Rescue policy | Calls/window | Estimated latency/window |
|---|---:|---:|
| No rescue | 22 | 2.5–6.0 s |
| 15% use 3×, 5% use 5× | 26.4 | 3.0–7.2 s |
| 25% use 3×, 10% use 5× | 29.7 | 3.4–8.1 s |
| Every window uses both 3× and 5× | 66 | 7.5–18 s |

For production, rescue should be restricted to a small uncertain subset or replaced by a local temporal model.

---

## 9. Revised CGSGM call count

### 9.1 Assumption requested here

A 96-frame window is divided into 8-frame semantic units:

\[
T=96/8=12.
\]

For each 8-frame unit, **one structured VLM prompt returns all five components for all visible subjects**:

```text
action
scene
accessory
appearance
global summary
```

Therefore the number of calls no longer scales with the number of subjects:

\[
N_{\text{CGSGM}}=12\ \text{logical VLM calls/window}.
\]

This replaces the previous central estimate of 24 calls, which assumed one combined-component prompt per subject.

### 9.2 Physical batching

The 12 temporal units have different visual inputs, so they do not share one identical visual prefix. They can nevertheless be processed as one batch:

```text
logical semantic calls/window:  12
vision items/window:            12 representative temporal-unit images
vision encoder batches:         1, if all 12 fit in one batch
structured decoder batches:     1, or 2 microbatches
```

This assumes one representative frame or compact visual input per 8-frame semantic unit. If every unit sends all eight raw frames, the visual workload becomes 96 images and the estimate is no longer valid.

### 9.3 CGSGM latency

A CGSGM semantic response is longer than a node response because it describes all subjects and five components. A reasonable output range is:

```text
250–450 output tokens/temporal unit
12 units -> approximately 3,000–5,400 output tokens/window
```

At 448×252 and with batching:

| Stage | Estimated time/window |
|---|---:|
| Decode/resize 12 representative frames | 0.08–0.25 s |
| Batched vision encoding | 0.30–0.90 s |
| Batched multimodal prefill and generation | 2.2–5.4 s |
| Local CGSGM prediction and anomaly scoring | <0.10 s |
| **Total** | **3.0–7.0 s/window** |

Central planning value:

```text
approximately 4.5–5.0 seconds/window
```

### 9.4 CGSGM memory

```text
logical batch size:        12 temporal units
visual inputs:             12 distinct images
estimated process peak:    23–30 GB
incremental window memory: approximately 2–4 GB
```

### 9.5 If descriptions are precomputed

If all subject/component descriptions or their embeddings are generated once and stored, online CGSGM inference needs:

```text
0 VLM calls/window
```

Only the local CGSGM network and score computation remain, generally well below 0.1 seconds/window.

### 9.6 Alternative one-call whole-window design

It is technically possible to prompt one VLM call with all 12 temporal positions and ask it to output all subjects and all five components for the entire 96-frame window:

```text
1 logical call/window
```

However, this is a changed CGSGM design. Its JSON is much longer, temporal omissions may increase, and it is not the main estimate in this note.

---

## 10. Consolidated revised estimates

### 10.1 Base inference without rescue

| Design | Logical VLM calls/window | Vision passes | Estimated latency/window | Estimated process peak |
|---|---:|---:|---:|---:|
| M0 independent nodes, optimized | ≈22 | 1 | 2.5–6.0 s | 22–29 GB |
| **M2 Unary OT, optimized** | **≈22** | **1** | **2.5–6.0 s** | **22–29 GB** |
| CGSGM, all subjects/components together per 8-frame unit | 12 | 1 batched pass over 12 images | 3.0–7.0 s | 23–30 GB |
| CGSGM with cached descriptions | 0 | 0 online | <0.1 s | local-model dependent |

### 10.2 Central planning values

```text
M2 Unary OT:
    22 logical node evaluations
    one shared eight-frame visual encoding
    approximately 4 seconds/window
    use 5 seconds/window for conservative scheduling

CGSGM combined-subject/component prompting:
    12 logical temporal-unit evaluations
    approximately 4.5–5 seconds/window
```

### 10.3 Cost comparison

```text
M2 versus M0 independent nodes:
    same VLM calls
    same visual input
    same batched decoder workload
    less than approximately 1% additional cost

CGSGM versus optimized M2:
    fewer logical prompts, 12 versus 22
    but different visual inputs for 12 temporal units
    longer structured outputs
    therefore similar overall latency order
```

Call count alone should not be used as a latency proxy. M2 has more short prompts that share one visual prefix; CGSGM has fewer but longer outputs and less prefix sharing.

---

## 11. Whole-run planning example

For 44,436 windows, using the conservative central M2 value of 5 seconds/window:

\[
44{,}436\times5\ \text{s}
=222{,}180\ \text{s}
\approx61.7\ \text{GPU-hours}.
\]

Using the full estimated range:

```text
2.5 s/window -> approximately 30.9 GPU-hours
6.0 s/window -> approximately 74.1 GPU-hours
```

Continuous batching of multiple windows can reduce wall-clock time, but it does not reduce the corresponding GPU-work estimate proportionally. A practical three-window pipeline might finish in roughly 18–35 wall-clock hours after tuning, rather than the several-day serial/API behavior of the current research code.

---

## 12. Required implementation changes for these estimates to hold

The current archive does not automatically realize all assumptions. The production implementation needs:

1. **Explicit image cap**

```python
resize to 448×252 before cv2.imwrite
# or configure max_pixels = 144 * 28 * 28 per image
```

2. **Local graph retrieval**

```text
all 39 graph descriptions -> cached text embeddings
one cached window visual embedding -> top 4 abnormal + top 6 normal
no selector VLM call
```

3. **One vision-encoder pass per window**

```text
encode T0...T7 once
reuse projected image tokens / multimodal prefix
```

4. **Batched independent-node requests**

```text
approximately 22 node prompts in one batch or two microbatches
```

5. **Compact output schema**

```text
retain p_i, L_i, Q_i and a short evidence string
cap generation length
```

6. **M2-only path**

```text
skip conditional refinement and all research diagnostics
```

Without these changes, the current serial archive can remain tens of seconds per window despite using M2 mathematics.

---

## 13. Benchmark protocol for replacing estimates

Use 100 representative windows after a 20-window warm-up.

Measure separately:

```text
frame decode + resize
vision encoder
shared prefix prefill
batched node prefill
batched node decode
JSON parsing
M2 Sinkhorn and graph aggregation
peak torch memory
server-reserved memory
```

Recommended test matrix:

```text
resolution: 448×252, 588×336
node batch: 11, 22
window concurrency: 1, 2, 3, 4
output cap: 96, 128, 160 tokens/node
```

Report:

```text
p50 and p95 latency/window
windows/second
logical VLM calls/window
vision passes/window
output tokens/window
peak allocated GB
peak reserved GB
```

The measured values should replace the ranges in this note before final system reporting.

---

## 14. Source basis and confidence

### Code-derived, high confidence

- Current v3 uses eight exact evidence frames.
- Active inference selects 4 abnormal and 6 normal graphs.
- The active library contains 17 abnormal and 22 normal graphs.
- A 4+6 shortlist contains about 22 unique semantic nodes on average.
- M2 reuses independent-node outputs and adds no VLM calls.
- The current archive does not resize extracted frames before sending them.

### Official model/hardware basis

- Qwen2.5-VL supports dynamic resolution and explicit `min_pixels`/`max_pixels`; its official model card recommends using a bounded visual-token range to balance performance and cost.
- The official model card recommends FlashAttention 2 for acceleration and memory savings in multi-image/video workloads.
- NVIDIA TensorRT-LLM reports more than 6,000 tokens/s for an optimized FP16 Llama-3.1-8B workload on A100-SXM4-80GB under high-throughput conditions. This is used only as an upper-bound reference; the VLM estimate is intentionally lower.

### Estimate confidence

| Quantity | Confidence |
|---|---|
| 22 logical M2 node evaluations/window | High |
| M2 adds no VLM calls over M0 | High |
| 12 CGSGM calls/window under the stated combined prompt | High, conditional on the stated prompting design |
| 448×252 visual-token calculation | High |
| 22–29GB process peak | Medium |
| 2.5–6.0 s optimized M2 latency | Medium-low until measured on the target server |
| 3.0–7.0 s optimized CGSGM latency | Medium-low until measured |

