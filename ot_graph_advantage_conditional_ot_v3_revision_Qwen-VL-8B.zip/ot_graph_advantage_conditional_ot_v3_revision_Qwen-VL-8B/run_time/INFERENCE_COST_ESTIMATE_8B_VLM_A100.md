# Inference-Cost Estimate for an 8B VLM on A100 80GB

## Graph matching, independent-node matching, wider-window reasoning, and CGSGM subject descriptions

**Status:** engineering estimate, not a measured benchmark  
**Target code:** `ot_graph_advantage_conditional_ot_v3_revision`  
**Target hardware:** one NVIDIA A100 80GB, preferably SXM; PCIe is slightly slower  
**Reference VLM class:** Qwen2.5-VL-7B / an approximately 8B multimodal decoder  
**Window:** 96 frames, represented by the current code as eight deterministic images `T0...T7`

---

## 1. Direct answer: is an LLM needed at inference?

No separate language-only LLM is needed when:

```text
the graph library has already been discovered and frozen;
no new graph is generated during inference;
no error-driven graph revision is requested;
only graph scores and anomaly scores are required.
```

In that setting:

```text
8B VLM                    required for visual scoring in the current implementation
DeepSeek / teacher LLM    not required
Optimal transport         local numerical computation, no model call
Graph-score aggregation   local numerical computation, no model call
Anomaly-score computation local numerical computation, no model call
```

Use the following deployment settings:

```bash
DISCOVER_GRAPHS=0 \
RUN_BLIND_VERIFIER=0 \
RUN_LEAVE_ONE_OUT=0
```

The current active development wrapper enables the blind verifier and leave-one-node-out analysis because it is designed to prove graph advantages. Those calls should be disabled in production scoring.

One qualification is important: the present v3 code still uses the **VLM itself** for graph candidate retrieval. This is not a separate LLM, but it is one additional VLM call per window. Candidate retrieval can later be replaced by a local image-text retriever or a fixed shortlist.

---

## 2. Assumptions behind the estimates

The estimates below use the following controlled configuration.

### 2.1 Model and precision

```text
Model size                     approximately 7–8B parameters
Weight precision               BF16/FP16
Inference engine               optimized vLLM, SGLang, or TensorRT-style server
GPU                            A100 80GB SXM, TP=1
Batch-1 output speed           approximately 70–120 output tokens/s
```

The output-token speed is an engineering range inferred from official A100/TensorRT-LLM measurements for 6–8B text decoders. A VLM is slower than a text-only model because each request also runs a vision encoder.

### 2.2 Visual input

The current code sends the same eight exact frames to every VLM call. For a practical local deployment, explicitly cap each image to approximately:

```text
256 visual tokens/image × 8 images = 2,048 visual tokens/request
```

Qwen2.5-VL supports a configurable range of roughly 256–1,280 visual tokens per image. The current code sets high-resolution mode; without an explicit cap, original 720p/1080p frames can make runtime much higher than the main estimates below.

### 2.3 Active graph shortlist

The current active wrapper uses:

```text
final abnormal graphs/window     4
final normal graphs/window       6
conditional graph calls/window  10
selector ranking pool            8 abnormal + 12 normal
```

The active graph catalog contains:

```text
17 abnormal graphs
22 normal graphs
39 total graphs
```

From the current graph catalog, a random `4 abnormal + 6 normal` shortlist contains on average:

```text
22.12 node instances
21.97 unique semantic nodes
10th / 50th / 90th percentiles of unique nodes: 20 / 22 / 23
```

Therefore, the central call-count estimate uses **22 independent node calls per window**.

For the smaller historical `2 abnormal + 4 normal` setting, the corresponding average is about **13 unique nodes**.

---

## 3. What the current code calls for one window

For one 96-frame window, the current v3 path is:

```text
1. VLM candidate-graph selector
2. One independent VLM call for every unique node in the selected graphs
3. Local M0 node score
4. Local M1 shared row-max score
5. Local M2 Unary OT score
6. One conditional VLM call for every selected graph
7. Local M3a conditional row-max
8. Local M3b conditional OT without coherence
9. Local M3c conditional OT with coherence
10. Local abnormal-vs-normal graph competition
```

Steps 3–5 and 7–10 do not require VLM calls.

### 3.1 Deployment call count: current active `4A + 6N`

Let:

```text
N_r = selector calls, normally 1
N_u = number of unique shortlisted nodes, average ≈22
N_g = number of shortlisted graphs, 4+6=10
```

Then:

| Method | Formula | Average VLM calls/window |
|---|---:|---:|
| Independent nodes, M0 | `N_r + N_u` | **≈23** |
| Shared row-max, M1 | `N_r + N_u` | **≈23** |
| Unary OT graph matching, M2 | `N_r + N_u` | **≈23** |
| Conditional row-max, M3a | `N_r + N_u + N_g` | **≈33** |
| Conditional OT, M3b/M3c | `N_r + N_u + N_g` | **≈33** |

If graph retrieval is local or the shortlist is fixed, subtract one call:

```text
M0/M1/M2: approximately 22 calls/window
M3a/M3b/M3c: approximately 32 calls/window
```

A selector-repair call is issued only when the first shortlist is invalid. If its rate is `r_repair`, add `r_repair` to the expected call count.

### 3.2 Smaller `2A + 4N` setting

| Method | Average VLM calls/window |
|---|---:|
| M0/M1/M2 | **≈14** including selector; ≈13 without selector |
| M3a/M3b/M3c | **≈20** including selector; ≈19 without selector |

### 3.3 Diagnostics that must be disabled for deployment

If enabled, the current development code may add:

```text
blind verifier:                  +1 call on a discordant M0/M3c window
leave-one-node-out analysis:     +K calls on that window, usually K=2 or 3
DeepSeek graph discovery:        LLM calls on selected failures
```

For discordance rate `d` and average chosen graph size `K≈2.3`, verifier plus leave-one-out adds approximately:

\[
\Delta N \approx d(1+K) \approx 3.3d.
\]

Examples:

```text
d=10%  -> about +0.33 VLM calls/window on average
d=20%  -> about +0.66 VLM calls/window on average
```

This average looks small, but the affected windows become much slower individually. These analyses are unnecessary when only anomaly scores are wanted.

---

## 4. Prompt and token workload in the current code

The current prompt templates were measured directly from the attached code and active 39-graph catalog.

### 4.1 Text prompt size before adding visual tokens

| Call type | Measured prompt size | Rough tokenizer range |
|---|---:|---:|
| Graph selector | 33,686 characters / 3,970 words | **≈5,200–8,400 text tokens** |
| Independent node | mean 1,621 characters / 204 words | **≈265–405 text tokens** |
| Conditional 2-node graph | mean 5,461 characters / 534 words | **≈694–1,365 text tokens** |
| Conditional 3-node graph | mean 7,374 characters / 688 words | **≈894–1,844 text tokens** |

The selector is disproportionately expensive because the prompt renders the full graph catalog and asks the VLM to return a larger ranked candidate pool.

### 4.2 Typical generated JSON size

From the current output schemas and mock records:

| Call type | Approximate output tokens |
|---|---:|
| Selector, 8 abnormal + 12 normal candidates | **≈500–800** |
| Independent node | **≈100–180** |
| Conditional 2-node graph | **≈350–500** |
| Conditional 3-node graph | **≈500–700** |

The conditional graph stage is costly mainly because it generates a structured record for every node, not because OT itself is expensive.

### 4.3 Repeated visual processing

At 256 visual tokens per frame:

```text
one VLM call    8 × 256 = 2,048 visual tokens
M0/M2           23 calls ≈ 47,000 repeated visual tokens/window
M3c             33 calls ≈ 67,600 repeated visual tokens/window
```

At 1,280 visual tokens per frame, these figures become approximately five times larger. This is why explicit image-token limits and visual-prefix reuse matter more than optimizing the Sinkhorn solver.

---

## 5. A100 80GB latency estimate per VLM call

The following estimates assume:

```text
A100 SXM 80GB
BF16/FP16 8B-class VLM
8 frames capped at 256 visual tokens/frame
FlashAttention / optimized serving
batch size 1 for latency
compact JSON output
no network/API latency
```

| Call type | Estimated latency/call |
|---|---:|
| Candidate selector | **5–10 s** |
| Independent node | **1.3–2.4 s** |
| Conditional graph | **3.8–6.5 s** |
| Local Sinkhorn OT and score aggregation | **<1–10 ms** |

These are broad engineering estimates. The output length, not only model FLOPs, is important: the selector may generate about 600 tokens, while a conditional graph may generate 400–700 tokens.

---

## 6. Estimated end-to-end latency per 96-frame window

### 6.1 Current code, calls executed serially within one window

The current `WindowMatcher.match()` loops through nodes and graphs serially. `ASYNC_WORKERS` creates concurrency across windows, not true parallel node calls inside one window.

#### Active `4 abnormal + 6 normal` configuration

| Method | Calls | Estimated single-window latency |
|---|---:|---:|
| M0 independent nodes | ≈23 | **34–63 s** |
| M1 shared row-max | ≈23 | **34–63 s** |
| M2 Unary OT | ≈23 | **34–63 s** |
| M3a conditional row-max | ≈33 | **72–128 s** |
| M3b/M3c full conditional OT | ≈33 | **72–128 s** |

A reasonable central planning value is:

```text
M0/M2: approximately 50–60 seconds/window
M3c:   approximately 100–115 seconds/window
```

#### Smaller `2 abnormal + 4 normal` configuration

| Method | Calls | Estimated latency |
|---|---:|---:|
| M0/M2 | ≈14 | **22–41 s** |
| M3c | ≈20 | **45–80 s** |

### 6.2 Plain Hugging Face eager execution

A basic `transformers.generate()` loop without an optimized serving engine, batching, CUDA graphs, or visual-prefix reuse can be approximately **1.5–2.5× slower** than the ranges above.

### 6.3 Current high-resolution behavior without an explicit token cap

If the eight original frames are processed near 768–1,280 visual tokens per image rather than 256:

```text
M0/M2: approximately 60–140 s/window
M3c:   approximately 120–280 s/window
```

The exact multiplier is not linear because decoding cost is unchanged, but vision encoding and prefill increase substantially.

### 6.4 With three asynchronous windows

With `ASYNC_WORKERS=3`, three windows can be in flight. On one local A100 with dynamic batching, aggregate throughput may improve by roughly **1.8–2.5×**, not a perfect 3×. Individual request latency may increase because the GPU is shared.

Approximate aggregate throughput under the capped-resolution configuration:

| Method | Estimated throughput on one A100 |
|---|---:|
| M0/M2 | **100–270 windows/hour** |
| M3c | **50–125 windows/hour** |

These values are more useful for dataset planning than simply dividing single-request latency by three.

---

## 7. GPU memory estimate

### 7.1 Model-resident memory

For an approximately 8B BF16 VLM:

```text
raw BF16 weights                         about 16 GB
runtime, CUDA kernels, buffers           about 2–6 GB
model-resident total before a request    about 19–25 GB
```

An 8-bit weight version generally reduces the weight portion to roughly 8–10GB, but its graph/node score calibration must be revalidated.

### 7.2 Decoder KV-cache calculation

For the official Qwen2.5-VL-7B text decoder configuration:

```text
28 layers
4 key/value heads
head dimension 128
BF16, 2 bytes/value
```

KV memory per token is approximately:

\[
28\times 2_{K,V}\times4\times128\times2\ \text{bytes}
=57,344\ \text{bytes/token}
\approx56\ \text{KiB/token}.
\]

Examples:

| Decoder context | KV cache/request |
|---:|---:|
| 3,000 tokens | ≈164 MiB |
| 8,000 tokens | ≈438 MiB |
| 12,000 tokens | ≈656 MiB |
| 20,000 tokens | ≈1.09 GiB |

The selector normally has the largest text context. Vision-encoder activations and image preprocessing use additional transient memory.

### 7.3 Practical peak memory

With eight frames capped to about 256 visual tokens each:

| Serving condition | Approximate total GPU memory |
|---|---:|
| One independent-node request | **21–29 GB** |
| One selector or conditional request | **23–32 GB** |
| Three concurrent in-flight requests | **30–50 GB** |

With eight high-resolution frames near the upper visual-token range:

| Serving condition | Approximate total GPU memory |
|---|---:|
| One request | **30–45 GB** |
| Three concurrent requests | **50–75 GB**, with OOM risk depending on engine reservation |

### 7.4 What “memory per window” really means

The memory is **not** multiplied by 23 or 33, because current calls are serial inside a window and each call releases its transient KV/activation state.

A useful decomposition is:

```text
shared resident model memory       19–25 GB
incremental active-request memory   roughly 1–5 GB at capped resolution
peak total for one window           roughly 23–32 GB
```

vLLM commonly reserves a large fraction of GPU memory for its paged KV cache. Therefore `nvidia-smi` may show 65–75GB allocated even when the true incremental memory for one window is much smaller. That is allocator reservation, not 70GB of unique state per window.

---

## 8. Cost comparison: graph matching versus node matching

### 8.1 M2 Unary OT versus independent nodes

This is the most important cost result:

> **Unary OT graph matching has essentially the same VLM cost as independent-node matching.**

M0 and M2 reuse exactly the same selector result and independent node outputs. M2 adds only a small local Sinkhorn solve over matrices roughly of size:

```text
(K+1) × (M+1)
```

where `K` is usually 2–3 nodes in one graph and `M=16` evidence slots. This adds milliseconds, not seconds.

| Comparison | VLM calls | Latency ratio | Peak-memory ratio |
|---|---:|---:|---:|
| M2 Unary OT / M0 nodes | same | **≈1.00–1.02×** | **≈1.00×** |

Therefore, if M2 gives a useful accuracy gain, it is nearly free at inference once node scores already exist.

### 8.2 Full M3c conditional graph matching versus independent nodes

M3c adds one joint conditional VLM call for each shortlisted graph:

```text
10 extra calls in the current 4A+6N configuration
6 extra calls in the smaller 2A+4N configuration
```

| Comparison | Call-count ratio | Estimated latency ratio | Peak-memory ratio |
|---|---:|---:|---:|
| M3c / M0, 4A+6N | 33/23 = **1.43×** | **≈1.8–2.2×** | **≈1.0–1.15×** sequential |
| M3c / M0, 2A+4N | 20/14 = **1.43×** | **≈1.7–2.1×** | **≈1.0–1.15×** sequential |

Latency grows more than call count because a conditional graph response is longer than an independent-node response.

### 8.3 GPU-hour and energy formulas

If the GPU rental price is `R` currency units per GPU-hour, the cost/window is:

\[
\text{cost/window}=R\times \frac{\text{latency seconds}}{3600}.
\]

For A100 SXM at approximately 400W, the idealized energy/window is:

\[
E_{Wh}=400\times\frac{\text{latency seconds}}{3600}.
\]

Using the main ranges:

| Method | GPU time/window | Energy/window at 400W |
|---|---:|---:|
| M0/M2 | 34–63 s | **3.8–7.0 Wh** |
| M3c | 72–128 s | **8.0–14.2 Wh** |

These are upper-bound device-energy estimates and exclude CPU, storage, and cooling.

---

## 9. Wider-window reasoning

The current OT-v3 active inference path does **not** perform the legacy 3×/5× wider-window rescue. Therefore the main call counts above contain no wider-window calls.

If the whole graph pipeline is rerun on wider windows, let:

```text
C0 = base calls/window
r3 = fraction of windows receiving 3× rescue
r5 = fraction receiving an additional 5× rescue
```

Then approximately:

\[
E[C]=C_0(1+r_3+r_5).
\]

For full M3c with `C0≈33`:

| Rescue policy | Average calls/window |
|---|---:|
| None | 33 |
| 20% first rescue, 5% second rescue | **≈41.3** |
| 30% first rescue, 10% second rescue | **≈46.2** |
| Every window receives both rescues | **99** |

The corresponding latency scales similarly unless the shortlist, node scores, or visual embeddings are reused.

A cheaper rescue design is:

```text
reuse the original shortlist;
rerun only the winning abnormal and normal graphs;
reuse cached image embeddings;
run rescue only when the abnormal-normal margin is near zero.
```

That avoids multiplying the full 33-call pipeline.

---

## 10. Recommended production configuration

The present code is a research ablation framework. For practical inference, the highest-value optimizations are:

### 10.1 Keep M2 when possible

```text
M0 independent node scores
    + local Unary OT
    -> graph score
```

M2 has almost no incremental VLM cost and was the strongest measured ablation in the current study.

### 10.2 Disable research-only calls

```bash
DISCOVER_GRAPHS=0
RUN_BLIND_VERIFIER=0
RUN_LEAVE_ONE_OUT=0
```

### 10.3 Replace VLM graph retrieval

The current selector prompt is about 34k characters and generates a long ranked list. Replace it with one of:

```text
fixed graph shortlist by deployment domain;
local CLIP/image-text retrieval;
a small trained graph retriever;
cache the shortlist for overlapping windows;
retrieve once per video scene, not once per 96-frame window.
```

This removes one of the most expensive calls.

### 10.4 Cache the eight visual embeddings

The same eight images are currently re-encoded for every node and every graph call. A production server should compute the vision features once and reuse the multimodal prefix for all prompts belonging to that window.

Expected effect:

```text
large reduction in vision-encoder time;
smaller memory traffic;
identical visual evidence across methods;
no change to the graph mathematics.
```

### 10.5 Batch prompts of the same type

Instead of issuing 22 independent node calls serially:

```text
batch all independent-node prompts for one or several windows;
batch conditional prompts of similar length;
use continuous batching in vLLM/SGLang/TensorRT-LLM.
```

With local retrieval, visual-prefix reuse, compact JSON and batching, a reasonable target—not the current implementation—is:

| Optimized target | Estimated latency/window |
|---|---:|
| M0/M2 | **3–8 s** |
| M3c | **7–18 s** |

This target requires engineering changes; it is not the expected speed of the current serial code.

---

## 11. CGSGM subject-centered VLM descriptions

The available implementation reference states that Stage I decomposes each subject-centered region into five semantic components:

```text
action
scene
accessory
appearance
global summary
```

CGSGM then predicts the expected normal global summary from the local semantic components. The CGSGM neural predictor itself is local and does **not** require a VLM call. The VLM calls are used to produce the semantic descriptions/embeddings.

The exact call count depends on how those five components are prompted. The original Stage-I generation code is not included in the current OT archive, so the rigorous estimate is given parametrically.

Let:

```text
T = number of temporal semantic units in one 96-frame window
S_t = number of retained subject tracks/crops in temporal unit t
C = VLM calls per subject crop
```

If semantic embeddings are produced every eight frames:

\[
T=96/8=12.
\]

Then:

\[
N_{CGSGM}=C\sum_{t=1}^{12}S_t + N_{global}.
\]

### 11.1 Recommended and likely implementation

One structured VLM call returns all five semantic components for one subject crop:

```text
C=1
```

Assuming an average of two retained subjects per eight-frame unit:

```text
12 temporal units × 2 subjects = approximately 24 VLM calls/window
```

Reasonable scenarios:

| Average retained subjects per 8-frame unit | Calls/window, one combined component prompt |
|---:|---:|
| 1 | **12** |
| 2 | **24** |
| 3 | **36** |
| 4 | **48** |

If one additional full-scene description is generated for every temporal unit, add 12 calls.

### 11.2 Inefficient separate-component implementation

If action, scene, accessory, appearance and global summary are queried separately:

```text
C=5
```

For two subjects per unit:

```text
12 × 2 × 5 = 120 calls/window
```

This should be avoided. All five components should be returned in one structured response.

### 11.3 Subject tracklets spanning the full 96-frame window

If subjects are tracked across the whole window and described once per track rather than once per eight-frame unit, the cost can drop to:

```text
approximately 1–4 calls/window
```

This is a different temporal design from the existing eight-frame semantic granularity.

### 11.4 Offline-cache case

If CGSGM semantic descriptions are precomputed once and loaded from PKL/embedding files, online inference uses:

```text
0 VLM calls/window for description generation
```

Only the local CGSGM and anomaly-scoring model run online.

### 11.5 Central CGSGM estimate

Under the most plausible combined-prompt, eight-frame-granularity assumption:

```text
average CGSGM description calls/window: about 24
reasonable range: 12–36
confidence: medium-low, because the exact original description-generation loop is not in the current archive
```

This is the same order as M0/M2 under the current 4A+6N graph shortlist and lower than full M3c.

---

## 12. Consolidated comparison

### 12.1 VLM calls and latency

| Inference design | Average VLM calls/window | Estimated A100 latency/window |
|---|---:|---:|
| M0 independent nodes, 4A+6N | ≈23 | 34–63 s |
| M2 Unary OT, 4A+6N | ≈23 | 34–63 s |
| M3c conditional OT, 4A+6N | ≈33 | 72–128 s |
| M0/M2, 2A+4N | ≈14 | 22–41 s |
| M3c, 2A+4N | ≈20 | 45–80 s |
| CGSGM, 2 subjects × 12 units, combined prompt | ≈24 | roughly 20–50 s, depending on crop size/output |
| CGSGM with cached descriptions | 0 | local model only |

### 12.2 Relative cost

```text
Unary OT versus independent nodes:
    essentially free after node scores exist

Full conditional OT versus independent nodes:
    approximately 43% more VLM calls
    approximately 80–120% more latency in the current serial code
    little increase in peak memory because calls are sequential

CGSGM:
    cost scales with number of subject-time crops, not number of graphs
```

---

## 13. How to replace these estimates with measurements

A rigorous benchmark on the actual machine should log each call type separately.

For every request, record:

```text
call_type: selector | independent_node | conditional_graph | verifier | rescue
graph_key or node_key
input_text_tokens
visual_tokens
output_tokens
vision_encoder_ms
prefill_ms
time_to_first_token_ms
decode_ms
total_ms
peak_allocated_bytes
peak_reserved_bytes
cache_hit
```

Per window, report:

```text
total VLM calls
call count by type
sum GPU service time
wall-clock latency
peak GPU memory
number of graph candidates
number of unique nodes
whether rescue/verifier/LOO fired
```

Recommended benchmark conditions:

```text
50–100 windows
warm-up first 5 windows and exclude them
batch/concurrency = 1, 2, 3, 8
visual-token cap = 256, 512, 1,280 per image
BF16 and one validated 8-bit configuration
M0, M2 and M3c on exactly the same windows
```

The key deployment metric should be:

```text
GPU-seconds per window at a fixed AP/balanced-accuracy level
```

not only raw VLM calls.

---

## 14. Confidence and limitations

### High-confidence quantities

```text
current code call structure;
4A+6N and 2A+4N call-count formulas;
current catalog node-count averages;
prompt character/word sizes measured from the attached code;
M2's negligible local OT cost relative to a VLM call;
no DeepSeek requirement when discovery is disabled;
Qwen decoder KV-cache formula from the official model configuration.
```

### Medium-confidence quantities

```text
A100 latency ranges;
vision-encoder transient memory;
concurrency throughput improvement;
high-resolution slowdown factor.
```

These depend strongly on the local inference engine, output-token limits, frame resolution, FlashAttention, prefix caching, and batching.

### Lower-confidence quantity

```text
CGSGM average calls/window
```

The method description specifies subject-centered five-component semantics and eight-frame embeddings, but the exact original VLM call loop is not present in the attached inference code. The document therefore gives a formula, scenarios and a clearly stated central assumption rather than presenting a false exact count.

---

## 15. Source basis

1. Current attached `ot_graph_advantage_conditional_ot_v3_revision` code, especially:
   - `run_ot_graph_advantage_active_v3.sh`
   - `tools/live_matching.py`
   - `tools/prompts.py`
   - `tools/vlm_runtime.py`
   - active `graph_catalog_v2.json`
2. Internal `ALGORITHMS_AND_IMPLEMENTATION` reference for the Part A+C inference flow and CGSGM semantic components.
3. NVIDIA official A100 80GB specifications.
4. NVIDIA TensorRT-LLM official A100 performance tables for 6–8B text decoders.
5. Qwen official Qwen2.5-VL-7B model card and `config.json`, including dynamic visual-token ranges and decoder dimensions.

