@echo off
setlocal
set CONDA_BAT=H:\Software\anaconda\install\condabin\conda.bat
set ENV_NAME=ot_qwen_gpu
if not "%~1"=="" set ENV_NAME=%~1
if not exist "%CONDA_BAT%" (
  echo ERROR: conda.bat not found at %CONDA_BAT%
  exit /b 2
)
call "%CONDA_BAT%" create -n "%ENV_NAME%" python=3.12 -y
if errorlevel 1 exit /b %ERRORLEVEL%
call "%CONDA_BAT%" activate "%ENV_NAME%"
python -m pip install --upgrade pip
python -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cu126
python -m pip install "transformers>=4.57.0,<5" accelerate safetensors sentencepiece pillow opencv-python numpy scipy scikit-learn pytest
if errorlevel 1 exit /b %ERRORLEVEL%
echo.
echo Installed environment: %ENV_NAME%
echo Native Windows uses PyTorch SDPA by default. FlashAttention 2 is optional and is not
echo installed here because its native-Windows build is not reliably available.
endlocal
