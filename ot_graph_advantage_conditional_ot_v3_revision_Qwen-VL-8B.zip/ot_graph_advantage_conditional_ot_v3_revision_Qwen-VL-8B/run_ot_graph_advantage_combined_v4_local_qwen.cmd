@echo off
setlocal
set SCRIPT_DIR=%~dp0
set PYTHON_EXE=H:\Software\anaconda\install\envs\ot_qwen_gpu\python.exe
if not exist "%PYTHON_EXE%" set PYTHON_EXE=H:\Software\anaconda\install\envs\normal_graph_gpu\python.exe
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%run_ot_graph_advantage_combined_v4_local_qwen.ps1" -Python "%PYTHON_EXE%" %*
exit /b %ERRORLEVEL%
