#!/usr/bin/env python3
"""Fail-fast verification for local Qwen3-VL/Qwen3 graph experiments."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from local_qwen_backend import assert_model_complete, expected_weight_files


def model_status(path: Path, label: str, required: bool) -> dict:
    expected = expected_weight_files(path)
    missing = [str(item) for item in expected if not item.is_file()]
    value = {
        "label": label,
        "path": str(path),
        "required": required,
        "config_exists": (path / "config.json").is_file(),
        "expected_weight_shards": len(expected),
        "missing_weight_shards": missing,
        "partial_downloads": [str(item) for item in path.glob("*.crdownload")],
        "complete": (path / "config.json").is_file() and not missing,
    }
    if required:
        assert_model_complete(path, label)
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--vlm-dir", type=Path, default=Path("G:/Qwen3-VL-8B"))
    parser.add_argument("--llm-dir", type=Path, default=Path("G:/Qwen3-8B"))
    parser.add_argument("--clip-dir", type=Path, default=Path("G:/Dataset/XDViolence/videos/clip-vit-large-patch14"))
    parser.add_argument("--require-llm", action="store_true")
    parser.add_argument("--require-clip", action="store_true")
    args = parser.parse_args()

    import cv2
    import torch
    import transformers
    from transformers import Qwen3VLForConditionalGeneration

    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA is unavailable in this Python. On this machine Windows sees the A100s "
            "while WSL currently does not, so use the native Windows runner."
        )
    gpus = []
    for index in range(torch.cuda.device_count()):
        free_bytes, total_bytes = torch.cuda.mem_get_info(index)
        gpus.append({
            "index": index,
            "name": torch.cuda.get_device_name(index),
            "free_gib": free_bytes / 1024**3,
            "total_gib": total_bytes / 1024**3,
        })
    result = {
        "python": sys.executable,
        "python_version": sys.version,
        "torch": torch.__version__,
        "torch_cuda": torch.version.cuda,
        "transformers": transformers.__version__,
        "opencv": cv2.__version__,
        "qwen3_vl_class_available": Qwen3VLForConditionalGeneration is not None,
        "gpus": gpus,
        "models": [
            model_status(args.vlm_dir, "Qwen3-VL", True),
            model_status(args.llm_dir, "Qwen3 text", args.require_llm),
            {
                "label": "CLIP retriever",
                "path": str(args.clip_dir),
                "required": args.require_clip,
                "complete": (args.clip_dir / "config.json").is_file()
                and ((args.clip_dir / "model.safetensors").is_file() or (args.clip_dir / "pytorch_model.bin").is_file()),
            },
        ],
    }
    if args.require_clip and not result["models"][-1]["complete"]:
        raise FileNotFoundError(f"incomplete CLIP model: {args.clip_dir}")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
