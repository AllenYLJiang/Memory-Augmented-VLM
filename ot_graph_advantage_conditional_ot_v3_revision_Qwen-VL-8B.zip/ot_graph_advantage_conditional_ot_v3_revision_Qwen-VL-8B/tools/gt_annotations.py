#!/usr/bin/env python3
"""Frame-level XD-Violence ground truth used by the OT experiment.

The project-wide operational rule is ``max overlap with one merged anomaly interval >= 8``.
A second core-event label (strictly more than two thirds of the window anomalous) is retained
for structural analyses.  Main metrics and graph discovery must use the operational label.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Mapping, Sequence, Tuple

Interval = Tuple[int, int]


def merge_intervals(intervals: Sequence[Interval]) -> List[Interval]:
    values = sorted((int(a), int(b)) for a, b in intervals)
    merged: List[Interval] = []
    for start, end in values:
        if not merged or start > merged[-1][1] + 1:
            merged.append((start, end))
        else:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
    return merged


def load_annotations(path: Path) -> Dict[str, List[Interval]]:
    annotations: Dict[str, List[Interval]] = {}
    with Path(path).open("r", encoding="utf-8") as handle:
        for line_no, raw in enumerate(handle, 1):
            parts = raw.strip().split()
            if not parts:
                continue
            if len(parts) < 3 or (len(parts) - 1) % 2:
                raise ValueError(f"invalid annotation line {line_no}: {raw.rstrip()}")
            values = [int(value) for value in parts[1:]]
            intervals = []
            for index in range(0, len(values), 2):
                start, end = values[index], values[index + 1]
                if start < 0 or end < start:
                    raise ValueError(f"invalid interval on line {line_no}: {start} {end}")
                intervals.append((start, end))
            annotations[parts[0]] = merge_intervals(intervals)
    return annotations


def _overlap(start: int, end: int, other_start: int, other_end: int) -> int:
    return max(0, min(end, other_end) - max(start, other_start) + 1)


def label_window(
    video_id: str,
    start_frame: int,
    end_frame: int,
    annotations: Mapping[str, Sequence[Interval]],
    min_overlap_frames: int = 8,
    core_overlap_threshold: float = 2.0 / 3.0,
) -> dict:
    start, end = int(start_frame), int(end_frame)
    if end < start:
        raise ValueError(f"invalid frame span: {start}-{end}")
    intervals = merge_intervals([(int(a), int(b)) for a, b in annotations.get(str(video_id), [])])
    window_frames = end - start + 1
    overlaps = [_overlap(start, end, a, b) for a, b in intervals]
    max_overlap = max(overlaps, default=0)
    # Intervals are merged/non-overlapping, so the sum is the union overlap.
    union_overlap = sum(overlaps)
    overlap_fraction = union_overlap / float(window_frames)
    operational = int(max_overlap >= max(1, int(min_overlap_frames)))
    core = int(overlap_fraction > float(core_overlap_threshold))
    if operational == 0:
        subset = "normal"
    elif core == 1:
        subset = "core_anomaly"
    else:
        subset = "partial_or_boundary_anomaly"
    return {
        "y_true": operational,
        "y_true_operational": operational,
        "y_true_core": core,
        "window_frames": window_frames,
        "max_contiguous_overlap_frames": max_overlap,
        "union_overlap_frames": union_overlap,
        # Backward-compatible aliases.
        "overlap_frames": union_overlap,
        "overlap_fraction": overlap_fraction,
        "min_overlap_frames": int(min_overlap_frames),
        "core_overlap_threshold": float(core_overlap_threshold),
        "core_comparison": "strictly_greater_than",
        "temporal_subset": subset,
        "annotation_found": str(video_id) in annotations,
        "intervals": [[a, b] for a, b in intervals],
    }
