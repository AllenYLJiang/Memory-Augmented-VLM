#!/usr/bin/env python3
"""Cheap local CLIP shortlist retrieval for the frozen graph catalog."""
from __future__ import annotations

import json
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

import numpy as np

from common import stable_sha1, write_json
from schemas import GraphTemplateV2, WindowCase


@dataclass(frozen=True)
class ClipRetrieverConfig:
    model_dir: Path
    cache_dir: Path
    device: str = "auto"
    text_batch_size: int = 64
    image_batch_size: int = 16


def _graph_text(graph: GraphTemplateV2) -> str:
    nodes = "; ".join(
        f"{node.title}: {', '.join(node.cue_bundle[:3])}" for node in graph.nodes
    )
    return f"{graph.title}. {graph.joint_semantics}. Visible concepts: {nodes}"


class LocalClipGraphRetriever:
    def __init__(self, runtime, config: ClipRetrieverConfig) -> None:
        self.runtime = runtime
        self.config = config
        self._lock = threading.RLock()
        self._loaded = False
        self.model = None
        self.processor = None
        self.torch = None
        self.device = ""
        self._catalog_signature = ""
        self._keys: list[str] = []
        self._features = None

    def _load(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            import torch
            from transformers import CLIPModel, CLIPProcessor

            model_dir = Path(self.config.model_dir)
            if not (model_dir / "config.json").is_file():
                raise FileNotFoundError(f"CLIP model is incomplete: {model_dir}")
            if not torch.cuda.is_available():
                raise RuntimeError("CLIP retrieval requires CUDA in the optimized local runner")
            device = self.config.device
            if device == "auto":
                device = "cuda:1" if torch.cuda.device_count() > 1 else "cuda:0"
            self.model = CLIPModel.from_pretrained(
                str(model_dir), local_files_only=True, dtype=torch.float16,
            ).eval().to(device)
            self.processor = CLIPProcessor.from_pretrained(str(model_dir), local_files_only=True)
            self.torch = torch
            self.device = device
            self._loaded = True
            print(f"[local-retriever] loaded={model_dir} device={device}", flush=True)

    def _catalog_features(self, catalog: Mapping[str, GraphTemplateV2]):
        self._load()
        keys = sorted(catalog)
        texts = [_graph_text(catalog[key]) for key in keys]
        signature = stable_sha1(str(self.config.model_dir), keys, texts, size=40)
        if self._catalog_signature == signature and self._features is not None:
            return keys, self._features
        cache_path = Path(self.config.cache_dir) / f"catalog_text_{signature}.npz"
        if cache_path.is_file():
            value = np.load(cache_path)
            features = value["features"]
        else:
            batches = []
            for start in range(0, len(texts), max(1, self.config.text_batch_size)):
                values = self.processor(
                    text=texts[start:start + self.config.text_batch_size],
                    return_tensors="pt",
                    padding=True,
                    truncation=True,
                )
                values = {key: item.to(self.device) for key, item in values.items()}
                with self.torch.inference_mode():
                    result = self.model.get_text_features(**values)
                result = result / result.norm(dim=-1, keepdim=True).clamp_min(1e-8)
                batches.append(result.float().cpu().numpy())
            features = np.concatenate(batches, axis=0)
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(cache_path, features=features)
        self._catalog_signature = signature
        self._keys = keys
        self._features = features
        return keys, features

    def shortlist(
        self,
        case: WindowCase,
        catalog: Mapping[str, GraphTemplateV2],
        top_k_abnormal: int,
        top_k_normal: int,
    ) -> tuple[list[GraphTemplateV2], dict]:
        from PIL import Image

        with self._lock:
            keys, text_features = self._catalog_features(catalog)
            evidence = self.runtime.evidence_metadata(case)
            image_paths = [Path(str(path)) for path in evidence.get("image_paths", [])]
            images = [Image.open(path).convert("RGB") for path in image_paths]
            try:
                values = self.processor(images=images, return_tensors="pt")
            finally:
                for image in images:
                    image.close()
            values = {key: item.to(self.device) for key, item in values.items()}
            with self.torch.inference_mode():
                image_features = self.model.get_image_features(**values)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True).clamp_min(1e-8)
            pooled = image_features.mean(dim=0, keepdim=True)
            pooled = pooled / pooled.norm(dim=-1, keepdim=True).clamp_min(1e-8)
            scores = pooled.float().cpu().numpy()[0] @ text_features.T
            ranking = sorted(
                ({
                    "graph_key": key,
                    "polarity": catalog[key].polarity,
                    "family": catalog[key].family,
                    "visual_support": float((scores[index] + 1.0) / 2.0),
                    "cosine_similarity": float(scores[index]),
                    "visible_reason": "local CLIP mean similarity over the eight exact frames",
                } for index, key in enumerate(keys)),
                key=lambda item: (-item["cosine_similarity"], item["graph_key"]),
            )
            abnormal = [item for item in ranking if item["polarity"] == "abnormal"][:top_k_abnormal]
            normal_ranked = [item for item in ranking if item["polarity"] == "normal"]
            normal, families = [], set()
            for item in normal_ranked:
                if item["family"] in families:
                    continue
                normal.append(item)
                families.add(item["family"])
                if len(normal) >= top_k_normal:
                    break
            for item in normal_ranked:
                if item not in normal:
                    normal.append(item)
                if len(normal) >= top_k_normal:
                    break
            selected_abnormal = [item["graph_key"] for item in abnormal]
            selected_normal = [item["graph_key"] for item in normal[:top_k_normal]]
            trace = {
                "mode": "local_clip_catalog_shortlist",
                "selected_abnormal": selected_abnormal,
                "selected_normal": selected_normal,
                "abnormal_ranking": [item for item in ranking if item["polarity"] == "abnormal"],
                "normal_ranking": normal_ranked,
                "source_pair": {
                    "abnormal": str(case.source_record.get("best_abnormal_graph", "") or ""),
                    "normal": str(case.source_record.get("best_normal_graph", "") or ""),
                },
                "selector_pool": {"abnormal": len(selected_abnormal), "normal": len(selected_normal)},
                "shortlist_pool_multiplier": 1.0,
                "complete": len(selected_abnormal) == top_k_abnormal and len(selected_normal) == top_k_normal,
                "repaired": False,
                "cache_hit": False,
                "cache_path": "",
                "raw": "",
                "retriever_model": str(self.config.model_dir),
            }
            if not trace["complete"]:
                raise ValueError("local CLIP retriever could not produce the requested polarity-balanced shortlist")
            audit_path = Path(self.config.cache_dir) / "shortlists" / f"{stable_sha1(case.segment_key, size=20)}.json"
            write_json(audit_path, trace)
            trace["cache_path"] = str(audit_path)
            chosen = selected_abnormal + selected_normal
            return [catalog[key] for key in chosen], trace
