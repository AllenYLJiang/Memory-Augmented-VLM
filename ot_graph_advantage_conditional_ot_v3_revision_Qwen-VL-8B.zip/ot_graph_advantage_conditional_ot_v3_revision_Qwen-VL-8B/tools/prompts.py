#!/usr/bin/env python3
"""Blind prompts for independent nodes, two-stage conditional refinement and verification."""
from __future__ import annotations

import json
from typing import Any, Mapping

from schemas import GraphNodeV2, GraphTemplateV2


PROMPT_VERSION = "conditional_ot_multigraph_v3_initial_ot_feedback_pool_v2"
FORBIDDEN = (
    "y_true", "correct answer", "anomaly overlap", "label_b1", "label_b2",
    "label_b4", "label_b5", "label_b6",
)


def assert_blind(prompt: str) -> None:
    lowered = prompt.lower()
    leaked = [token for token in FORBIDDEN if token in lowered]
    if leaked:
        raise ValueError(f"prompt contains forbidden evaluation information: {leaked}")


def _node_text(node: GraphNodeV2, anonymous_id: str) -> dict:
    return {
        "id": anonymous_id,
        "description": node.title,
        "visual_cues": list(node.cue_bundle),
    }


def _distribution_schema() -> dict:
    return {
        "presence_probability": 0.0,
        "null_probability": 0.0,
        "location_distribution_given_present": [0.125] * 8,
        "evidence_quality_by_bin": [0.0] * 8,
        "best_bin": None,
        "region": "",
        "visible_evidence": "",
        "uncertainty": 0.0,
    }


def independent_node_prompt(node: GraphNodeV2) -> str:
    prompt = f"""TASK: INDEPENDENT_NODE_MATCHING
The eight supplied frames are T0..T7 in chronological order and are the complete visual
field for this experiment. Inspect them for exactly ONE visual concept. Do not infer or
search for a larger event template and do not assume related concepts exist.

Concept:
{json.dumps(_node_text(node, 'N'), ensure_ascii=False, indent=2)}

Return one compact JSON object with exactly these short keys:
- `p`: evidence-based presence probability in [0,1]; `n`: null probability in [0,1];
- `l`: exactly 8 location probabilities summing to 1 for T0..T7;
- `q`: exactly 8 direct-visibility scores in [0,1] for T0..T7;
- `b`: best-bin integer 0..7, or null; `r`: short region string;
- `e`: one short visible-evidence sentence; `u`: uncertainty in [0,1].

Do not copy a default/template response. Inspect all eight frames and estimate every value.
Use compact one-line JSON without Markdown or explanatory text.

Definitions:
- `presence_probability`: P(the concept is visibly present | these frames, this concept only).
- `location_distribution_given_present`: eight non-negative values that sum to 1; temporal
  location conditional on the concept being present. If presence is very low, return a
  near-uniform distribution rather than inventing a location.
- `evidence_quality_by_bin`: direct visual correspondence quality in [0,1] for each frame.
- `null_probability`: probability that no adequate visible support exists.

Describe only directly visible evidence. Filename, category, graph membership, other nodes,
and expected answer are unavailable."""
    assert_blind(prompt)
    return prompt


def _initial_ot_payload(graph: GraphTemplateV2, standalone_nodes: Mapping[str, Mapping[str, Any]], initial_ot: Mapping[str, Any]) -> tuple[list[dict], dict[str, str]]:
    id_to_key = {f"N{index}": node.key for index, node in enumerate(graph.nodes)}
    assignments = {
        str(item.get("node_key")): item
        for item in initial_ot.get("assignments", [])
        if isinstance(item, Mapping)
    }
    diagnostics = initial_ot.get("diagnostics", {}) if isinstance(initial_ot.get("diagnostics"), Mapping) else {}
    location_by_node = diagnostics.get("node_location", {}) if isinstance(diagnostics.get("node_location"), Mapping) else {}
    null_by_node = diagnostics.get("null_mass_by_node", {}) if isinstance(diagnostics.get("null_mass_by_node"), Mapping) else {}
    nodes = []
    for anonymous_id, node in zip(id_to_key, graph.nodes):
        standalone = standalone_nodes.get(node.key, {})
        nodes.append({
            **_node_text(node, anonymous_id),
            "standalone_estimate": {
                "presence_probability": standalone.get("presence", 0.0),
                "location_distribution_given_present": standalone.get("location_distribution_given_present", [0.125] * 8),
                "evidence_quality_by_bin": standalone.get("evidence_quality_by_bin", standalone.get("bin_affinity", [0.0] * 8)),
                "best_bin": standalone.get("best_bin"),
                "visible_evidence": standalone.get("visible_evidence", ""),
            },
            "initial_ot_estimate": {
                "presence_probability": initial_ot.get("node_presence", {}).get(node.key, 0.0),
                "expected_time": initial_ot.get("expected_time", {}).get(node.key, 0.0),
                "assigned_evidence": assignments.get(node.key, {}).get("assigned", "NULL"),
                "location_distribution": location_by_node.get(node.key, []),
                "null_mass": null_by_node.get(node.key, 0.0),
            },
        })
    return nodes, id_to_key


def conditional_refinement_prompt(
    graph: GraphTemplateV2,
    standalone_nodes: Mapping[str, Mapping[str, Any]],
    initial_ot: Mapping[str, Any],
) -> tuple[str, dict[str, str]]:
    nodes, id_to_key = _initial_ot_payload(graph, standalone_nodes, initial_ot)
    prompt = f"""TASK: CONDITIONAL_NODE_SET_REFINEMENT_AFTER_INITIAL_OT
The eight supplied frames are T0..T7 in chronological order. A first-stage independent
analysis and a first optimal-transport allocation have already produced tentative node
locations. Treat the listed semantic nodes as one candidate explanation and refine each
node using the other nodes' tentative existence and locations.

Do not infer or output a fixed relation schema. The graph semantics are joint
conditional inference over one shared evidence field:
- decide whether the initial allocation is visually justified;
- re-localize a node when another node reveals the correct episode;
- suppress a standalone match when it belongs to an unrelated moment;
- allow NULL when the node is absent or not observable;
- do not force nodes to be in different frames when distinct concepts genuinely co-occur.

Candidate joint semantics: {graph.joint_semantics}
Initial state:
{json.dumps(nodes, ensure_ascii=False, indent=2)}

For each node return P(node | video, all other listed nodes and their initial OT state).
`context_increases_from` and `context_decreases_from` contain anonymous node IDs only. They
mean conditional probability influence, not physical causality.

Return one compact JSON object. Top level: `c`=graph coherence in [0,1], `s`=episode
span-bin integer list, `e`=short episode summary, `n`=node object. `n` must contain
exactly these IDs: {json.dumps(list(id_to_key), ensure_ascii=False)}. For every node ID use:
`p`=presence, `n`=null, `l`=8 location probabilities, `q`=8 evidence scores,
`b`=best bin, `r`=region, `e`=visible evidence, `u`=uncertainty,
`up`=IDs increasing support, `down`=IDs decreasing support, `why`=short update reason.
Do not copy the initial estimates. Re-evaluate every value from the frames and joint context.
Use compact one-line JSON without Markdown or explanatory text.

`location_distribution_given_present` must sum to 1. `evidence_quality_by_bin` measures only
direct visual support. `graph_coherence` is the probability that the node set describes one
compatible episode rather than unrelated moments. Use only visible evidence. Filename,
class label, graph polarity and expected answer are unavailable."""
    assert_blind(prompt)
    return prompt, id_to_key


def conditional_graph_prompt(graph: GraphTemplateV2) -> tuple[str, dict[str, str]]:
    """Backward-compatible prompt helper used by old tests/tools.

    New live code must call :func:`conditional_refinement_prompt` with the initial OT state.
    """
    standalone = {
        node.key: {
            "presence": 0.5,
            "location_distribution_given_present": [0.125] * 8,
            "evidence_quality_by_bin": [0.5] * 8,
            "best_bin": None,
            "visible_evidence": "not supplied in compatibility mode",
        }
        for node in graph.nodes
    }
    initial = {
        "node_presence": {node.key: 0.5 for node in graph.nodes},
        "expected_time": {node.key: 0.5 for node in graph.nodes},
        "assignments": [],
        "diagnostics": {},
    }
    return conditional_refinement_prompt(graph, standalone, initial)


def graph_shortlist_prompt(catalog: Mapping[str, GraphTemplateV2], top_k_abnormal: int, top_k_normal: int) -> tuple[str, dict[str, str]]:
    abnormal = sorted((g for g in catalog.values() if g.polarity == "abnormal"), key=lambda g: g.key)
    normal = sorted((g for g in catalog.values() if g.polarity == "normal"), key=lambda g: g.key)
    id_to_key = {
        **{f"A{index}": graph.key for index, graph in enumerate(abnormal)},
        **{f"N{index}": graph.key for index, graph in enumerate(normal)},
    }

    def compact(graph: GraphTemplateV2, candidate_id: str) -> dict:
        return {
            "id": candidate_id,
            "family": graph.family,
            "joint_semantics": graph.joint_semantics,
            "nodes": [
                {"description": node.title, "visual_cues": list(node.cue_bundle[:3])}
                for node in graph.nodes
            ],
        }

    schema = {
        "abnormal_candidates": [{"id": "A0", "visual_support": 0.0, "visible_reason": ""}],
        "normal_candidates": [{"id": "N0", "visual_support": 0.0, "visible_reason": ""}],
    }
    prompt = f"""TASK: BLIND_GRAPH_CANDIDATE_SHORTLIST
Select candidate node-set explanations before either matching method runs. The same shortlist
will be used by all methods. Use only visible frames; do not infer from filename or expected
answer.

Return exactly {max(1, int(top_k_abnormal))} abnormal and {max(2, int(top_k_normal))}
normal/confound candidates. Normal candidates must be family-diverse when visually plausible:
prefer at most one candidate from a family before selecting a second from that family.

Abnormal candidates:
{json.dumps([compact(g, f'A{i}') for i, g in enumerate(abnormal)], ensure_ascii=False, indent=2)}

Normal/confound candidates:
{json.dumps([compact(g, f'N{i}') for i, g in enumerate(normal)], ensure_ascii=False, indent=2)}

Return JSON only and use candidate IDs exactly:
{json.dumps(schema, ensure_ascii=False, indent=2)}"""
    assert_blind(prompt)
    return prompt, id_to_key


def graph_shortlist_repair_prompt(previous: Mapping[str, Any], id_to_key: Mapping[str, str], top_k_abnormal: int, top_k_normal: int) -> str:
    schema = {
        "abnormal_candidates": [{"id": "A0", "visual_support": 0.0, "visible_reason": ""}],
        "normal_candidates": [{"id": "N0", "visual_support": 0.0, "visible_reason": ""}],
    }
    prompt = f"""TASK: REPAIR_BLIND_GRAPH_SHORTLIST
The previous candidate shortlist was incomplete or duplicated. Re-read the same eight frames
and return exactly {top_k_abnormal} distinct abnormal IDs and {top_k_normal} distinct normal
IDs. Use only IDs from this allowed map and keep the normal candidates family-diverse.

Allowed IDs:
{json.dumps(dict(id_to_key), ensure_ascii=False, indent=2)}

Previous response:
{json.dumps(dict(previous), ensure_ascii=False, indent=2)}

Return JSON only:
{json.dumps(schema, ensure_ascii=False, indent=2)}"""
    assert_blind(prompt)
    return prompt


def verifier_prompt(method_x: dict, method_y: dict) -> str:
    schema = {
        "preferred_method": "X|Y|tie",
        "confidence": 0.0,
        "visual_reason": "",
        "method_x_failure": "",
        "method_y_failure": "",
    }
    prompt = f"""TASK: BLIND_MATCHING_VERIFIER
Two anonymous methods analyzed the same eight frames. Judge which result is more faithfully
grounded. You do not know the dataset label, method identity or which one was scored correct.
Both summaries use the same schema. Prefer a method only when its node probabilities,
locations, NULL assignments and graph competition are visibly better justified.

METHOD X:
{json.dumps(method_x, ensure_ascii=False, indent=2)}

METHOD Y:
{json.dumps(method_y, ensure_ascii=False, indent=2)}

Return JSON only:
{json.dumps(schema, ensure_ascii=False, indent=2)}"""
    assert_blind(prompt)
    return prompt
