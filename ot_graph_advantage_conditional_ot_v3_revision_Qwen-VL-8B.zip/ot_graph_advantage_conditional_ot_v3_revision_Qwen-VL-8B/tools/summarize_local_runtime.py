#!/usr/bin/env python3
"""Deduplicate per-response telemetry and summarize physical GPU batches."""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np

from common import read_json, write_json


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", required=True, type=Path)
    args = parser.parse_args()
    batches = {}
    for path in (args.run_dir / "cache" / "responses").rglob("*.json"):
        value = read_json(path, {})
        telemetry = value.get("telemetry", {}) if isinstance(value, dict) else {}
        batch_id = str(telemetry.get("batch_id", ""))
        if batch_id:
            batches.setdefault(batch_id, telemetry)
    rows = list(batches.values())
    total_ms = [float(row.get("total_ms", 0.0)) for row in rows]
    output = {
        "physical_gpu_batches": len(rows),
        "logical_requests": sum(int(row.get("logical_requests", row.get("batch_size", 0))) for row in rows),
        "visual_encoder_passes": sum(int(row.get("visual_encoder_passes", 0)) for row in rows),
        "visual_feature_cache_hits": sum(bool(row.get("visual_feature_cache_hit")) for row in rows),
        "batch_size_counts": dict(Counter(str(row.get("batch_size", 0)) for row in rows)),
        "total_gpu_batch_seconds": sum(total_ms) / 1000.0,
        "batch_latency_ms": {
            "mean": float(np.mean(total_ms)) if total_ms else 0.0,
            "p50": float(np.percentile(total_ms, 50)) if total_ms else 0.0,
            "p95": float(np.percentile(total_ms, 95)) if total_ms else 0.0,
        },
        "peak_allocated_gib": max((int(row.get("peak_allocated_bytes", 0)) for row in rows), default=0) / 1024**3,
        "peak_reserved_gib": max((int(row.get("peak_reserved_bytes", 0)) for row in rows), default=0) / 1024**3,
        "batches": rows,
    }
    write_json(args.run_dir / "local_runtime_summary.json", output)
    print(json.dumps(output, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
