#!/usr/bin/env python3
"""Resumable sampled run for independent nodes versus two-stage conditional OT graphs."""
from __future__ import annotations

import argparse
import csv
import json
import queue
import threading
import traceback
from concurrent import futures
from pathlib import Path
from typing import Dict

from common import append_jsonl, case_id, file_sha256, read_json, stable_sha1, write_json
from discover_ot_failures import LiveDiscovery
from graph_catalog import read_catalog_json
from gt_annotations import label_window, load_annotations
from live_matching import PRIMARY_GRAPH_METHOD, WindowMatcher
from local_retrieval import ClipRetrieverConfig, LocalClipGraphRetriever
from prompts import PROMPT_VERSION
from render_report import build_report, render_case
from schemas import WindowCase
from selection import (
    discover_prediction_files,
    label_codes,
    load_deduplicated_records,
    sample_video_ids,
    select_windows,
    source_group_id,
    write_selection,
)
from video_completion import audit_video_completion
from vlm_runtime import CachedVideoVLM, RuntimeConfig


def parse_args():
    parser = argparse.ArgumentParser(description="Two-stage conditional OT graph-vs-node experiment")
    parser.add_argument("--source-run", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--graph-catalog", required=True, type=Path)
    parser.add_argument("--code-dir", required=True, type=Path)
    parser.add_argument("--annotations", required=True, type=Path)
    parser.add_argument("--video-sample-fraction", type=float, default=0.1)
    parser.add_argument("--video-sample-seed", type=int, default=42)
    parser.add_argument("--max-windows-per-video", type=int, default=1)
    parser.add_argument("--max-total-windows", type=int, default=0)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--model", default="qwen3.6-plus")
    parser.add_argument("--runtime-backend", choices=("local_qwen", "dashscope"), default="local_qwen")
    parser.add_argument("--model-dir", type=Path, default=Path("G:/Qwen3-VL-8B"))
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--dtype", default="bfloat16")
    parser.add_argument("--attention", choices=("auto", "sdpa", "flash_attention_2"), default="auto")
    parser.add_argument("--min-pixels", type=int, default=4096)
    parser.add_argument("--max-pixels", type=int, default=147456)
    parser.add_argument("--max-vlm-batch-size", type=int, default=24)
    parser.add_argument("--selector-max-new-tokens", type=int, default=1400)
    parser.add_argument("--node-max-new-tokens", type=int, default=220)
    parser.add_argument("--graph-max-new-tokens", type=int, default=700)
    parser.add_argument("--verifier-max-new-tokens", type=int, default=500)
    parser.add_argument("--no-vision-feature-reuse", action="store_true")
    parser.add_argument("--retrieval-mode", choices=("vlm", "clip"), default="clip")
    parser.add_argument("--matching-profile", choices=("full", "m2"), default="full")
    parser.add_argument("--clip-model-dir", type=Path, default=Path("G:/Dataset/XDViolence/videos/clip-vit-large-patch14"))
    parser.add_argument("--clip-device", default="auto")
    parser.add_argument("--fps", type=float, default=2.0)
    parser.add_argument("--key-env", default="DASHSCOPE_API_KEY")
    parser.add_argument("--evidence-mode", choices=("frames", "video"), default="frames")
    parser.add_argument("--evidence-frames", type=int, default=8)
    parser.add_argument("--evidence-slots-per-bin", type=int, default=2)
    parser.add_argument("--decision-margin", type=float, default=0.03)
    parser.add_argument("--coherence-weight", type=float, default=0.25)
    parser.add_argument("--competition-aggregation", choices=("max", "logmeanexp"), default="logmeanexp")
    parser.add_argument("--competition-temperature", type=float, default=0.1)
    parser.add_argument("--top-k-abnormal", type=int, default=2)
    parser.add_argument("--top-k-normal", type=int, default=4)
    parser.add_argument("--shortlist-pool-multiplier", type=float, default=1.0)
    parser.add_argument("--frozen-source-pair", action="store_true")
    parser.add_argument("--exclude-videos-file", type=Path)
    parser.add_argument("--exclude-source-groups", action="store_true")
    parser.add_argument("--gt-min-overlap-frames", type=int, default=8)
    parser.add_argument("--gt-core-overlap-threshold", type=float, default=2.0 / 3.0)
    parser.add_argument("--source-window", type=int, default=96)
    parser.add_argument("--source-stride", type=int, default=16)
    parser.add_argument("--metric-min-video-completion", type=float, default=0.99)
    parser.add_argument("--no-verifier", action="store_true")
    parser.add_argument("--run-leave-one-out", action="store_true")
    parser.add_argument("--no-images", action="store_true")
    parser.add_argument("--mock", action="store_true")
    parser.add_argument("--discover-live", action="store_true")
    parser.add_argument("--discovery-out-dir", type=Path)
    parser.add_argument("--discovery-registry", type=Path)
    parser.add_argument("--max-discovery-cases", type=int, default=0)
    parser.add_argument("--discovery-cases-per-video", type=int, default=1)
    parser.add_argument("--teacher-model", default="deepseek-v4-pro")
    parser.add_argument("--teacher-base-url", default="https://api.deepseek.com")
    parser.add_argument("--teacher-key-env", default="DEEPSEEK_API_KEY")
    parser.add_argument("--teacher-backend", choices=("local_qwen", "openai"), default="local_qwen")
    parser.add_argument("--teacher-model-dir", type=Path, default=Path("G:/Qwen3-8B"))
    parser.add_argument("--teacher-device", default="cuda:1")
    parser.add_argument("--teacher-max-new-tokens", type=int, default=5000)
    return parser.parse_args()


def _write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _code_hashes() -> dict:
    root = Path(__file__).resolve().parent
    names = (
        "matching.py", "sinkhorn_ot.py", "competition.py", "prompts.py", "live_matching.py",
        "vlm_runtime.py", "local_qwen_backend.py", "local_retrieval.py",
    )
    return {name: file_sha256(root / name) for name in names}


def main() -> int:
    args = parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    catalog = read_catalog_json(args.graph_catalog)
    graph_catalog_sha256 = file_sha256(args.graph_catalog)
    annotations_sha256 = file_sha256(args.annotations)
    exclusion_sha256 = file_sha256(args.exclude_videos_file) if args.exclude_videos_file and args.exclude_videos_file.is_file() else ""
    prediction_files = discover_prediction_files(args.source_run)
    source_records, input_stats = load_deduplicated_records(prediction_files)
    code_hashes = _code_hashes()

    run_signature = stable_sha1(
        "multi_candidate_conditional_ot_v3",
        PROMPT_VERSION,
        graph_catalog_sha256,
        annotations_sha256,
        exclusion_sha256,
        input_stats.get("prediction_file_sha256"),
        code_hashes,
        args.model,
        args.runtime_backend,
        args.model_dir,
        args.device,
        args.dtype,
        args.attention,
        args.min_pixels,
        args.max_pixels,
        args.max_vlm_batch_size,
        args.retrieval_mode,
        args.matching_profile,
        args.clip_model_dir,
        args.fps,
        args.evidence_mode,
        args.evidence_frames,
        args.evidence_slots_per_bin,
        args.decision_margin,
        args.coherence_weight,
        args.competition_aggregation,
        args.competition_temperature,
        args.top_k_abnormal,
        args.top_k_normal,
        args.shortlist_pool_multiplier,
        args.frozen_source_pair,
        args.video_sample_fraction,
        args.video_sample_seed,
        args.max_windows_per_video,
        args.max_total_windows,
        args.gt_min_overlap_frames,
        args.gt_core_overlap_threshold,
        args.source_window,
        args.source_stride,
        args.metric_min_video_completion,
        args.no_verifier,
        args.run_leave_one_out,
        args.mock,
        size=40,
    )

    completion_rows = audit_video_completion(source_records, args.source_window, args.source_stride)
    completion_by_video = {row["video_id"]: row for row in completion_rows}
    _write_csv(args.out_dir / "video_completion_audit.csv", completion_rows)

    selected_video_ids, sample_manifest = sample_video_ids(
        source_records, args.video_sample_fraction, args.video_sample_seed,
    )
    excluded_video_ids, excluded_groups = set(), set()
    if args.exclude_videos_file and args.exclude_videos_file.is_file():
        excluded_video_ids = {
            line.strip() for line in args.exclude_videos_file.read_text(encoding="utf-8").splitlines()
            if line.strip()
        }
        excluded_groups = {source_group_id(value) for value in excluded_video_ids}
        if args.exclude_source_groups:
            selected_video_ids = {
                video_id for video_id in selected_video_ids if source_group_id(video_id) not in excluded_groups
            }
        else:
            selected_video_ids -= excluded_video_ids
    sample_manifest["exclude_videos_file"] = str(args.exclude_videos_file or "")
    sample_manifest["exclude_source_groups"] = bool(args.exclude_source_groups)
    sample_manifest["excluded_source_groups"] = sorted(excluded_groups)
    sample_manifest["selected_videos"] = [
        item for item in sample_manifest.get("selected_videos", [])
        if str(item.get("video_id", "")) in selected_video_ids
    ]
    sample_manifest["selected_union_videos"] = len(selected_video_ids)
    for code, stats in sample_manifest.get("class_stats", {}).items():
        stats["union_videos_containing_class"] = sum(code in label_codes(video_id) for video_id in selected_video_ids)

    selected = select_windows(
        source_records,
        selected_video_ids,
        args.video_sample_seed,
        args.max_windows_per_video,
        args.max_total_windows,
        set(catalog),
        require_source_pair=args.frozen_source_pair,
    )
    annotations = load_annotations(args.annotations)
    prepared = []
    for source in selected:
        value = dict(source)
        gt = label_window(
            str(value.get("video_id", "")),
            int(value.get("start_frame", 0)),
            int(value.get("end_frame", 0)),
            annotations,
            min_overlap_frames=args.gt_min_overlap_frames,
            core_overlap_threshold=args.gt_core_overlap_threshold,
        )
        if not gt["annotation_found"]:
            continue
        completion = completion_by_video.get(str(value.get("video_id", "")), {})
        metric_eligible = (
            float(args.metric_min_video_completion) <= 0.0
            or (
                completion.get("num_frames_source") == "video_metadata"
                and float(completion.get("coverage", 0.0)) >= float(args.metric_min_video_completion)
            )
        )
        value["_corrected_gt"] = gt
        value["_video_completion"] = completion
        value["_metric_eligible"] = bool(metric_eligible)
        prepared.append(value)

    write_selection(args.out_dir, prepared, sample_manifest, input_stats, require_source_pair=args.frozen_source_pair)
    gt_audit_rows = []
    for value in prepared:
        gt = value.get("_corrected_gt", {})
        source_truth = value.get("y_true")
        gt_audit_rows.append({
            "segment_key": value.get("segment_key"),
            "video_id": value.get("video_id"),
            "start_frame": value.get("start_frame"),
            "end_frame": value.get("end_frame"),
            "source_y_true": source_truth,
            "y_true_operational": gt.get("y_true_operational"),
            "y_true_core": gt.get("y_true_core"),
            "source_vs_operational_mismatch": (
                "" if source_truth is None else int(int(source_truth) != int(gt.get("y_true_operational", 0)))
            ),
            "max_contiguous_overlap_frames": gt.get("max_contiguous_overlap_frames"),
            "union_overlap_frames": gt.get("union_overlap_frames"),
            "overlap_fraction": gt.get("overlap_fraction"),
            "temporal_subset": gt.get("temporal_subset"),
            "metric_eligible": value.get("_metric_eligible"),
            "video_completion": value.get("_video_completion", {}).get("coverage"),
        })
    _write_csv(args.out_dir / "gt_label_audit.csv", gt_audit_rows)
    run_config = {
        "version": "multi_candidate_conditional_ot_v3",
        "prompt_version": PROMPT_VERSION,
        "source_run": str(args.source_run),
        "prediction_files": [str(path) for path in prediction_files],
        "prediction_file_sha256": input_stats.get("prediction_file_sha256", {}),
        "graph_catalog": str(args.graph_catalog),
        "graph_catalog_sha256": graph_catalog_sha256,
        "annotations_sha256": annotations_sha256,
        "exclusion_sha256": exclusion_sha256,
        "code_hashes": code_hashes,
        "run_signature": run_signature,
        "code_dir": str(args.code_dir),
        "annotations": str(args.annotations),
        "video_sample_fraction": args.video_sample_fraction,
        "video_sample_seed": args.video_sample_seed,
        "max_windows_per_video": args.max_windows_per_video,
        "max_total_windows": args.max_total_windows,
        "workers": args.workers,
        "model": args.model,
        "runtime_backend": args.runtime_backend,
        "model_dir": str(args.model_dir),
        "device": args.device,
        "dtype": args.dtype,
        "attention": args.attention,
        "min_pixels": args.min_pixels,
        "max_pixels": args.max_pixels,
        "max_vlm_batch_size": args.max_vlm_batch_size,
        "reuse_vision_features": not args.no_vision_feature_reuse,
        "retrieval_mode": args.retrieval_mode,
        "matching_profile": args.matching_profile,
        "clip_model_dir": str(args.clip_model_dir),
        "clip_device": args.clip_device,
        "fps": args.fps,
        "evidence_mode": args.evidence_mode,
        "evidence_frames": args.evidence_frames,
        "evidence_slots_per_bin": args.evidence_slots_per_bin,
        "decision_margin": args.decision_margin,
        "coherence_weight": args.coherence_weight,
        "competition_aggregation": args.competition_aggregation,
        "competition_temperature": args.competition_temperature,
        "top_k_abnormal": args.top_k_abnormal,
        "top_k_normal": args.top_k_normal,
        "shortlist_pool_multiplier": args.shortlist_pool_multiplier,
        "candidate_mode": (
            "frozen_source_pair" if args.frozen_source_pair
            else f"{args.retrieval_mode}_catalog_shortlist"
        ),
        "exclude_videos_file": str(args.exclude_videos_file or ""),
        "exclude_source_groups": args.exclude_source_groups,
        "gt_min_overlap_frames": args.gt_min_overlap_frames,
        "gt_core_overlap_threshold": args.gt_core_overlap_threshold,
        "source_window": args.source_window,
        "source_stride": args.source_stride,
        "metric_min_video_completion": args.metric_min_video_completion,
        "mock": args.mock,
        "run_leave_one_out": args.run_leave_one_out,
        "discover_live": args.discover_live,
        "max_discovery_cases": args.max_discovery_cases,
        "discovery_cases_per_video": args.discovery_cases_per_video,
        "selected_windows": len(prepared),
        "metric_eligible_windows": sum(bool(value.get("_metric_eligible")) for value in prepared),
    }
    write_json(args.out_dir / "run_config.json", run_config)
    print(
        f"[selection] source_windows={input_stats['unique_segments']} sample_videos={sample_manifest['selected_union_videos']} "
        f"selected_windows={len(prepared)} metric_eligible={run_config['metric_eligible_windows']} "
        f"fraction={args.video_sample_fraction}", flush=True,
    )

    local = threading.local()
    progress_lock = threading.Lock()
    progress = {"done": 0}

    discovery_session = discovery_queue = discovery_thread = None
    discovery_lock = threading.Lock()
    discovery_state = {"enqueued": 0, "videos": {}}
    if args.discover_live:
        if args.discovery_out_dir is None or args.discovery_registry is None:
            raise SystemExit("--discover-live requires --discovery-out-dir and --discovery-registry")
        discovery_session = LiveDiscovery(
            out_dir=args.discovery_out_dir,
            graph_catalog=args.graph_catalog,
            registry_path=args.discovery_registry,
            teacher_model=args.teacher_model,
            teacher_base_url=args.teacher_base_url,
            teacher_key_env=args.teacher_key_env,
            teacher_backend=args.teacher_backend,
            teacher_model_dir=args.teacher_model_dir,
            teacher_device=args.teacher_device,
            teacher_max_new_tokens=args.teacher_max_new_tokens,
            mock=args.mock,
        )
        discovery_queue = queue.Queue()

        def discovery_worker() -> None:
            assert discovery_queue is not None and discovery_session is not None
            while True:
                item = discovery_queue.get()
                try:
                    if item is None:
                        return
                    discovery_session.discover(item, discovery_state["enqueued"], 0)
                except Exception as exc:
                    error = {
                        "case_id": item.get("case_id") if isinstance(item, dict) else None,
                        "segment_key": item.get("segment_key") if isinstance(item, dict) else None,
                        "type": type(exc).__name__, "error": str(exc),
                    }
                    append_jsonl(args.discovery_out_dir / "discovery_worker_errors.jsonl", error)
                    print(f"[discovery-worker-error] case={error['case_id']}: {exc}", flush=True)
                finally:
                    discovery_queue.task_done()

        discovery_thread = threading.Thread(target=discovery_worker, name="ot-graph-discovery", daemon=True)
        discovery_thread.start()

    def enqueue_discovery(result: dict) -> None:
        if discovery_queue is None:
            return
        video_id = str(result.get("video_id", ""))
        with discovery_lock:
            if args.max_discovery_cases > 0 and discovery_state["enqueued"] >= args.max_discovery_cases:
                return
            used = int(discovery_state["videos"].get(video_id, 0))
            if args.discovery_cases_per_video > 0 and used >= args.discovery_cases_per_video:
                return
            discovery_state["videos"][video_id] = used + 1
            discovery_state["enqueued"] += 1
        discovery_queue.put(result)

    runtime = CachedVideoVLM(RuntimeConfig(
        code_dir=args.code_dir,
        cache_dir=args.out_dir / "cache",
        model=args.model,
        backend=args.runtime_backend,
        model_dir=args.model_dir,
        device=args.device,
        dtype=args.dtype,
        attention=args.attention,
        min_pixels=args.min_pixels,
        max_pixels=args.max_pixels,
        max_batch_size=args.max_vlm_batch_size,
        selector_max_new_tokens=args.selector_max_new_tokens,
        node_max_new_tokens=args.node_max_new_tokens,
        graph_max_new_tokens=args.graph_max_new_tokens,
        verifier_max_new_tokens=args.verifier_max_new_tokens,
        reuse_vision_features=not args.no_vision_feature_reuse,
        fps=args.fps,
        key_env=args.key_env,
        mock=args.mock,
        evidence_mode=args.evidence_mode,
        evidence_frames=args.evidence_frames,
    ))
    retriever = None
    if args.retrieval_mode == "clip" and not args.frozen_source_pair and not args.mock:
        retriever = LocalClipGraphRetriever(runtime, ClipRetrieverConfig(
            model_dir=args.clip_model_dir,
            cache_dir=args.out_dir / "cache" / "retrieval",
            device=args.clip_device,
        ))
    matcher = WindowMatcher(
        runtime,
        catalog,
        args.decision_margin,
        top_k_abnormal=args.top_k_abnormal,
        top_k_normal=args.top_k_normal,
        shortlist_pool_multiplier=args.shortlist_pool_multiplier,
        use_catalog_shortlist=not args.frozen_source_pair,
        evidence_slots_per_bin=args.evidence_slots_per_bin,
        coherence_weight=args.coherence_weight,
        competition_aggregation=args.competition_aggregation,
        competition_temperature=args.competition_temperature,
        run_leave_one_out=args.run_leave_one_out,
        retriever=retriever,
        matching_profile=args.matching_profile,
    )

    def get_matcher() -> WindowMatcher:
        return matcher

    def process(source: dict) -> dict:
        segment_key = str(source["segment_key"])
        cid = case_id(segment_key)
        record_path = args.out_dir / "records" / f"{cid}.json"
        cached = read_json(record_path, None)
        if isinstance(cached, dict) and cached.get("segment_key") == segment_key and cached.get("run_signature") == run_signature:
            result, state = cached, "cached"
        else:
            case = WindowCase(
                segment_key=segment_key,
                video_id=str(source.get("video_id", "")),
                video_path=str(source.get("video_path", "")),
                start_frame=int(source.get("start_frame", 0)),
                end_frame=int(source.get("end_frame", 0)),
                y_true=int(source["_corrected_gt"]["y_true_operational"]),
                source_record=source,
            )
            result = get_matcher().match(case, run_verifier=not args.no_verifier)
            result["run_signature"] = run_signature
            write_json(record_path, result)
            state = "new"
        comparison = result.get("comparison", {})
        if comparison.get("verified_graph_help"):
            write_json(args.out_dir / "live_graph_advantage" / f"{result['case_id']}.json", result)
            page = render_case(result, args.out_dir, no_images=args.no_images)
            print(f"+ GRAPH>NODE case={result['case_id']} segment={segment_key} page={page}", flush=True)
        if comparison.get("verified_graph_hurt"):
            print(f"! VERIFIED-GRAPH-HURT case={result['case_id']} segment={segment_key}", flush=True)
        if comparison.get("conditional_ot_failure"):
            write_json(args.out_dir / "live_graph_failures" / f"{result['case_id']}.json", result)
            render_case(result, args.out_dir, no_images=args.no_images)
            print(f"- GRAPH-FAIL case={result['case_id']} segment={segment_key}", flush=True)
            enqueue_discovery(result)
        with progress_lock:
            progress["done"] += 1
            done = progress["done"]
        print(f"[window {done}/{len(prepared)}] {state} {segment_key}", flush=True)
        return result

    errors_path = args.out_dir / "errors.jsonl"
    workers = max(1, int(args.workers))
    if workers == 1:
        for source in prepared:
            try:
                process(source)
            except Exception as exc:
                append_jsonl(errors_path, {"segment_key": source.get("segment_key"), "type": type(exc).__name__, "error": str(exc), "traceback": traceback.format_exc()})
                print(f"[window-error] {source.get('segment_key')}: {exc}", flush=True)
    else:
        with futures.ThreadPoolExecutor(max_workers=workers) as executor:
            jobs = {executor.submit(process, source): source for source in prepared}
            for future in futures.as_completed(jobs):
                source = jobs[future]
                try:
                    future.result()
                except Exception as exc:
                    append_jsonl(errors_path, {"segment_key": source.get("segment_key"), "type": type(exc).__name__, "error": str(exc), "traceback": traceback.format_exc()})
                    print(f"[window-error] {source.get('segment_key')}: {exc}", flush=True)

    if discovery_queue is not None:
        discovery_queue.put(None)
        discovery_queue.join()
        if discovery_thread is not None:
            discovery_thread.join()
        assert discovery_session is not None
        summary = discovery_session.finalize(discovery_state["enqueued"])
        print(f"[live-discovery-complete] {json.dumps(summary, ensure_ascii=False)}", flush=True)

    summary = build_report(args.out_dir, no_images=args.no_images, run_signature=run_signature)
    print(
        f"[complete] windows={summary['n_windows']} videos={summary['n_videos']} "
        f"verified_graph_helps={summary['paired_effects']['verified_graph_helps']} "
        f"verified_graph_hurts={summary['paired_effects']['verified_graph_hurts']} "
        f"report={args.out_dir / 'index.html'}", flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
