#!/usr/bin/env python3
"""Cached local-Qwen calls with deterministic eight-frame evidence locking.

All candidate selection, independent-node, conditional-refinement and verifier calls for a
window can see the exact same T0..T7 images.  ``evidence_mode=video`` remains available for
backward compatibility.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Optional

from common import read_json, stable_sha1, write_json
from local_qwen_backend import BACKEND_VERSION, LocalQwen3VLM, LocalVLMConfig, parse_json_object
from schemas import WindowCase


@dataclass(frozen=True)
class RuntimeConfig:
    code_dir: Path
    cache_dir: Path
    model: str = "Qwen3-VL-8B-Instruct-local"
    backend: str = "local_qwen"
    model_dir: Path = Path("G:/Qwen3-VL-8B")
    device: str = "cuda:0"
    dtype: str = "bfloat16"
    attention: str = "auto"
    min_pixels: int = 4096
    max_pixels: int = 147456
    max_batch_size: int = 24
    selector_max_new_tokens: int = 1400
    node_max_new_tokens: int = 220
    graph_max_new_tokens: int = 700
    verifier_max_new_tokens: int = 500
    reuse_vision_features: bool = True
    fps: float = 2.0
    key_env: str = "DASHSCOPE_API_KEY"
    mock: bool = False
    json_retries: int = 3
    evidence_mode: str = "frames"          # frames | video
    evidence_frames: int = 8
    image_jpeg_quality: int = 92


class CachedVideoVLM:
    def __init__(self, config: RuntimeConfig) -> None:
        self.config = config
        self.config.cache_dir.mkdir(parents=True, exist_ok=True)
        if config.evidence_mode not in {"frames", "video"}:
            raise ValueError("evidence_mode must be frames or video")
        self._vlm = None
        self._segment_cache = None
        self._ffprobe_meta = None
        self._parse_json_like = None
        if not config.mock and config.backend == "local_qwen":
            self._parse_json_like = parse_json_object
            self._vlm = LocalQwen3VLM(LocalVLMConfig(
                model_dir=Path(config.model_dir),
                device=config.device,
                dtype=config.dtype,
                attention=config.attention,
                min_pixels=int(config.min_pixels),
                max_pixels=int(config.max_pixels),
                max_batch_size=int(config.max_batch_size),
                selector_max_new_tokens=int(config.selector_max_new_tokens),
                node_max_new_tokens=int(config.node_max_new_tokens),
                graph_max_new_tokens=int(config.graph_max_new_tokens),
                verifier_max_new_tokens=int(config.verifier_max_new_tokens),
                reuse_vision_features=bool(config.reuse_vision_features),
            ))
        elif not config.mock:
            src = config.code_dir / "src"
            if str(src) not in sys.path:
                sys.path.insert(0, str(src))
            from structural_vlm_binary.utils.video import SegmentCache, ffprobe_meta
            from structural_vlm_binary.vlm.dashscope_backend import DashScopeVLM, DashScopeVLMConfig, parse_json_like
            self._segment_cache = SegmentCache(config.cache_dir / "segments")
            self._ffprobe_meta = ffprobe_meta
            self._parse_json_like = parse_json_like
            self._vlm = DashScopeVLM(DashScopeVLMConfig(
                model=config.model,
                fps=float(config.fps),
                api_key_env=config.key_env,
                vl_high_resolution_images=True,
                max_retries=6,
                json_parse_retries=1,
            ))

    @staticmethod
    def _host_path(value: str | Path) -> Path:
        """Translate WSL /mnt/<drive>/ paths when the experiment runs on Windows."""
        text = str(value)
        if os.name == "nt" and text.startswith("/mnt/") and len(text) > 6:
            drive = text[5].upper()
            tail = text[6:].lstrip("/").replace("/", "\\")
            return Path(f"{drive}:\\{tail}")
        return Path(text)

    def _segment(self, case: WindowCase) -> Path:
        source_segment = str(case.source_record.get("segment_path", "") or "")
        if source_segment and self._host_path(source_segment).is_file():
            return self._host_path(source_segment)
        video = self._host_path(case.video_path)
        if not video.is_file():
            raise FileNotFoundError(f"video unavailable for {case.segment_key}: {video}")
        assert self._segment_cache is not None and self._ffprobe_meta is not None
        meta = self._ffprobe_meta(video)
        return self._segment_cache.get_segment(
            video_path=video,
            start_frame=int(case.start_frame),
            end_frame=int(case.end_frame),
            fps=float(meta.fps),
        )

    @staticmethod
    def _frame_indices(start: int, end: int, count: int) -> list[int]:
        count = max(1, int(count))
        if end <= start:
            return [int(start)] * count
        return [
            int(round(start + (end - start) * ((index + 0.5) / count)))
            for index in range(count)
        ]

    def _extract_frame_panel(self, case: WindowCase) -> dict:
        import cv2  # type: ignore

        output_dir = self.config.cache_dir / "evidence_frames" / stable_sha1(case.segment_key, size=20)
        metadata_path = output_dir / "metadata.json"
        cached = read_json(metadata_path, None)
        if isinstance(cached, dict):
            paths = [Path(value) for value in cached.get("image_paths", [])]
            if len(paths) == self.config.evidence_frames and all(path.is_file() for path in paths):
                return cached

        video = self._host_path(case.video_path)
        absolute = True
        start, end = int(case.start_frame), int(case.end_frame)
        if not video.is_file():
            video = self._segment(case)
            absolute = False
            capture_probe = cv2.VideoCapture(str(video))
            frame_count = int(capture_probe.get(cv2.CAP_PROP_FRAME_COUNT)) if capture_probe.isOpened() else 0
            capture_probe.release()
            start, end = 0, max(0, frame_count - 1)
        capture = cv2.VideoCapture(str(video))
        if not capture.isOpened():
            raise RuntimeError(f"cannot open evidence video: {video}")
        indices = self._frame_indices(start, end, self.config.evidence_frames)
        output_dir.mkdir(parents=True, exist_ok=True)
        paths = []
        try:
            for bin_index, frame_index in enumerate(indices):
                path = output_dir / f"T{bin_index}_f{frame_index}.jpg"
                if not path.is_file():
                    capture.set(cv2.CAP_PROP_POS_FRAMES, int(frame_index))
                    ok, frame = capture.read()
                    if not ok or frame is None:
                        raise RuntimeError(f"failed to extract frame {frame_index} from {video}")
                    if not cv2.imwrite(str(path), frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(self.config.image_jpeg_quality)]):
                        raise RuntimeError(f"failed to write evidence frame: {path}")
                paths.append(path)
        finally:
            capture.release()
        metadata = {
            "mode": "frames",
            "source_video": str(video),
            "absolute_source_frame_indices": bool(absolute),
            "frame_indices": indices,
            "image_paths": [str(path) for path in paths],
            "bin_labels": [f"T{index}" for index in range(len(paths))],
        }
        write_json(metadata_path, metadata)
        return metadata

    def evidence_metadata(self, case: WindowCase) -> dict:
        if self.config.mock:
            return {
                "mode": self.config.evidence_mode,
                "frame_indices": self._frame_indices(case.start_frame, case.end_frame, self.config.evidence_frames),
                "image_paths": [],
                "bin_labels": [f"T{index}" for index in range(self.config.evidence_frames)],
            }
        if self.config.evidence_mode == "frames":
            return self._extract_frame_panel(case)
        return {"mode": "video", "frame_indices": [], "image_paths": [], "bin_labels": []}

    def _call_media(self, case: WindowCase, prompt: str, evidence: Mapping[str, Any]) -> str:
        assert self._vlm is not None
        if self.config.backend == "local_qwen":
            if evidence.get("mode") != "frames":
                raise ValueError("local Qwen3-VL backend currently requires evidence_mode=frames")
            outputs, _ = self._vlm.generate_batch(
                [prompt],
                [Path(str(path)) for path in evidence.get("image_paths", [])],
                ["single"],
            )
            return outputs[0]
        if evidence.get("mode") == "frames":
            content = []
            for index, image_path in enumerate(evidence.get("image_paths", [])):
                content.append({"text": f"T{index}"})
                content.append({"image": Path(str(image_path)).resolve().as_uri()})
            content.append({"text": prompt})
            messages = [{"role": "user", "content": content}]
            call_messages = getattr(self._vlm, "_call_messages", None)
            if call_messages is None:
                raise RuntimeError("installed DashScope backend does not expose multi-image _call_messages")
            return call_messages(messages, vl_high_resolution_images=True)
        return self._vlm.call_video(video_path=self._segment(case), prompt=prompt)

    def request_json(
        self,
        *,
        case: WindowCase,
        prompt: str,
        namespace: str,
        mock_spec: Optional[Mapping[str, Any]] = None,
    ) -> dict:
        return self.request_json_batch(case=case, requests=[{
            "prompt": prompt,
            "namespace": namespace,
            "mock_spec": mock_spec or {},
        }])[0]

    def request_json_batch(
        self,
        *,
        case: WindowCase,
        requests: list[Mapping[str, Any]],
    ) -> list[dict]:
        """Resolve cached requests and execute remaining prompts in GPU microbatches."""
        evidence = self.evidence_metadata(case)
        evidence_signature = stable_sha1(
            evidence.get("mode"),
            evidence.get("frame_indices"),
            evidence.get("image_paths"),
            size=40,
        )
        results: list[dict | None] = [None] * len(requests)
        pending: list[tuple[int, Mapping[str, Any], Path]] = []
        backend_signature = stable_sha1(
            BACKEND_VERSION, self.config.backend, self.config.model_dir, self.config.device,
            self.config.dtype, self.config.attention, self.config.min_pixels,
            self.config.max_pixels, self.config.reuse_vision_features, size=40,
        )
        for index, request in enumerate(requests):
            prompt = str(request["prompt"])
            namespace = str(request["namespace"])
            digest = hashlib.sha1(
                f"{case.segment_key}\0{self.config.model}\0{backend_signature}\0{self.config.fps}\0"
                f"{evidence_signature}\0{prompt}".encode("utf-8")
            ).hexdigest()
            cache_path = self.config.cache_dir / "responses" / namespace / f"{digest}.json"
            cached = read_json(cache_path, None)
            if isinstance(cached, dict) and isinstance(cached.get("parsed"), dict):
                result = dict(cached)
                result["cache_hit"] = True
                result["cache_path"] = str(cache_path)
                results[index] = result
            else:
                pending.append((index, request, cache_path))

        batch_limit = max(1, int(self.config.max_batch_size))
        for offset in range(0, len(pending), batch_limit):
            batch = pending[offset:offset + batch_limit]
            if self.config.mock:
                raw_outputs = []
                telemetry = {"backend": "mock", "batch_size": len(batch), "visual_encoder_passes": 0}
                for _, request, _ in batch:
                    parsed = self._mock_response(case.segment_key, request.get("mock_spec", {}))
                    raw_outputs.append(json.dumps(parsed, ensure_ascii=False))
            else:
                assert self._parse_json_like is not None and self._vlm is not None
                if self.config.backend == "local_qwen":
                    raw_outputs, telemetry = self._vlm.generate_batch(
                        [str(request["prompt"]) for _, request, _ in batch],
                        [Path(str(path)) for path in evidence.get("image_paths", [])],
                        [str(request["namespace"]) for _, request, _ in batch],
                    )
                    telemetry = dict(telemetry)
                    telemetry["batch_id"] = stable_sha1(
                        case.segment_key,
                        [str(request["namespace"]) for _, request, _ in batch],
                        [stable_sha1(str(request["prompt"]), size=40) for _, request, _ in batch],
                        size=20,
                    )
                    telemetry["logical_requests"] = len(batch)
                else:
                    raw_outputs = [
                        self._call_media(case, str(request["prompt"]), evidence)
                        for _, request, _ in batch
                    ]
                    telemetry = {"backend": "dashscope", "batch_size": len(batch)}
            for (index, request, cache_path), raw in zip(batch, raw_outputs):
                raw_attempts = [raw]
                try:
                    parsed = self._parse_json_like(raw) if not self.config.mock else json.loads(raw)
                    if not isinstance(parsed, dict):
                        raise ValueError("VLM returned non-object JSON")
                except Exception as first_error:
                    parsed = None
                    last_error = first_error
                    for _ in range(max(0, int(self.config.json_retries) - 1)):
                        if self.config.mock:
                            break
                        if self.config.backend == "local_qwen":
                            retry_values, _ = self._vlm.generate_batch(
                                [str(request["prompt"])],
                                [Path(str(path)) for path in evidence.get("image_paths", [])],
                                [str(request["namespace"])],
                            )
                            retry_raw = retry_values[0]
                        else:
                            retry_raw = self._call_media(case, str(request["prompt"]), evidence)
                        raw_attempts.append(retry_raw)
                        try:
                            candidate = self._parse_json_like(retry_raw)
                            if not isinstance(candidate, dict):
                                raise ValueError("VLM returned non-object JSON")
                            parsed = candidate
                            raw = retry_raw
                            break
                        except Exception as exc:
                            last_error = exc
                    if parsed is None:
                        raise ValueError(
                            f"VLM JSON parse failed for {case.segment_key}/{request['namespace']}: {last_error}"
                        )
                record = {
                    "version": "cached_local_qwen_vlm_v1",
                    "segment_key": case.segment_key,
                    "namespace": str(request["namespace"]),
                    "model": self.config.model,
                    "backend": self.config.backend,
                    "model_dir": str(self.config.model_dir),
                    "fps": float(self.config.fps),
                    "evidence": evidence,
                    "evidence_signature": evidence_signature,
                    "prompt_sha1": stable_sha1(str(request["prompt"]), size=40),
                    "prompt": str(request["prompt"]),
                    "parsed": parsed,
                    "raw": raw,
                    "raw_attempts": raw_attempts,
                    "cache_hit": False,
                    "cache_path": str(cache_path),
                    "telemetry": telemetry,
                }
                write_json(cache_path, record)
                results[index] = record
        return [value for value in results if isinstance(value, dict)]

    @staticmethod
    def _mock_response(segment_key: str, spec: Mapping[str, Any]) -> dict:
        kind = str(spec.get("kind", ""))

        def unit(*parts: str) -> float:
            value = int(hashlib.sha1("\0".join((segment_key,) + parts).encode()).hexdigest()[:12], 16)
            return value / float(16 ** 12 - 1)

        def distribution(peak: int) -> list[float]:
            values = [math.exp(-0.7 * abs(index - peak)) for index in range(8)]
            total = sum(values)
            return [round(value / total, 5) for value in values]

        if kind == "independent":
            node_key = str(spec.get("node_key", "node"))
            presence = 0.2 + 0.7 * unit(node_key, "presence")
            peak = int(unit(node_key, "peak") * 8) % 8
            quality = [max(0.05, 0.25 + 0.7 * unit(node_key, str(index), "quality")) for index in range(8)]
            return {
                "presence_probability": round(presence, 4),
                "null_probability": round(1.0 - presence, 4),
                "location_distribution_given_present": distribution(peak),
                "evidence_quality_by_bin": [round(value, 4) for value in quality],
                "best_bin": peak,
                "region": "mock region",
                "visible_evidence": f"mock independent evidence for {node_key}",
                "uncertainty": 0.15,
            }
        if kind in {"selector", "selector_repair"}:
            abnormal_ids = [str(value) for value in spec.get("abnormal_ids", [])]
            normal_ids = [str(value) for value in spec.get("normal_ids", [])]
            top_k_abnormal = max(1, int(spec.get("top_k_abnormal", 1)))
            top_k_normal = max(2, int(spec.get("top_k_normal", 2)))

            def ranked(values: list[str], group: str, limit: int) -> list[dict]:
                ordered = sorted(values, key=lambda value: unit(group, value), reverse=True)[:limit]
                return [{
                    "id": value,
                    "visual_support": round(0.4 + 0.55 * unit(group, value), 4),
                    "visible_reason": f"mock shortlist support for {value}",
                } for value in ordered]

            return {
                "abnormal_candidates": ranked(abnormal_ids, "abnormal", top_k_abnormal),
                "normal_candidates": ranked(normal_ids, "normal", top_k_normal),
            }
        if kind in {"joint", "joint_subset"}:
            node_keys = [str(value) for value in spec.get("node_keys", [])]
            graph_key = str(spec.get("graph_key", "graph"))
            initial_presence = spec.get("initial_presence", {}) if isinstance(spec.get("initial_presence"), Mapping) else {}
            nodes = {}
            for index, node_key in enumerate(node_keys):
                anonymous_id = f"N{index}"
                base = float(initial_presence.get(node_key, 0.2 + 0.7 * unit(node_key, "presence")))
                delta = 0.22 * (unit(graph_key, node_key, "delta") - 0.5)
                presence = max(0.05, min(0.95, base + delta))
                peak = (int(unit(graph_key, node_key, "peak") * 8) + index) % 8
                quality = [max(0.05, 0.25 + 0.7 * unit(graph_key, node_key, str(i), "quality")) for i in range(8)]
                nodes[anonymous_id] = {
                    "presence_probability": round(presence, 4),
                    "null_probability": round(1.0 - presence, 4),
                    "location_distribution_given_present": distribution(peak),
                    "evidence_quality_by_bin": [round(value, 4) for value in quality],
                    "best_bin": peak,
                    "region": "mock joint region",
                    "visible_evidence": f"mock joint evidence for {anonymous_id}",
                    "context_increases_from": [f"N{(index + 1) % len(node_keys)}"] if len(node_keys) > 1 else [],
                    "context_decreases_from": [],
                    "probability_update_reason": "mock conditional update from initial OT",
                    "uncertainty": 0.12,
                }
            return {
                "graph_coherence": round(0.45 + 0.5 * unit(graph_key, "coherence"), 4),
                "episode_span_bins": [0, 7],
                "episode_summary": "mock coherent episode",
                "nodes": nodes,
            }
        if kind == "verifier":
            return {
                "preferred_method": str(spec.get("preferred_method", "Y")),
                "confidence": 0.8,
                "visual_reason": "mock verifier preference",
                "method_x_failure": "",
                "method_y_failure": "",
            }
        raise ValueError(f"unknown mock response kind: {kind}")
