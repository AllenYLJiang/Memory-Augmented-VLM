#!/usr/bin/env python3
"""Persistent local Qwen3 inference backends used by the Windows GPU runner."""
from __future__ import annotations

import json
import hashlib
import re
import threading
import time
import types
from dataclasses import dataclass
from collections import OrderedDict
from pathlib import Path
from typing import Any, Mapping, Sequence

BACKEND_VERSION = "local_qwen_transformers_v1_compact_fast_processor_shared_vision"


def parse_json_object(text: str) -> dict:
    """Parse an object from plain JSON, fenced JSON, or a response with thinking text."""
    value = str(text or "").strip()
    if "</think>" in value:
        value = value.rsplit("</think>", 1)[-1].strip()
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", value, flags=re.I | re.S)
    candidates = [fenced.group(1)] if fenced else []
    candidates.append(value)
    decoder = json.JSONDecoder()
    first = value.find("{")
    if first >= 0:
        candidates.append(value[first:])
    last_error: Exception | None = None
    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
            if isinstance(parsed, dict):
                return parsed
        except Exception as exc:
            last_error = exc
        try:
            start = candidate.find("{")
            if start >= 0:
                parsed, _ = decoder.raw_decode(candidate[start:])
                if isinstance(parsed, dict):
                    return parsed
        except Exception as exc:
            last_error = exc
    raise ValueError(f"no JSON object found: {last_error}; output={value[:500]!r}")


def expected_weight_files(model_dir: Path) -> list[Path]:
    index_path = Path(model_dir) / "model.safetensors.index.json"
    if not index_path.is_file():
        single = Path(model_dir) / "model.safetensors"
        return [single]
    value = json.loads(index_path.read_text(encoding="utf-8"))
    names = sorted(set(value.get("weight_map", {}).values()))
    return [Path(model_dir) / str(name) for name in names]


def assert_model_complete(model_dir: Path, label: str) -> None:
    model_dir = Path(model_dir)
    required = [model_dir / "config.json", *expected_weight_files(model_dir)]
    missing = [str(path) for path in required if not path.is_file()]
    partials = sorted(model_dir.glob("*.crdownload"))
    if missing:
        suffix = f"; partial downloads={len(partials)}" if partials else ""
        raise FileNotFoundError(f"incomplete {label} at {model_dir}; missing={missing}{suffix}")


@dataclass(frozen=True)
class LocalVLMConfig:
    model_dir: Path
    device: str = "cuda:0"
    dtype: str = "bfloat16"
    attention: str = "auto"
    min_pixels: int = 4096
    max_pixels: int = 147456
    max_batch_size: int = 24
    selector_max_new_tokens: int = 1400
    node_max_new_tokens: int = 220
    graph_max_new_tokens: int = 700
    verifier_max_new_tokens: int = 500
    default_max_new_tokens: int = 1000
    reuse_vision_features: bool = True


class LocalQwen3VLM:
    """One persistent Qwen3-VL model with batched, semantically isolated prompts.

    Every row in a batch is still a separate conversation. When rows use the same eight
    frames, the patched vision hook encodes those frames once and repeats only the resulting
    visual features. This preserves the independent-node control while avoiding repeated
    vision-encoder work.
    """

    def __init__(self, config: LocalVLMConfig) -> None:
        self.config = config
        self._lock = threading.RLock()
        self._loaded = False
        self._reuse_state: dict[str, Any] | None = None
        self._vision_feature_cache: OrderedDict[str, tuple] = OrderedDict()
        self.model = None
        self.processor = None
        self.torch = None
        self.attention_impl = ""

    def _load(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            assert_model_complete(self.config.model_dir, "Qwen3-VL model")
            import importlib.util
            import torch
            from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

            if not torch.cuda.is_available() or not self.config.device.startswith("cuda"):
                raise RuntimeError(
                    "local Qwen3-VL requires CUDA for this project; run the Windows GPU "
                    "preflight instead of silently falling back to CPU"
                )
            attention = self.config.attention
            if attention == "auto":
                attention = "flash_attention_2" if importlib.util.find_spec("flash_attn") else "sdpa"
            dtype = getattr(torch, self.config.dtype)
            load_kwargs = {
                "local_files_only": True,
                "dtype": dtype,
                "device_map": {"": self.config.device},
                "low_cpu_mem_usage": True,
                "attn_implementation": attention,
            }
            try:
                model = Qwen3VLForConditionalGeneration.from_pretrained(
                    str(self.config.model_dir), **load_kwargs,
                )
            except Exception:
                if attention != "flash_attention_2":
                    raise
                attention = "sdpa"
                load_kwargs["attn_implementation"] = attention
                model = Qwen3VLForConditionalGeneration.from_pretrained(
                    str(self.config.model_dir), **load_kwargs,
                )
            processor = AutoProcessor.from_pretrained(
                str(self.config.model_dir),
                local_files_only=True,
                use_fast=True,
                min_pixels=int(self.config.min_pixels),
                max_pixels=int(self.config.max_pixels),
            )
            processor.tokenizer.padding_side = "left"
            model.eval()
            self.model = model
            self.processor = processor
            self.torch = torch
            self.attention_impl = attention
            self._install_shared_vision_hook()
            self._loaded = True
            print(
                f"[local-vlm] loaded={self.config.model_dir} device={self.config.device} "
                f"dtype={self.config.dtype} attention={attention} max_pixels={self.config.max_pixels}",
                flush=True,
            )

    def _install_shared_vision_hook(self) -> None:
        assert self.model is not None
        inner = self.model.model
        original = inner.get_image_features
        owner = self

        def shared_get_image_features(_inner, pixel_values, image_grid_thw=None):
            state = owner._reuse_state
            if not state or image_grid_thw is None:
                return original(pixel_values, image_grid_thw)
            batch_size = state["batch_size"]
            images_per_request = state["images_per_request"]
            if image_grid_thw.shape[0] != batch_size * images_per_request:
                return original(pixel_values, image_grid_thw)
            first_grid = image_grid_thw[:images_per_request]
            if any(
                not owner.torch.equal(
                    image_grid_thw[index * images_per_request:(index + 1) * images_per_request],
                    first_grid,
                )
                for index in range(1, batch_size)
            ):
                return original(pixel_values, image_grid_thw)
            first_patch_rows = int(first_grid.prod(-1).sum().item())
            if pixel_values.shape[0] != first_patch_rows * batch_size:
                return original(pixel_values, image_grid_thw)
            signature = str(state.get("media_signature", ""))
            cached = owner._vision_feature_cache.get(signature)
            if cached is not None and owner.torch.equal(cached[0], first_grid):
                image_embeds, deepstack = cached[1], cached[2]
                owner._vision_feature_cache.move_to_end(signature)
                state["vision_encoder_passes"] = 0
            else:
                image_embeds, deepstack = original(pixel_values[:first_patch_rows], first_grid)
                image_embeds = tuple(value.detach() for value in image_embeds)
                deepstack = tuple(value.detach() for value in deepstack)
                owner._vision_feature_cache[signature] = (
                    first_grid.detach().clone(), image_embeds, deepstack,
                )
                owner._vision_feature_cache.move_to_end(signature)
                while len(owner._vision_feature_cache) > 4:
                    owner._vision_feature_cache.popitem(last=False)
                state["vision_encoder_passes"] = 1
            repeated_images = tuple(image_embeds) * batch_size
            repeated_deepstack = tuple(
                owner.torch.cat([layer] * batch_size, dim=0) for layer in deepstack
            )
            return repeated_images, repeated_deepstack

        inner.get_image_features = types.MethodType(shared_get_image_features, inner)

    @staticmethod
    def _messages(prompt: str, images: Sequence[Any]) -> list[dict]:
        content: list[dict] = []
        for index, image in enumerate(images):
            content.append({"type": "text", "text": f"T{index}"})
            content.append({"type": "image", "image": image})
        content.append({"type": "text", "text": prompt})
        return [
            {
                "role": "system",
                "content": [{
                    "type": "text",
                    "text": (
                        "You are a precise visual evidence scorer. Inspect the supplied images, "
                        "estimate values from visible evidence, never copy placeholder/default "
                        "values, and return valid compact JSON only."
                    ),
                }],
            },
            {"role": "user", "content": content},
        ]

    def _token_cap(self, namespaces: Sequence[str]) -> int:
        caps = []
        for namespace in namespaces:
            if namespace.startswith("candidate_selector"):
                caps.append(self.config.selector_max_new_tokens)
            elif namespace.startswith("independent/"):
                caps.append(self.config.node_max_new_tokens)
            elif namespace.startswith("conditional_refinement/"):
                caps.append(self.config.graph_max_new_tokens)
            elif namespace.startswith("verifier"):
                caps.append(self.config.verifier_max_new_tokens)
            else:
                caps.append(self.config.default_max_new_tokens)
        return max(caps, default=self.config.default_max_new_tokens)

    def generate_batch(
        self,
        prompts: Sequence[str],
        image_paths: Sequence[Path],
        namespaces: Sequence[str],
    ) -> tuple[list[str], dict]:
        self._load()
        if not prompts:
            return [], {}
        if len(prompts) > int(self.config.max_batch_size):
            raise ValueError(
                f"batch has {len(prompts)} prompts, limit={self.config.max_batch_size}; "
                "increase LOCAL_MAX_BATCH_SIZE or let request_json_batch microbatch it"
            )
        from PIL import Image

        with self._lock:
            started = time.perf_counter()
            images = [Image.open(path).convert("RGB") for path in image_paths]
            try:
                conversations = [self._messages(prompt, images) for prompt in prompts]
                inputs = self.processor.apply_chat_template(
                    conversations,
                    tokenize=True,
                    add_generation_prompt=True,
                    padding=True,
                    return_dict=True,
                    return_tensors="pt",
                )
            finally:
                for image in images:
                    image.close()
            inputs = inputs.to(self.config.device)
            torch = self.torch
            torch.cuda.synchronize(self.config.device)
            torch.cuda.reset_peak_memory_stats(self.config.device)
            prefill_ready = time.perf_counter()
            media_signature = hashlib.sha1(
                "\0".join(str(Path(path).resolve()) for path in image_paths).encode("utf-8")
            ).hexdigest()
            reuse_state = {
                "batch_size": len(prompts),
                "images_per_request": len(image_paths),
                "media_signature": media_signature,
                "vision_encoder_passes": len(prompts),
            }
            self._reuse_state = reuse_state if self.config.reuse_vision_features else None
            try:
                with torch.inference_mode():
                    generated = self.model.generate(
                        **inputs,
                        max_new_tokens=self._token_cap(namespaces),
                        do_sample=False,
                        use_cache=True,
                    )
                torch.cuda.synchronize(self.config.device)
            finally:
                self._reuse_state = None
            finished = time.perf_counter()
            prompt_width = int(inputs.input_ids.shape[1])
            trimmed = [row[prompt_width:] for row in generated]
            outputs = self.processor.batch_decode(
                trimmed,
                skip_special_tokens=True,
                clean_up_tokenization_spaces=False,
            )
            output_tokens = [int(row.numel()) for row in trimmed]
            telemetry = {
                "backend": "local_qwen3_vl_transformers",
                "model_dir": str(self.config.model_dir),
                "device": self.config.device,
                "attention": self.attention_impl,
                "batch_size": len(prompts),
                "images_per_request": len(image_paths),
                "visual_encoder_passes": int(reuse_state["vision_encoder_passes"]),
                "visual_feature_cache_hit": bool(reuse_state["vision_encoder_passes"] == 0),
                "processor_ms": (prefill_ready - started) * 1000.0,
                "generate_ms": (finished - prefill_ready) * 1000.0,
                "total_ms": (finished - started) * 1000.0,
                "input_tokens_padded": prompt_width,
                "output_tokens": output_tokens,
                "peak_allocated_bytes": int(torch.cuda.max_memory_allocated(self.config.device)),
                "peak_reserved_bytes": int(torch.cuda.max_memory_reserved(self.config.device)),
            }
            return outputs, telemetry


@dataclass(frozen=True)
class LocalLLMConfig:
    model_dir: Path
    device: str = "cuda:1"
    dtype: str = "bfloat16"
    attention: str = "auto"
    max_new_tokens: int = 5000
    enable_thinking: bool = True


class LocalQwen3Teacher:
    """Lazy local Qwen3-8B replacement for the DeepSeek discovery client."""

    def __init__(self, config: LocalLLMConfig) -> None:
        self.config = config
        self._lock = threading.RLock()
        self._loaded = False
        self.model = None
        self.tokenizer = None
        self.torch = None

    def _load(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            assert_model_complete(self.config.model_dir, "Qwen3 text model")
            import importlib.util
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer

            if not torch.cuda.is_available() or not self.config.device.startswith("cuda"):
                raise RuntimeError("local Qwen3 graph discovery requires a CUDA device")
            attention = self.config.attention
            if attention == "auto":
                attention = "flash_attention_2" if importlib.util.find_spec("flash_attn") else "sdpa"
            kwargs = {
                "local_files_only": True,
                "dtype": getattr(torch, self.config.dtype),
                "device_map": {"": self.config.device},
                "low_cpu_mem_usage": True,
                "attn_implementation": attention,
            }
            try:
                model = AutoModelForCausalLM.from_pretrained(str(self.config.model_dir), **kwargs)
            except Exception:
                if attention != "flash_attention_2":
                    raise
                kwargs["attn_implementation"] = "sdpa"
                model = AutoModelForCausalLM.from_pretrained(str(self.config.model_dir), **kwargs)
            self.tokenizer = AutoTokenizer.from_pretrained(str(self.config.model_dir), local_files_only=True)
            self.model = model.eval()
            self.torch = torch
            self._loaded = True
            print(f"[local-llm] loaded={self.config.model_dir} device={self.config.device}", flush=True)

    def call(self, system: str, user: str) -> dict:
        self._load()
        with self._lock:
            messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
            text = self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
                enable_thinking=bool(self.config.enable_thinking),
            )
            inputs = self.tokenizer([text], return_tensors="pt").to(self.config.device)
            with self.torch.inference_mode():
                generated = self.model.generate(
                    **inputs,
                    max_new_tokens=int(self.config.max_new_tokens),
                    do_sample=False,
                    use_cache=True,
                )
            output_ids = generated[0, inputs.input_ids.shape[1]:]
            ids = output_ids.tolist()
            think_end = self.tokenizer.convert_tokens_to_ids("</think>")
            try:
                content_start = len(ids) - ids[::-1].index(think_end)
            except ValueError:
                content_start = 0
            thinking = self.tokenizer.decode(ids[:content_start], skip_special_tokens=True).strip()
            raw = self.tokenizer.decode(ids[content_start:], skip_special_tokens=True).strip()
            parsed = parse_json_object(raw)
            parsed["_raw"] = raw
            parsed["_thinking"] = thinking
            return parsed
