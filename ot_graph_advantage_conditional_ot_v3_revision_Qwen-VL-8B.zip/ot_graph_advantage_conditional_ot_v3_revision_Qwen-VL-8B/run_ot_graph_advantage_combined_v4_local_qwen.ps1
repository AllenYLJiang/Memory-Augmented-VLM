param(
    [string]$Tag = "conditional_ot_v4_local_qwen3vl8b",
    [double]$VideoSampleFraction = 0.3,
    [int]$VideoSampleSeed = 20260725,
    [int]$MaxWindowsPerVideo = 1,
    [int]$MaxTotalWindows = 0,
    [int]$TopKAbnormalGraphs = 4,
    [int]$TopKNormalGraphs = 6,
    [int]$Workers = 3,
    [ValidateSet("full", "m2")][string]$MatchingProfile = "full",
    [ValidateSet("clip", "vlm")][string]$RetrievalMode = "clip",
    [string]$Python = "H:\Software\anaconda\install\envs\ot_qwen_gpu\python.exe",
    [string]$VlmModelDir = "G:\Qwen3-VL-8B",
    [string]$LlmModelDir = "G:\Qwen3-8B",
    [string]$ClipModelDir = "G:\Dataset\XDViolence\videos\clip-vit-large-patch14",
    [string]$VlmDevice = "cuda:0",
    [string]$LlmDevice = "cuda:1",
    [string]$ClipDevice = "cuda:0",
    [int]$MaxPixels = 147456,
    [int]$MaxVlmBatchSize = 24,
    [switch]$DiscoverGraphs,
    [int]$MaxDiscoveryCases = 30,
    [int]$DiscoveryCasesPerVideo = 1,
    [switch]$RunBlindVerifier,
    [switch]$RunLeaveOneOut,
    [switch]$NoImages,
    [switch]$Mock
)

$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
$ProjectRoot = Split-Path $Root -Parent
if (-not (Test-Path $Python)) {
    $fallback = "H:\Software\anaconda\install\envs\normal_graph_gpu\python.exe"
    if (Test-Path $fallback) { $Python = $fallback }
    else { throw "Python not found: $Python. Run setup\install_windows_gpu.cmd first." }
}

$RunDir = Join-Path $Root "runs\$Tag"
$GraphCatalog = Join-Path $Root "graph_library_v4_active_discovered\graph_catalog_v2.json"
$SourceRun = Join-Path $ProjectRoot "pipeline_backup_PartA_PartC_OK_graph_vs_node_revision\runs\graph_node_analysis\graph_vs_node_all_anomaly_20260712"
$CodeDir = Join-Path $ProjectRoot "Previous_code\structural_vlm_binary_v40_15_qwen36_highres_graph_vs_node_revision"
$Annotations = Join-Path $ProjectRoot "annotations_uniform_format.txt"
if (-not (Test-Path $Annotations)) { $Annotations = "G:\Dataset\XDViolence\videos\annotations_uniform_format.txt" }
$ExcludeVideos = Join-Path $Root "graph_library_v4_active_discovered\discovery_source_videos.txt"

foreach ($required in @($GraphCatalog, $SourceRun, $Annotations, $VlmModelDir)) {
    if (-not (Test-Path $required)) { throw "Required input does not exist: $required" }
}
if ($DiscoverGraphs -and $MatchingProfile -ne "full") {
    throw "Graph discovery requires -MatchingProfile full so failures use real conditional-OT outputs."
}

$Preflight = @(
    (Join-Path $Root "tools\verify_local_qwen.py"),
    "--vlm-dir", $VlmModelDir,
    "--llm-dir", $LlmModelDir,
    "--clip-dir", $ClipModelDir
)
if ($RetrievalMode -eq "clip") { $Preflight += "--require-clip" }
if ($DiscoverGraphs) { $Preflight += "--require-llm" }
& $Python @Preflight
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$Args = @(
    (Join-Path $Root "tools\run_analysis.py"),
    "--source-run", $SourceRun,
    "--out-dir", $RunDir,
    "--graph-catalog", $GraphCatalog,
    "--code-dir", $CodeDir,
    "--annotations", $Annotations,
    "--video-sample-fraction", "$VideoSampleFraction",
    "--video-sample-seed", "$VideoSampleSeed",
    "--max-windows-per-video", "$MaxWindowsPerVideo",
    "--max-total-windows", "$MaxTotalWindows",
    "--workers", "$Workers",
    "--model", "Qwen3-VL-8B-Instruct-local",
    "--runtime-backend", "local_qwen",
    "--model-dir", $VlmModelDir,
    "--device", $VlmDevice,
    "--attention", "auto",
    "--min-pixels", "4096",
    "--max-pixels", "$MaxPixels",
    "--max-vlm-batch-size", "$MaxVlmBatchSize",
    "--retrieval-mode", $RetrievalMode,
    "--matching-profile", $MatchingProfile,
    "--clip-model-dir", $ClipModelDir,
    "--clip-device", $ClipDevice,
    "--evidence-mode", "frames",
    "--evidence-frames", "8",
    "--evidence-slots-per-bin", "2",
    "--decision-margin", "0.03",
    "--coherence-weight", "0.25",
    "--competition-aggregation", "logmeanexp",
    "--competition-temperature", "0.1",
    "--top-k-abnormal", "$TopKAbnormalGraphs",
    "--top-k-normal", "$TopKNormalGraphs",
    "--shortlist-pool-multiplier", "2.0",
    "--gt-min-overlap-frames", "8",
    "--gt-core-overlap-threshold", "0.6666666666666666",
    "--source-window", "96",
    "--source-stride", "16",
    "--metric-min-video-completion", "0",
    "--exclude-videos-file", $ExcludeVideos,
    "--exclude-source-groups",
    "--teacher-backend", "local_qwen",
    "--teacher-model-dir", $LlmModelDir,
    "--teacher-device", $LlmDevice,
    "--teacher-max-new-tokens", "5000"
)
if (-not $RunBlindVerifier) { $Args += "--no-verifier" }
if ($RunLeaveOneOut) { $Args += "--run-leave-one-out" }
if ($NoImages) { $Args += "--no-images" }
if ($Mock) { $Args += "--mock" }
if ($DiscoverGraphs) {
    $Args += @(
        "--discover-live",
        "--discovery-out-dir", (Join-Path $RunDir "graph_discovery"),
        "--discovery-registry", (Join-Path $RunDir "graph_discovery\discovered_v3_candidates.json"),
        "--max-discovery-cases", "$MaxDiscoveryCases",
        "--discovery-cases-per-video", "$DiscoveryCasesPerVideo"
    )
}

Write-Host "=================================================================="
Write-Host " LOCAL QWEN3-VL-8B CONDITIONAL OT V4"
Write-Host "=================================================================="
Write-Host "  profile   : $MatchingProfile"
Write-Host "  retrieval : $RetrievalMode"
Write-Host "  VLM       : $VlmModelDir on $VlmDevice"
Write-Host "  LLM       : $LlmModelDir on $LlmDevice (discovery=$($DiscoverGraphs.IsPresent))"
Write-Host "  image cap : $MaxPixels pixels/image"
Write-Host "  run dir   : $RunDir"

& $Python @Args
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& $Python (Join-Path $Root "tools\summarize_local_runtime.py") --run-dir $RunDir
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$ReportArgs = @((Join-Path $Root "tools\render_report.py"), "--run-dir", $RunDir)
if ($NoImages) { $ReportArgs += "--no-images" }
& $Python @ReportArgs | Out-Null
& $Python (Join-Path $Root "tools\export_winner_loser_examples.py") `
    --run-dir $RunDir --graph-catalog $GraphCatalog `
    --out-dir (Join-Path $RunDir "winner_loser_examples")
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "[done] main report        : $(Join-Path $RunDir 'index.html')"
Write-Host "[done] winner/loser report: $(Join-Path $RunDir 'winner_loser_examples\index.html')"
