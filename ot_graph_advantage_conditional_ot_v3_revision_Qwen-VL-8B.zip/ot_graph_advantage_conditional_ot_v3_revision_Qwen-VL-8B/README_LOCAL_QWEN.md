# Local Qwen3-VL-8B / Qwen3-8B OT Graph Experiment

## Running from WSL

Full M0-M3 research comparison, local CLIP retrieval, no discovery:

```bash
cd /mnt/c/XDViolence_Graph_Distillation

TAG=qwen3vl8b_v4_full_0p3_seed20260725 \
VIDEO_SAMPLE_FRACTION=0.3 VIDEO_SAMPLE_SEED=20260725 \
MAX_WINDOWS_PER_VIDEO=1 MAX_TOTAL_WINDOWS=0 \
TOP_K_ABNORMAL_GRAPHS=4 TOP_K_NORMAL_GRAPHS=6 \
MATCHING_PROFILE=full RETRIEVAL_MODE=clip ASYNC_WORKERS=3 \
bash ot_graph_advantage_conditional_ot_v3_revision_Qwen-VL-8B/run_ot_graph_advantage_combined_v4_local_qwen.sh
```

Fast production-oriented M2 evaluation:

```bash
TAG=qwen3vl8b_v4_m2_0p3_seed20260725 \
VIDEO_SAMPLE_FRACTION=0.3 VIDEO_SAMPLE_SEED=20260725 \
MAX_WINDOWS_PER_VIDEO=1 MAX_TOTAL_WINDOWS=0 \
TOP_K_ABNORMAL_GRAPHS=4 TOP_K_NORMAL_GRAPHS=6 \
MATCHING_PROFILE=m2 RETRIEVAL_MODE=clip ASYNC_WORKERS=3 \
bash ot_graph_advantage_conditional_ot_v3_revision_Qwen-VL-8B/run_ot_graph_advantage_combined_v4_local_qwen.sh
```

One-window real-model smoke test:

```bash
TAG=qwen3vl8b_smoke VIDEO_SAMPLE_FRACTION=0.01 MAX_TOTAL_WINDOWS=1 \
TOP_K_ABNORMAL_GRAPHS=2 TOP_K_NORMAL_GRAPHS=4 \
MATCHING_PROFILE=m2 RETRIEVAL_MODE=clip ASYNC_WORKERS=1 NO_IMAGES=1 \
bash ot_graph_advantage_conditional_ot_v3_revision_Qwen-VL-8B/run_ot_graph_advantage_combined_v4_local_qwen.sh
```

After `G:\Qwen3-8B` is complete, local graph discovery is enabled with:

```bash
DISCOVER_GRAPHS=1 MAX_DISCOVERY_CASES=30 DISCOVERY_CASES_PER_VIDEO=1 \
TAG=qwen3vl8b_v4_discovery_0p1 VIDEO_SAMPLE_FRACTION=0.1 \
MATCHING_PROFILE=full RETRIEVAL_MODE=clip \
bash ot_graph_advantage_conditional_ot_v3_revision_Qwen-VL-8B/run_ot_graph_advantage_combined_v4_local_qwen.sh
```

## Running directly from PowerShell

```powershell
cd C:\XDViolence_Graph_Distillation\ot_graph_advantage_conditional_ot_v3_revision_Qwen-VL-8B

.\run_ot_graph_advantage_combined_v4_local_qwen.ps1 `
  -Tag qwen3vl8b_v4_full_0p3_seed20260725 `
  -VideoSampleFraction 0.3 -VideoSampleSeed 20260725 `
  -MaxWindowsPerVideo 1 -MaxTotalWindows 0 `
  -TopKAbnormalGraphs 4 -TopKNormalGraphs 6 `
  -MatchingProfile full -RetrievalMode clip -Workers 3
```

## Outputs and resume

Outputs are written under `runs/<TAG>/` using the original project layout. Important additions:

```text
local_runtime_summary.json          physical batches, logical requests, latency and GPU memory
cache/retrieval/                    CLIP catalog embeddings and per-window shortlist traces
cache/responses/                    prompt, raw output, parsed JSON and per-batch telemetry
records/                            complete window records; used for resume
winner_loser_examples/index.html   graph competition and graph-over-node examples
```

