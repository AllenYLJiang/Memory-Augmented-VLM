# Conditional OT v3 implementation notes

Implemented from the v2 review:

1. dual operational/core GT with merged intervals;
2. actual initial-OT feedback in the conditional prompt;
3. M3a/M3b/M3c local ablations;
4. exact shared eight-frame evidence;
5. multiple OT slots per temporal bin;
6. separated presence/location/evidence quantities;
7. family-diverse shortlist and repair-only fallback;
8. normalized multi-graph competition and Top-N sensitivity;
9. size-independent coherence weighting and catalog weights;
10. symmetric help/hurt verification;
11. optional leave-one-node-out conditionality proof;
12. failure-source diagnosis before graph creation;
13. run-specific inactive discovery registry;
14. movie/source-group exclusion;
15. stale merged prediction protection;
16. source prediction and matching-code hashes in run signature;
17. video completion audit and clustered bootstrap;
18. comprehensive deterministic/mock tests.

No live DashScope or DeepSeek request is required for the test suite.
