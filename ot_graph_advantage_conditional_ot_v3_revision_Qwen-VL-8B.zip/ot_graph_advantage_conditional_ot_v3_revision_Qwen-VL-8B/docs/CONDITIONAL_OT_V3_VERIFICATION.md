# Conditional OT v3 — revision and verification report

## Scope

Revised the supplied `ot_graph_advantage` package without changing the external detector.
The v3 code replaces the previous one-pass joint OT analysis with a genuine two-stage process:
standalone node estimation → initial OT → VLM refinement conditioned on initial OT → final OT.

## Implemented changes

- 8-frame operational GT and separate >2/3 core-event GT.
- M3a/M3b/M3c method decomposition.
- Exact deterministic T0..T7 images for every VLM call.
- Two evidence slots per temporal bin by default.
- Separate node presence, location-given-presence and direct evidence quality.
- Initial OT state included in conditional VLM prompts.
- Optional leave-one-node-out conditionality proof.
- Family-diverse normal shortlist with repair and no alphabetic fallback.
- Candidate-count-normalized log-mean-exp competition and Top-N sensitivity.
- Fixed graph-coherence weight independent of graph size.
- Symmetric blind verification of helps and hurts.
- Failure diagnosis before graph generation; only catalog gaps register inactive graphs.
- Run-specific discovery registry and movie/source-group leakage exclusion.
- Stale merged prediction protection and stronger run signatures.
- Per-video completion audit, GT audit, clustered bootstrap and video-level effects.

## Static and unit verification

```text
python -m compileall -q tools tests       PASS
bash -n run_ot_graph_advantage.sh         PASS
pytest -q                                 37 passed, 1 skipped
```

The skipped test checks conversion from an external detector checkout that is not embedded in
this standalone archive. A separate check against the supplied detector revision succeeded:

```text
loaded detector catalog: 13 graphs = 6 abnormal + 7 normal
families inferred and preserved: PASS
```

## No-API end-to-end smoke test

A synthetic six-video source run was processed with:

```text
MOCK=1
VIDEO_SAMPLE_FRACTION=1
MAX_WINDOWS_PER_VIDEO=1
DISCOVER_GRAPHS=1
MAX_DISCOVERY_CASES=3
METRIC_MIN_VIDEO_COMPLETION=0
```

Verified:

- deterministic selection;
- six matching methods;
- initial-OT conditional refinement;
- shortlist and family diversity;
- symmetric verifier path;
- live background discovery;
- inactive graph registration;
- report generation;
- `gt_label_audit.csv`;
- `video_completion_audit.csv`;
- `video_clustered_bootstrap.json`;
- `video_level_effect.csv`;
- case HTML and aggregate HTML.

## Live-API boundary

No DashScope or DeepSeek request was made in this environment. Live endpoint behavior, rate
limits and model JSON compliance must be checked with a capped smoke run before a 30-percent
run.

The current detector backend exposes `_call_messages`, which is required by exact multi-image
evidence locking.

## Cache and run-tag note

The prompt version and evidence representation changed. Use a new tag such as:

```text
conditional_ot_v3_0p3_seed314
```

Old v2 record files fail the v3 run-signature check and are recomputed. Old response-cache
files remain harmless because prompt/evidence hashes differ.

## Recommended first live command

```bash
TAG=conditional_ot_v3_smoke30 \
VIDEO_SAMPLE_FRACTION=0.03 VIDEO_SAMPLE_SEED=314 \
MAX_WINDOWS_PER_VIDEO=1 MAX_TOTAL_WINDOWS=30 \
TOP_K_ABNORMAL_GRAPHS=2 TOP_K_NORMAL_GRAPHS=4 \
ASYNC_WORKERS=2 \
DISCOVER_GRAPHS=1 MAX_DISCOVERY_CASES=10 \
DISCOVERY_CASES_PER_VIDEO=1 \
EXCLUDE_DISCOVERY_SOURCE_VIDEOS=1 \
bash ot_graph_advantage/run_ot_graph_advantage.sh
```

Only after inspecting the smoke output should `VIDEO_SAMPLE_FRACTION=0.3` and unlimited
discovery be enabled.
