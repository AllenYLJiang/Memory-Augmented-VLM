# Outputs

Each `runs/<TAG>/` contains:

```text
run_config.json                    exact settings, code/data hashes and run signature
selection_summary.json             deterministic class-wise video sample
window_manifest.jsonl              selected windows, GT-blind selection
gt_label_audit.csv                 source GT vs 8-frame operational/core GT
video_completion_audit.csv         expected/observed windows and source-video coverage
records/<case-id>.json             atomic resumable full result
cache/evidence_frames/             exact T0..T7 images used by every VLM call
cache/responses/                    prompt/evidence-locked VLM cache
ot_window_results.jsonl            aggregate completed records
summary.json                       overall report
method_metrics.csv                 M0/M1/M2/M3a/M3b/M3c metrics
core_event_metrics.csv             same methods under >2/3 core-event labels
method_decomposition.json          pairwise helps/hurts for isolated factors
paired_effects.json                M3c vs M0 helps/hurts
video_clustered_bootstrap.json     video-resampled CIs for accuracy/balanced-accuracy/AP
video_level_effect.csv             per-video M3c minus M0 effects
top_n_sensitivity.csv              normal Top-1...Top-K competition sensitivity
node_probability_change.csv        standalone -> initial OT -> conditional -> final OT
joint_graph_proof_cases.jsonl      blind-verified M3c corrections
verified_graph_hurt_cases.jsonl    symmetrically verified M3c regressions
conditional_ot_failures.jsonl      M3c failures eligible for diagnosis
index.html                         aggregate report
cases/<case-id>/index.html         exact frames, shortlist, ablations, heatmaps, transport
```

Discovery output is run-specific:

```text
graph_discovery/discovered_v3_candidates.json
graph_discovery/graph_proposals.jsonl
graph_discovery/accepted_graph_candidates.jsonl
graph_discovery/discovery_errors.jsonl
graph_discovery/discovery_summary.json
graph_discovery/CURRENT_OT_GRAPH_LIBRARY_AUGMENTED.md
```

Every discovered graph is `active=false` and is not added to the current run's frozen catalog.
