# Prompt isolation and evidence locking

## Candidate shortlist

One blind VLM call sees the frozen graph catalog and the exact T0..T7 images. It selects
`Top-K abnormal + Top-K normal` candidates. It never receives filename, filename class code,
corrected GT, source correctness or the previous winning pair. Normal candidates include a
family field; local code enforces family diversity and repairs incomplete output once.

## Independent node call

The call receives exactly one node title and cue bundle. It does not receive graph title,
other nodes, polarity, required/anchor status, filename or GT. It returns standalone presence,
location-given-presence and visual evidence quality.

## Conditional refinement call

The call receives all anonymous nodes from one graph plus:

```text
standalone probability/location/evidence for every node
initial OT presence
initial assigned slot
initial expected time
initial NULL mass
```

It must explicitly say whether other nodes increase, decrease or relocate a target node. It
outputs no fixed legacy relation schema.

## Symmetric blind verifier

Every explicit M0/M3c disagreement with complete traces can be verified. The two method
summaries are named X and Y; their order is deterministically randomized. Both use the same
format. The verifier never receives GT or which method local code considers correct.

## Leave-one-node-out

Optional proof calls remove one node at a time from the graph and repeat only conditional
refinement. These calls are limited to discordant cases because they are expensive.

## DeepSeek diagnosis

Ground truth enters only after matching. DeepSeek first classifies the failure source. It may
propose a new graph only for a genuine catalog gap. Selector, allocation, calibration and
representation failures must not be converted into more graph rules.

Automated leakage and initial-OT prompt tests are in `tests/test_prompt_leakage.py`.
