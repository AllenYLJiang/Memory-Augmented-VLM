# Method: two-stage conditional optimal transport

## 1. Problem

For a node-set graph `G={A,B,C}`, independent node matching estimates:

\[
P(A\mid V),\quad P(B\mid V),\quad P(C\mid V).
\]

Each decision can attach to the easiest-looking part of the segment. The three matches may
refer to unrelated moments, and multiple nodes can reuse the same ambiguous evidence.

The desired graph matcher instead estimates a joint latent allocation:

\[
P(A,B,C,L_A,L_B,L_C\mid V,G),
\]

where `L_i` is a soft temporal/evidence location. Other nodes and their tentative locations can
raise, suppress or relocate the probability of node `i`.

## 2. Locked visual evidence

For every selected 96-frame segment, eight deterministic frames are extracted once. Candidate
selection, independent node calls, conditional graph calls and blind verification receive the
same `T0..T7` images. This removes API-internal video sampling as a confound.

Each temporal bin is duplicated into `S` transport slots (`S=2` by default):

```text
T0#0 T0#1 T1#0 T1#1 ... T7#0 T7#1
```

Slots allow different compatible concepts to occupy the same time bin while still limiting
unbounded reuse of one visual location.

## 3. Standalone node estimation

Each independent, GT-blind VLM call returns three separate quantities:

```json
{
  "presence_probability": 0.0,
  "null_probability": 0.0,
  "location_distribution_given_present": [0,0,0,0,0,0,0,0],
  "evidence_quality_by_bin": [0,0,0,0,0,0,0,0]
}
```

The location distribution sums to one. Evidence quality is direct visual support, not another
presence probability. This avoids counting the same VLM confidence several times.

## 4. M1 and initial OT (M2)

M1 forms a unary affinity for node `i` and evidence slot `j`:

\[
U_{ij}=P_i^{standalone}\sqrt{Q_{ij}^{standalone}L_{ij}^{standalone}}.
\]

M1 chooses each row maximum independently. M2 appends a NULL column and unused-evidence row,
then solves a soft, entropy-regularized dustbin transport plan with Sinkhorn iterations.

The output per node contains:

```text
initial OT presence
NULL mass
soft slot allocation
expected temporal location
transport entropy
```

## 5. Conditional refinement from the actual initial OT state

For each shortlisted graph, the VLM receives:

- all anonymous graph nodes and cue bundles;
- every node's standalone probability/location/evidence;
- its initial OT probability, assigned slot, expected time and NULL mass;
- no filename, class code, polarity, ground truth or expected answer.

It returns:

\[
P(A\mid V,\hat B,\hat C,\hat L),
\]

and corresponding location/evidence distributions. `context_increases_from` and
`context_decreases_from` are influence traces, not physical-causality claims.

## 6. M3 decomposition

The conditional and standalone quantities are fused locally. Presence is used exactly once;
location and direct visual evidence remain separate.

- **M3a conditional row-max:** uses conditional affinities but no final OT.
- **M3b conditional OT:** applies final dustbin OT, with coherence fixed to one.
- **M3c full conditional OT:** multiplies M3b's node-set score by a separately weighted graph
  coherence term.

Graph score is:

\[
S_G=
\exp\left(\frac{\sum_i w_i\log q_i}{\sum_i w_i}\right)
\cdot c_G^{\lambda_c}.
\]

`lambda_c` is fixed across graphs; coherence therefore has no larger relative weight merely
because a graph has fewer nodes. Catalog node weights are respected.

## 7. Multi-graph competition

A blind selector chooses the same candidate set for all methods. Normal graphs are selected
from distinct families first, followed by the remaining highest-supported graphs. Incomplete
selector JSON is repaired once; unresolved shortlists are rejected instead of alphabetically
filled.

Abnormal and normal graph sets use candidate-count-normalized log-mean-exp by default:

\[
S_A=\tau\log\frac1{K_A}\sum_g e^{S_g/\tau},\qquad
S_N=\tau\log\frac1{K_N}\sum_g e^{S_g/\tau}.
\]

The margin is `S_A-S_N`. Max aggregation and normal Top-N sensitivity are also dumped.

## 8. Direct evidence for conditional dependence

With `RUN_LEAVE_ONE_OUT=1`, only discordant M0/M3c cases receive additional calls. For a target
node A:

\[
\Delta_{B\rightarrow A}=P(A\mid A,B,C,V)-P(A\mid A,C,V).
\]

This tests whether another graph node changes A's probability rather than merely changing the
prompt wording.

## 9. Evaluation labels

Main metrics use the project operational rule:

```text
max overlap with any merged anomaly interval >= 8 frames
```

A second core label is retained:

```text
union anomaly fraction > 2/3
```

It is used only to analyze complete event interiors. Annotation intervals are merged before
overlap is computed. `gt_label_audit.csv` exposes source-label disagreement.

## 10. Statistical and source-run safeguards

- formal metrics can be restricted to source videos with >=99% prediction-window coverage;
- window-level results are supplemented with video-clustered bootstrap CIs and per-video signs;
- stale merged files cannot hide newer shard files;
- run signatures include prediction, catalog, annotation, prompt and matching-code hashes;
- graph discovery source groups are excluded at movie/source level, not only exact clip ID.

## 11. Discovery policy

M3c failures are first assigned to:

```text
candidate_selector_failure
conditional_refinement_failure
ot_allocation_failure
coherence_or_calibration_failure
catalog_gap
representation_gap
```

Only `catalog_gap` may create a graph. All other failures return `representation_only` or
`no_new_graph_needed`. Every test-derived graph remains inactive and must be validated on a
separate holdout.
