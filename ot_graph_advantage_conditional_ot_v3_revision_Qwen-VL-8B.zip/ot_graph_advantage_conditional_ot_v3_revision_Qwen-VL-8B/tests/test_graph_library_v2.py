import json
import tempfile
from pathlib import Path

import _ctx  # noqa
from build_graph_library_v2 import build


def test_builder_merges_discovered_graph_and_records_source_video():
    root = Path(tempfile.mkdtemp())
    base = root / "base.json"
    registry = root / "registry.json"
    out = root / "v2"
    base.write_text(json.dumps({
        "abnormal": [{
            "key": "base_abnormal", "title": "Base abnormal", "polarity": "abnormal",
            "joint_semantics": "two cues form one event", "nodes": [
                {"key": "a", "title": "a", "cue_bundle": ["a"], "required": True},
                {"key": "b", "title": "b", "cue_bundle": ["b"], "required": True},
            ],
        }],
        "normal": [],
    }), encoding="utf-8")
    registry.write_text(json.dumps({"candidate_graphs": [{
        "source_case_id": "case",
        "source_segment_key": "Movie.Name_label_B1-0-0__seg1_f0-95",
        "graph": {
            "key": "normal_confound", "title": "Normal confound", "polarity": "normal",
            "joint_semantics": "two cues form one normal episode", "nodes": [
                {"key": "x", "title": "x", "cue_bundle": ["x"], "required": True},
                {"key": "y", "title": "y", "cue_bundle": ["y"], "required": True},
            ],
        },
    }]}), encoding="utf-8")
    manifest = build(base, registry, out)
    merged = json.loads((out / "graph_catalog_v2.json").read_text(encoding="utf-8"))
    assert manifest["final_counts"] == {"abnormal": 1, "normal": 1}
    assert merged["normal"][0]["active"] is True
    assert (out / "discovery_source_videos.txt").read_text().strip() == "Movie.Name_label_B1-0-0"
    assert (out / "discovery_source_groups.txt").read_text().strip() == "Movie.Name_label_B1-0-0"
    assert merged["normal"][0]["family"]


def test_builder_consolidates_same_key_proposals_and_inherits_exclusions():
    root = Path(tempfile.mkdtemp())
    base_dir = root / "base"
    base_dir.mkdir()
    base = base_dir / "catalog.json"
    registry = root / "registry.json"
    out = root / "active"
    base.write_text(json.dumps({"abnormal": [], "normal": []}), encoding="utf-8")
    (base_dir / "discovery_source_videos.txt").write_text("Old.Movie_label_B1-0-0\n", encoding="utf-8")

    def candidate(case, video, cue):
        return {
            "source_case_id": case,
            "source_video_id": video,
            "source_segment_key": f"{video}__seg0_f0-95",
            "graph": {
                "key": "same_graph", "title": "Same graph", "polarity": "abnormal",
                "joint_semantics": "two cues form one episode", "nodes": [
                    {
                        "key": "anchor", "title": "anchor", "cue_bundle": [cue],
                        "required": True, "anchor": True, "role": "event_anchor", "phase_hint": "onset",
                    },
                    {
                        "key": "effect", "title": "effect", "cue_bundle": ["effect"],
                        "required": True, "role": "effect", "phase_hint": "aftermath",
                    },
                ],
            },
        }

    registry.write_text(json.dumps({"candidate_graphs": [
        candidate("case1", "New.One_label_G-0-0", "cue one"),
        candidate("case2", "New.Two_label_G-0-0", "cue two"),
    ]}), encoding="utf-8")
    manifest = build(base, registry, out)
    merged = json.loads((out / "graph_catalog_v2.json").read_text(encoding="utf-8"))
    assert manifest["final_counts"] == {"abnormal": 1, "normal": 0}
    assert len(manifest["accepted_proposals"]) == 2
    assert len(manifest["consolidated_duplicate_proposals"]) == 1
    graph = merged["abnormal"][0]
    assert graph["active"] is True
    assert len(graph["discovery_sources"]) == 2
    assert graph["nodes"][0]["cue_bundle"] == ["cue one", "cue two"]
    exclusions = set((out / "discovery_source_videos.txt").read_text().splitlines())
    assert exclusions == {"Old.Movie_label_B1-0-0", "New.One_label_G-0-0", "New.Two_label_G-0-0"}


if __name__ == "__main__":
    for name, function in sorted(globals().items()):
        if name.startswith("test_"):
            function()
            print("PASS", name)
