import _ctx  # noqa
import numpy as np
import sinkhorn_ot as ot


def test_301_collapse_vs_ot_allocation():
    real = np.array([[0.90,0.70,0.10],[0.88,0.20,0.75],[0.86,0.15,0.10]]); null = np.array([0.10,0.10,0.80])
    m1 = np.concatenate([real, null[:,None]],1).argmax(1)
    assert (m1==0).all()                                  # M1: all three collapse to E1
    plan = ot.solve_dustbin_ot(ot.build_augmented_log_scores(real, null), 80)
    s = ot.summarize_transport(plan, [0.0,3.5,7.0])
    picks = [int(s["node_location"][i].argmax()) for i in range(3) if s["node_presence"][i]>=0.5]
    assert len(picks)==len(set(picks))                    # OT: no evidence collision
    assert s["node_presence"][2] < 0.5                    # C pushed to NULL
    assert (s["node_presence"]>=0).all() and (s["node_presence"]<=1).all()


def test_305_dustbin_when_all_weak():
    real = np.array([[0.2,0.15,0.1],[0.1,0.2,0.15],[0.15,0.1,0.2]]); null = np.array([0.9,0.9,0.9])
    s = ot.summarize_transport(ot.solve_dustbin_ot(ot.build_augmented_log_scores(real, null), 80), [0,3.5,7])
    assert (s["node_presence"] < 0.5).all()


def test_marginals_hold():
    real = np.random.RandomState(0).rand(4,5)*0.8+0.1; null = np.random.RandomState(1).rand(4)*0.5
    K,M=4,5; plan = ot.solve_dustbin_ot(ot.build_augmented_log_scores(real, null), 100)
    exp_mu = np.concatenate([np.ones(K),[M]])/(K+M); exp_nu = np.concatenate([np.ones(M),[K]])/(K+M)
    assert np.abs(plan.sum(1)-exp_mu).max() < 1e-4 and np.abs(plan.sum(0)-exp_nu).max() < 1e-4


if __name__ == "__main__":
    for n,f in sorted(globals().items()):
        if n.startswith("test_"): f(); print("PASS",n)
