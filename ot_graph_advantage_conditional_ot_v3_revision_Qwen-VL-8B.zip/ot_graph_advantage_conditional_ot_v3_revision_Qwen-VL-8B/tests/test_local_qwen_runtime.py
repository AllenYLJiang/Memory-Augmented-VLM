import tempfile
from pathlib import Path

import pytest
import _ctx  # noqa

from graph_catalog import read_catalog_json
from live_matching import WindowMatcher, _parse_joint
from local_qwen_backend import assert_model_complete, parse_json_object
from schemas import GraphNodeV2, GraphTemplateV2, WindowCase
from vlm_runtime import CachedVideoVLM, RuntimeConfig


def case():
    return WindowCase(
        segment_key="mock_video__seg0_f0-95",
        video_id="mock_video_label_B1-0-0",
        video_path="missing.mp4",
        start_frame=0,
        end_frame=95,
        y_true=1,
        source_record={"y_pred": 0},
    )


def instrumented_runtime():
    runtime = CachedVideoVLM(RuntimeConfig(
        code_dir=Path("."),
        cache_dir=Path(tempfile.mkdtemp()),
        mock=True,
        backend="local_qwen",
    ))
    sizes = []
    original = runtime.request_json_batch

    def wrapped(*, case, requests):
        sizes.append((len(requests), [str(value["namespace"]) for value in requests]))
        return original(case=case, requests=requests)

    runtime.request_json_batch = wrapped
    return runtime, sizes


def test_full_profile_batches_isolated_node_and_graph_prompts():
    catalog = read_catalog_json(_ctx.ROOT / "graph_library_v4_active_discovered" / "graph_catalog_v2.json")
    runtime, sizes = instrumented_runtime()
    matcher = WindowMatcher(runtime, catalog, top_k_abnormal=2, top_k_normal=4)
    result = matcher.match(case(), run_verifier=False)
    assert result["matching_profile"] == "full"
    assert len(sizes) == 3
    assert sizes[0][0] == 1
    assert sizes[1][0] == len(result["independent_node_calls"])
    assert sizes[2][0] == 6
    assert all(name.startswith("independent/") for name in sizes[1][1])
    assert all(name.startswith("conditional_refinement/") for name in sizes[2][1])


def test_m2_profile_skips_conditional_model_batch_and_marks_aliases():
    catalog = read_catalog_json(_ctx.ROOT / "graph_library_v4_active_discovered" / "graph_catalog_v2.json")
    runtime, sizes = instrumented_runtime()
    matcher = WindowMatcher(
        runtime, catalog, top_k_abnormal=2, top_k_normal=4, matching_profile="m2",
    )
    result = matcher.match(case(), run_verifier=False)
    assert len(sizes) == 2
    assert result["matching_profile"] == "m2"
    assert result["primary_graph_method"] == "unary_ot"
    assert result["competitions"]["conditional_ot_full"]["aliased_from"] == "unary_ot"
    assert all(
        graph["diagnostics"]["conditional_stage_executed"] is False
        for graph in result["graph_results"]["conditional_ot_full"].values()
    )


def test_json_parser_ignores_thinking_and_fences():
    assert parse_json_object("<think>audit</think>\n```json\n{\"ok\": true}\n```") == {"ok": True}


def test_model_completeness_fails_before_loading_transformers():
    path = Path(tempfile.mkdtemp())
    (path / "config.json").write_text("{}", encoding="utf-8")
    (path / "model.safetensors.index.json").write_text(
        '{"weight_map":{"x":"model-00001-of-00001.safetensors"}}', encoding="utf-8",
    )
    with pytest.raises(FileNotFoundError, match="missing"):
        assert_model_complete(path, "test model")


def test_compact_joint_parser_accepts_qwen_node_list_and_null_null_probability():
    graph = GraphTemplateV2(
        key="g", title="g", polarity="abnormal", joint_semantics="joint", ordered=False,
        nodes=(GraphNodeV2("a", "a", ("a",), True, True, 1.0, "event_anchor", "any"),),
        matching_policy={},
    )
    response = {"parsed": {"c": 0.8, "n": [{
        "id": "N0", "p": 0.9, "n": None, "l": [0.125] * 8, "q": [0.8] * 8,
        "b": 2, "r": "center", "e": "visible", "u": 0.1, "up": [], "down": [], "why": "",
    }]}}
    _, trace = _parse_joint(response, graph, {"N0": "a"}, [f"T{i}" for i in range(8)], 1)
    assert trace["complete"] is True
    assert trace["nodes"]["a"]["conditional_presence"] == pytest.approx(0.9)
    assert trace["nodes"]["a"]["null_probability"] == pytest.approx(0.1)


def test_compact_joint_parser_canonicalizes_empty_bins_for_explicit_absence():
    graph = GraphTemplateV2(
        key="g", title="g", polarity="normal", joint_semantics="joint", ordered=False,
        nodes=(GraphNodeV2("a", "a", ("a",), True, True, 1.0, "confound_anchor", "any"),),
        matching_policy={},
    )
    response = {"parsed": {"c": 0.0, "n": [{
        "id": "N0", "p": 0.0, "n": None, "l": [], "q": [], "b": None,
        "r": "", "e": "not visible", "u": 0.0, "up": [], "down": [], "why": "absent",
    }]}}
    _, trace = _parse_joint(response, graph, {"N0": "a"}, [f"T{i}" for i in range(8)], 1)
    assert trace["complete"] is True
    assert trace["nodes"]["a"]["canonicalized_absent_bins"] is True
