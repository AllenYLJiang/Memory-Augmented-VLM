import json
import tempfile
from pathlib import Path

import pytest
import _ctx  # noqa
import graph_catalog as gc
from schemas import GraphTemplateV2, PHASES

CODE_DIR = Path(__file__).resolve().parents[2] / "Previous_code" / "structural_vlm_binary_v40_15_qwen36_highres_graph_vs_node_revision"


def test_shipped_catalog_has_atomic_node_set_graphs_and_families():
    cat = gc.read_catalog_json(_ctx.ROOT / "graph_catalog_v2.json")
    assert len(cat) >= 10
    for template in cat.values():
        assert isinstance(template, GraphTemplateV2)
        assert not hasattr(template, "edges")
        assert template.family
        assert len(template.nodes) >= 1
        for node in template.nodes:
            assert node.phase_hint in PHASES
            assert 0.0 < node.weight <= 2.0
        assert template.polarity in ("abnormal", "normal")


def test_detector_conversion_when_checkout_is_available():
    if not (CODE_DIR / "src" / "structural_vlm_binary").exists():
        pytest.skip("external detector checkout is not included in this archive")
    cat = gc.load_graph_catalog_v2(str(CODE_DIR))
    assert len(cat) >= 10
    assert all(template.family for template in cat.values())


def test_export_roundtrip():
    cat = gc.read_catalog_json(_ctx.ROOT / "graph_catalog_v2.json")
    destination = Path(tempfile.mkdtemp()) / "graph_catalog_v3.json"
    gc.export_catalog_json(cat, destination)
    data = json.loads(destination.read_text())
    assert data["abnormal"] and data["normal"]
    node0 = data["abnormal"][0]["nodes"][0]
    assert "cue_bundle" in node0 and "role" in node0 and "phase_hint" in node0
    assert "family" in data["abnormal"][0]
    assert "edges" not in data["abnormal"][0]


def test_simulation_family_wins_before_generic_game_or_driving_tokens():
    assert gc.infer_family("game_simulation_footage") == "stage_or_simulation"
    assert gc.infer_family("simulated_or_game_driving_footage") == "stage_or_simulation"
