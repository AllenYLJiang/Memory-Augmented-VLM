from pathlib import Path

import _ctx  # noqa
from gt_annotations import label_window, load_annotations, merge_intervals


def test_merge_intervals_prevents_double_counting(tmp_path: Path):
    annotations_path = tmp_path / "annotations.txt"
    annotations_path.write_text("video_label_B1-0-0 0 20 15 40\n", encoding="utf-8")
    annotations = load_annotations(annotations_path)
    assert annotations["video_label_B1-0-0"] == [(0, 40)]
    gt = label_window("video_label_B1-0-0", 0, 95, annotations)
    assert gt["union_overlap_frames"] == 41
    assert gt["max_contiguous_overlap_frames"] == 41


def test_operational_eight_frame_and_core_labels_are_separate():
    annotations = {"video": [(20, 27)]}
    gt = label_window("video", 0, 95, annotations, min_overlap_frames=8, core_overlap_threshold=2 / 3)
    assert gt["y_true_operational"] == 1
    assert gt["y_true_core"] == 0
    assert gt["temporal_subset"] == "partial_or_boundary_anomaly"


def test_seven_frame_overlap_is_not_operational_anomaly():
    annotations = {"video": [(20, 26)]}
    gt = label_window("video", 0, 95, annotations, min_overlap_frames=8)
    assert gt["y_true"] == 0
    assert gt["temporal_subset"] == "normal"
