import _ctx  # noqa
from leave_one_out import delta_matrix


def test_303_leave_one_out_deltas_positive():
    full = {"A":0.80,"B":0.75,"C":0.70}
    subset = {"B":{"A":0.55,"C":0.60}, "C":{"A":0.60,"B":0.62}}   # dropping B or C lowers A
    rows = delta_matrix(full, subset)
    a = next(r for r in rows if r["target_node"]=="A")
    assert a["delta_B_to_A"] > 0 and a["delta_C_to_A"] > 0        # P(A|B,C) > P(A|without)


if __name__ == "__main__":
    for n,f in sorted(globals().items()):
        if n.startswith("test_"): f(); print("PASS",n)
