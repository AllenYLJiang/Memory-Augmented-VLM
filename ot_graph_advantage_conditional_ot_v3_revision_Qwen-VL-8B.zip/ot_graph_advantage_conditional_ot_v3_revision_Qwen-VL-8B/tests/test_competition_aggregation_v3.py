import _ctx  # noqa
from competition import _aggregate, compete


class Result:
    def __init__(self, key, score):
        self.graph_key = key
        self.graph_score = score


def test_normalized_logmeanexp_does_not_reward_duplicate_candidates():
    one = _aggregate([0.7], "logmeanexp", 0.1)
    four = _aggregate([0.7, 0.7, 0.7, 0.7], "logmeanexp", 0.1)
    assert abs(one - four) < 1e-12


def test_max_and_logmeanexp_ablations_are_distinct_for_mixed_candidates():
    abnormal = [Result("a1", 0.8), Result("a2", 0.2)]
    normal = [Result("n1", 0.75), Result("n2", 0.74), Result("n3", 0.1), Result("n4", 0.1)]
    max_result = compete("m", abnormal, normal, aggregation="max")
    lme_result = compete("m", abnormal, normal, aggregation="logmeanexp", temperature=0.1)
    assert max_result["margin"] != lme_result["margin"]
    assert lme_result["candidate_counts"] == {"abnormal": 2, "normal": 4}
