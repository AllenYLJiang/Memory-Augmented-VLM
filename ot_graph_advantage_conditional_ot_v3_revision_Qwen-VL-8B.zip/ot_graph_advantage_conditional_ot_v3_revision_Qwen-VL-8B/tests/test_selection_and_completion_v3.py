import json
import os
import time
from pathlib import Path

import _ctx  # noqa
from selection import discover_prediction_files, source_group_id
from video_completion import expected_window_count


def test_stale_merged_predictions_do_not_hide_newer_shards(tmp_path: Path):
    merged = tmp_path / "merged" / "predictions.jsonl"
    shard = tmp_path / "shard_1" / "test" / "predictions.jsonl"
    merged.parent.mkdir(parents=True)
    shard.parent.mkdir(parents=True)
    merged.write_text("{}\n", encoding="utf-8")
    time.sleep(0.01)
    shard.write_text("{}\n", encoding="utf-8")
    files = discover_prediction_files(tmp_path)
    assert files == [shard]


def test_source_group_is_movie_level_not_clip_level():
    a = "Bad.Boys.II.2003__#00-06-42_00-10-00_label_B2-G-0"
    b = "Bad.Boys.II.2003__#00-10-00_00-12-00_label_B2-0-0"
    assert source_group_id(a) == source_group_id(b) == "Bad.Boys.II.2003"


def test_expected_window_count_matches_clamped_sliding_grid():
    assert expected_window_count(96, 96, 16) == 1
    assert expected_window_count(97, 96, 16) == 2
    assert expected_window_count(128, 96, 16) == 3
