import _ctx  # noqa
import matching as mm, mock
from competition import compete


def test_competition_decision():
    ga = mock.mk_graph(["A","B"], polarity="abnormal"); gn = mock.mk_graph(["X","Y"], polarity="normal")
    ua = mock.mk_unary(["A","B"], ["E1","E2"], [[0.9,0.2],[0.2,0.9]], [0.1,0.1])
    un = mock.mk_unary(["X","Y"], ["E1","E2"], [[0.3,0.2],[0.2,0.3]], [0.6,0.6])
    ra = mm.match_graph_unary_ot(ga, ua, [0.0,7.0]); rn = mm.match_graph_unary_ot(gn, un, [0.0,7.0])
    c = compete("unary_ot", [ra], [rn])
    assert c["decision"] == "abnormal" and c["y_pred"] == 1 and c["margin"] > 0


if __name__ == "__main__":
    for n,f in sorted(globals().items()):
        if n.startswith("test_"): f(); print("PASS",n)
