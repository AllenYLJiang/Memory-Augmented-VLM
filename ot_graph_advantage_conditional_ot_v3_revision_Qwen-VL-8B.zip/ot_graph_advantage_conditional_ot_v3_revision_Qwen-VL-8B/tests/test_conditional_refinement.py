import _ctx  # noqa
import numpy as np
import matching as mm, mock


def test_303_conditional_support_raises_presence():
    # A is moderate standalone; conditional prior high because B,C form a coherent episode
    g = mock.mk_graph(["A","B","C"])
    u = mock.mk_unary(["A","B","C"], ["E1","E2","E3"],
                      [[0.55,0.3,0.2],[0.3,0.85,0.2],[0.2,0.25,0.85]], [0.4,0.15,0.15])
    m2 = mm.match_graph_unary_ot(g, u, [0.0,3.5,7.0])
    cond = mock.mk_conditional(["A","B","C"], ["E1","E2","E3"],
                               [[0.8,0.3,0.2],[0.3,0.85,0.2],[0.2,0.25,0.85]], [0.2,0.15,0.15],
                               priors=[0.85,0.8,0.8], coherence=0.85)
    m3 = mm.match_graph_conditional_ot(g, u, cond, [0.0,3.5,7.0])
    assert m3.node_presence["A"] > m2.node_presence["A"]          # conditioning raises A
    assert m3.graph_coherence == 0.85


def test_304_conditional_suppression_to_null():
    # A strong standalone on E1, but B,C localize elsewhere -> conditional makes A absent
    g = mock.mk_graph(["A","B","C"])
    u = mock.mk_unary(["A","B","C"], ["E1","E2","E3"],
                      [[0.9,0.2,0.2],[0.2,0.85,0.2],[0.2,0.2,0.85]], [0.1,0.15,0.15])
    m2 = mm.match_graph_unary_ot(g, u, [0.0,3.5,7.0])
    cond = mock.mk_conditional(["A","B","C"], ["E1","E2","E3"],
                               [[0.1,0.1,0.1],[0.2,0.85,0.2],[0.2,0.2,0.85]], [0.85,0.15,0.15],
                               priors=[0.05,0.8,0.8], coherence=0.7)
    m3 = mm.match_graph_conditional_ot(g, u, cond, [0.0,3.5,7.0])
    assert m2.node_presence["A"] >= 0.5 and m3.node_presence["A"] < 0.5   # suppressed to NULL


if __name__ == "__main__":
    for n,f in sorted(globals().items()):
        if n.startswith("test_"): f(); print("PASS",n)
