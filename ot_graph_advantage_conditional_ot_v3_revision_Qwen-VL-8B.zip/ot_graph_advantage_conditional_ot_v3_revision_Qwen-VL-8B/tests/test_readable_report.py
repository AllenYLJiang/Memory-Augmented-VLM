import tempfile
from pathlib import Path

import _ctx  # noqa
from render_report import METHODS, _margin_gain, _opposing_graphs, render_case


def _competition(abnormal, normal, margin, decision, y_pred):
    return {
        "aggregation": "logmeanexp",
        "best_abnormal_graph": abnormal,
        "best_abnormal_score": 0.6,
        "best_normal_graph": normal,
        "best_normal_score": 0.6 - margin,
        "margin": margin,
        "decision": decision,
        "y_pred": y_pred,
    }


def _graph_result(score, node_key, node_score, assigned="T1#0"):
    return {
        "graph_score": score,
        "node_geometric_score": score,
        "graph_coherence": 0.8,
        "required_coverage": node_score,
        "complete": node_score >= 0.8,
        "node_presence": {node_key: node_score},
        "assignments": [{"node_key": node_key, "assigned": assigned, "mass": 0.5}],
        "diagnostics": {"collision_details": {"slot_collisions": 0}},
    }


def test_readable_case_leads_with_gt_aligned_and_opposing_graphs():
    result = {
        "case_id": "case-1",
        "video_id": "example_label_G-0-0",
        "start_frame": 0,
        "end_frame": 95,
        "y_true": 1,
        "y_true_operational": 1,
        "y_true_core": 1,
        "metric_eligible": True,
        "gt": {
            "temporal_subset": "core_anomaly",
            "overlap_frames": 96,
            "window_frames": 96,
        },
        "comparison": {
            "graph_helps": True,
            "graph_hurts": False,
            "verified_graph_help": True,
            "verified_graph_hurt": False,
        },
        "competitions": {
            "independent_direct_nodes": _competition("blast", "news", 0.01, "uncertain", 0),
            "shared_unary_rowmax": _competition("blast", "news", 0.02, "uncertain", 0),
            "unary_ot": _competition("blast", "news", 0.04, "abnormal", 1),
            "conditional_rowmax": _competition("blast", "news", 0.05, "abnormal", 1),
            "conditional_ot_no_coherence": _competition("blast", "news", 0.08, "abnormal", 1),
            "conditional_ot_full": _competition("blast", "news", 0.08, "abnormal", 1),
        },
        "graph_results": {
            method: {
                "blast": _graph_result(0.40 + index * 0.01, "bloom", 0.70 + index * 0.04),
                "news": _graph_result(0.20 + index * 0.01, "logo", 0.80, "T0#0"),
                "sports": _graph_result(0.18 + index * 0.01, "jersey", 0.75, "T2#0"),
                "staged": _graph_result(0.16 + index * 0.01, "staging", 0.70, "T3#0"),
                "traffic": _graph_result(0.14 + index * 0.01, "vehicle", 0.65, "T4#0"),
            }
            for index, method in enumerate(METHODS)
        },
        "joint_graph_calls": {
            "blast": {
                "episode_summary": "A source bloom is localized before visible damage.",
                "nodes": {"bloom": {"visible_evidence": "Bright source at T1."}},
            },
            "news": {
                "episode_summary": "A logo is visible.",
                "nodes": {"logo": {"visible_evidence": "Logo at T0."}},
            },
        },
        "graph_candidates": {
            "selected_abnormal": ["blast"],
            "selected_normal": ["traffic", "staged", "news", "sports"],
        },
        "probability_flow": [],
        "independent_node_calls": {},
        "blind_verifier": {
            "preferred_method": "graph",
            "confidence": 0.9,
            "visual_reason": "The graph localizes the event.",
        },
        "conditionality_audit": None,
    }

    run_dir = Path(tempfile.mkdtemp())
    output = Path(render_case(result, run_dir, no_images=True))
    document = output.read_text(encoding="utf-8")

    assert (output.parent / "readable.html").is_file()
    assert "GT-aligned graph candidate" in document
    assert "Opposing graph #3" in document
    assert "Opposing graph #4" not in document
    assert "M0 independent node P" in document
    assert "M2 Unary OT node P" in document
    assert "M3c full conditional OT node P" in document
    assert "Graph-level scores under every setting" in document
    assert "Abnormal aggregate A" in document
    assert "Normal aggregate N" in document
    assert "Raw margin A - N" in document
    assert "Direct decision arithmetic" in document
    assert "DIRECT WRONG-TO-RIGHT CORRECTION" in document
    assert "A 0.600000 - N 0.590000 = M +0.010000" in document
    assert "Recompute A, N and margin from every candidate graph score" in document
    assert "normalized log-mean-exp formula" in document
    assert "replayed A" in document and "stored A" in document
    assert "blast" in document and "news" in document and "sports" in document and "staged" in document
    assert _opposing_graphs(result) == ["news", "sports", "staged"]
    assert "T1#0" in document
    assert abs(_margin_gain(result) - 0.07) < 1e-12
