import _ctx  # noqa
from discover_ot_failures import _graph_signature, _prompt, _validate_graph


def _graph():
    return {
        "key": "two_visible_states",
        "title": "Two visible states",
        "polarity": "normal",
        "family": "synthetic",
        "joint_semantics": "both visible states occupy compatible evidence bins",
        "nodes": [
            {"key": "a", "title": "state a", "cue_bundle": ["visible a"]},
            {"key": "b", "title": "state b", "cue_bundle": ["visible b"]},
        ],
    }


def test_node_set_graph_without_edges_is_valid():
    graph = _graph()
    assert _validate_graph(graph) == []
    assert len(_graph_signature(graph)) == 64


def test_legacy_edges_are_rejected():
    graph = _graph()
    graph["edges"] = [{"source": "a", "target": "b"}]
    assert "legacy_edges_are_forbidden" in _validate_graph(graph)


def test_directed_discovery_rejects_wrong_polarity():
    graph = _graph()
    assert "wrong_polarity_expected_abnormal" in _validate_graph(graph, "abnormal")


def _case(y_true: int, y_pred: int):
    return {
        "case_id": "case",
        "y_true": y_true,
        "graph_candidates": {"complete": True, "selected_abnormal": [], "selected_normal": []},
        "completeness": {"independent": True, "joint": True},
        "competitions": {
            "independent_direct_nodes": {"y_pred": y_pred, "margin": 0.4},
            "unary_ot": {"y_pred": y_pred, "margin": 0.4},
            "conditional_rowmax": {"y_pred": y_pred, "margin": 0.4},
            "conditional_ot_no_coherence": {"y_pred": y_pred, "margin": 0.4},
            "conditional_ot_full": {
                "y_pred": y_pred,
                "decision": "abnormal" if y_pred else "normal",
                "best_abnormal_graph": "fight_graph",
                "best_normal_graph": "normal_graph",
                "margin": 0.4,
                "decision_margin_threshold": 0.03,
            },
        },
    }


def test_failure_prompt_allows_non_catalog_diagnoses_and_only_correct_polarity_graph():
    fp_prompt = _prompt(_case(0, 1), {})
    fn_prompt = _prompt(_case(1, 0), {})
    assert "no_new_graph_needed|representation_only|add_normal_graph" in fp_prompt
    assert '"polarity": "normal"' in fp_prompt
    assert "Only when the existing catalog genuinely lacks" in fp_prompt
    assert "no_new_graph_needed|representation_only|add_abnormal_graph" in fn_prompt
    assert '"polarity": "abnormal"' in fn_prompt


if __name__ == "__main__":
    for name, function in sorted(globals().items()):
        if name.startswith("test_"):
            function()
            print("PASS", name)
