import _ctx  # noqa

import prompts
from graph_catalog import read_catalog_json


CATALOG = read_catalog_json(_ctx.ROOT / "graph_catalog_v2.json")


def test_independent_prompt_has_exactly_one_node_context():
    graph = CATALOG["localized_discharge_chain"]
    prompt = prompts.independent_node_prompt(graph.nodes[0])
    assert graph.nodes[0].title in prompt
    assert graph.nodes[1].title not in prompt
    assert graph.key not in prompt
    assert "abnormal" not in prompt.lower()
    assert graph.nodes[0].role not in prompt
    assert "phase_hint" not in prompt
    assert "required" not in prompt
    prompts.assert_blind(prompt)


def test_conditional_refinement_is_blind_and_receives_initial_ot_state():
    graph = CATALOG["localized_discharge_chain"]
    independent = {
        node.key: {
            "presence": 0.4 + 0.1 * index,
            "location_distribution_given_present": [0.125] * 8,
            "evidence_quality_by_bin": [0.5] * 8,
            "best_bin": index,
            "visible_evidence": "anonymous evidence",
        }
        for index, node in enumerate(graph.nodes)
    }
    initial_ot = {
        "node_presence": {node.key: 0.5 for node in graph.nodes},
        "expected_time": {node.key: index / 7.0 for index, node in enumerate(graph.nodes)},
        "assignments": [{"node_key": node.key, "assigned": f"T{index}#0"} for index, node in enumerate(graph.nodes)],
        "diagnostics": {"null_mass_by_node": {node.key: 0.1 for node in graph.nodes}},
    }
    prompt, mapping = prompts.conditional_refinement_prompt(graph, independent, initial_ot)
    assert set(mapping.values()) == set(graph.node_keys)
    assert all(node.title in prompt for node in graph.nodes)
    assert "initial_ot_estimate" in prompt
    assert "standalone_estimate" in prompt
    lowered = prompt.lower()
    for legacy in ("causes", "precedes", "cooccur", "supports"):
        assert legacy not in lowered
    prompts.assert_blind(prompt)


def test_shortlist_prompt_requests_diverse_normal_candidates_without_gt():
    prompt, mapping = prompts.graph_shortlist_prompt(CATALOG, 2, 4)
    assert len([key for key in mapping if key.startswith("A")]) >= 2
    assert len([key for key in mapping if key.startswith("N")]) >= 4
    assert "diverse" in prompt.lower()
    assert "family" in prompt.lower()
    prompts.assert_blind(prompt)
