import _ctx  # noqa
import matching
import mock


def test_conditional_methods_share_affinity_but_isolate_ot_and_coherence():
    graph = mock.mk_graph(["A", "B", "C"])
    unary = mock.mk_unary(
        ["A", "B", "C"], ["E1", "E2", "E3"],
        [[0.9, 0.5, 0.2], [0.8, 0.4, 0.7], [0.75, 0.2, 0.1]],
        [0.1, 0.1, 0.5],
    )
    cond = mock.mk_conditional(
        ["A", "B", "C"], ["E1", "E2", "E3"],
        [[0.8, 0.5, 0.2], [0.75, 0.4, 0.8], [0.7, 0.2, 0.1]],
        [0.15, 0.1, 0.6], priors=[0.85, 0.9, 0.35], coherence=0.4,
    )
    rowmax = matching.match_graph_conditional_rowmax(graph, unary, cond, [0, 3.5, 7])
    ot_no_coherence = matching.match_graph_conditional_ot(
        graph, unary, cond, [0, 3.5, 7], use_coherence=False,
    )
    full = matching.match_graph_conditional_ot(graph, unary, cond, [0, 3.5, 7], use_coherence=True)
    assert rowmax.method == "conditional_rowmax"
    assert ot_no_coherence.method == "conditional_ot_no_coherence"
    assert full.method == "conditional_ot_full"
    assert ot_no_coherence.graph_coherence == 1.0
    assert full.graph_coherence == 0.4
    assert full.graph_score < ot_no_coherence.graph_score


def test_graph_coherence_weight_is_independent_of_node_count():
    two = mock.mk_graph(["A", "B"])
    three = mock.mk_graph(["A", "B", "C"])
    two_score = matching.graph_score([0.8, 0.8], two.weights, 0.25, coherence_weight=0.5)
    three_score = matching.graph_score([0.8, 0.8, 0.8], three.weights, 0.25, coherence_weight=0.5)
    assert abs(two_score - three_score) < 1e-12
