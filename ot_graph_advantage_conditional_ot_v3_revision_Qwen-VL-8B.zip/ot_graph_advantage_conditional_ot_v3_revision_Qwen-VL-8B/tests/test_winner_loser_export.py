from _ctx import ROOT

from export_winner_loser_examples import select_case


def _record(decision="abnormal", truth=1):
    return {
        "case_id": "case",
        "segment_key": "video__seg0_f0-95",
        "y_true": truth,
        "graph_candidates": {
            "selected_abnormal": ["a1", "a2"],
            "selected_normal": ["n1", "n2"],
        },
        "competitions": {
            "independent_direct_nodes": {"decision": "normal", "y_pred": 0, "margin": -0.1},
            "conditional_ot_full": {
                "decision": decision,
                "y_pred": 1 if decision == "abnormal" else 0,
                "best_abnormal_graph": "a1",
                "best_normal_graph": "n1",
                "best_abnormal_score": 0.7,
                "best_normal_score": 0.5,
                "margin": 0.2,
                "decision_margin_threshold": 0.03,
            },
        },
        "graph_results": {
            "conditional_ot_full": {
                "a1": {"graph_score": 0.72},
                "a2": {"graph_score": 0.4},
                "n1": {"graph_score": 0.69},
                "n2": {"graph_score": 0.2},
            }
        },
        "comparison": {"verified_graph_help": True},
    }


def test_selects_nearest_opposite_graph_and_marks_advantage():
    value = select_case(_record())
    assert value is not None
    assert value["winning_graph"] == "a1"
    assert value["losing_graph"] == "n1"
    assert value["graph_advantage"] is True
    assert value["verified_graph_help"] is True


def test_rejects_uncertain_or_wrong_polarity_decision():
    assert select_case(_record(decision="uncertain")) is None
    assert select_case(_record(decision="normal", truth=1)) is None
