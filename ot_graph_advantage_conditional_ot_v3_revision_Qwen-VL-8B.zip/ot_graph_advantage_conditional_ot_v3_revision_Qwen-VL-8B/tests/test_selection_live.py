import tempfile
from pathlib import Path

import _ctx  # noqa
from graph_catalog import read_catalog_json
from live_matching import WindowMatcher
from schemas import WindowCase
from selection import label_codes, sample_video_ids, select_windows, source_graph_pair
from vlm_runtime import CachedVideoVLM, RuntimeConfig


CATALOG = read_catalog_json(_ctx.ROOT / "graph_catalog_v2.json")


def _record(video_id, segment, abnormal="localized_discharge_chain", normal="camera_flash_or_edit"):
    return {
        "segment_key": f"{video_id}__seg{segment}_f0-95",
        "video_id": video_id,
        "video_path": "/does/not/matter/in/mock.mp4",
        "start_frame": 0,
        "end_frame": 95,
        "best_abnormal_graph": abnormal,
        "best_normal_graph": normal,
        "y_pred": 0,
        "binary_decision": "normal",
        "_corrected_gt": {"y_true": 1, "overlap_fraction": 1.0},
    }


def test_none_graph_pairs_are_never_selected():
    video = "example_label_B2-0-0"
    records = [_record(video, 0, "NONE", "NONE"), _record(video, 1)]
    selected = select_windows(records, {video}, 42, 1, 0, set(CATALOG))
    assert len(selected) == 1
    assert selected[0]["segment_key"].endswith("seg1_f0-95")


def test_nested_source_pair_is_a_gt_blind_fallback():
    record = _record("example_label_B2-0-0", 2, "NONE", "NONE")
    record["node_graph_ablation"] = {
        "operational_graph": {
            "best_abnormal_graph": "localized_discharge_chain",
            "best_normal_graph": "camera_flash_or_edit",
        }
    }
    assert source_graph_pair(record) == ("localized_discharge_chain", "camera_flash_or_edit")


def test_class_fraction_sampling_is_deterministic():
    records = []
    for index in range(20):
        records.append(_record(f"v{index}_label_B1-0-0", 0))
        records.append(_record(f"s{index}_label_B2-0-0", 0))
    first, manifest1 = sample_video_ids(records, 0.1, 42)
    second, manifest2 = sample_video_ids(records, 0.1, 42)
    assert first == second
    assert manifest1 == manifest2
    assert manifest1["class_stats"]["B1"]["target_independent_draw"] == 2
    assert manifest1["class_stats"]["B2"]["target_independent_draw"] == 2


def test_movie_titles_with_dots_keep_filename_labels():
    assert label_codes("Bad.Boys.II.2003__#00-06-42_00-10-00_label_B2-G-0") == {"B2", "G"}
    assert label_codes("City.Of.Men.2007__#00-51-50_00-53-31_label_B2-0-0.mp4") == {"B2"}


def test_mock_live_match_has_separate_and_joint_calls():
    source = _record("example_label_B2-0-0", 3)
    case = WindowCase(
        segment_key=source["segment_key"], video_id=source["video_id"],
        video_path=source["video_path"], start_frame=0, end_frame=95,
        y_true=1, source_record=source,
    )
    cache = Path(tempfile.mkdtemp())
    runtime = CachedVideoVLM(RuntimeConfig(code_dir=_ctx.ROOT, cache_dir=cache, mock=True))
    result = WindowMatcher(runtime, CATALOG, use_catalog_shortlist=False).match(case)
    expected_nodes = set(CATALOG["localized_discharge_chain"].node_keys + CATALOG["camera_flash_or_edit"].node_keys)
    assert set(result["independent_node_calls"]) == expected_nodes
    assert set(result["joint_graph_calls"]) == {"localized_discharge_chain", "camera_flash_or_edit"}
    assert set(result["competitions"]) == {
        "independent_direct_nodes", "shared_unary_rowmax", "unary_ot",
        "conditional_rowmax", "conditional_ot_no_coherence", "conditional_ot_full",
    }
    for graph_result in result["graph_results"]["conditional_ot_full"].values():
        assert graph_result["transport_plan"]


def test_mock_catalog_shortlist_competes_multiple_normal_graphs():
    source = _record("example_label_B2-0-0", 5)
    case = WindowCase(source["segment_key"], source["video_id"], source["video_path"], 0, 95, 1, source)
    cache = Path(tempfile.mkdtemp())
    runtime = CachedVideoVLM(RuntimeConfig(code_dir=_ctx.ROOT, cache_dir=cache, mock=True))
    result = WindowMatcher(runtime, CATALOG, top_k_abnormal=2, top_k_normal=4).match(case)
    candidates = result["graph_candidates"]
    assert len(candidates["selected_abnormal"]) == 2
    assert len(candidates["selected_normal"]) == 4
    assert len(result["joint_graph_calls"]) == 6
    assert result["version"] == "multi_candidate_conditional_ot_v3"


def test_shortlist_pool_ranks_more_candidates_than_it_deploys():
    source = _record("example_label_B2-0-0", 6)
    case = WindowCase(source["segment_key"], source["video_id"], source["video_path"], 0, 95, 1, source)
    cache = Path(tempfile.mkdtemp())
    runtime = CachedVideoVLM(RuntimeConfig(code_dir=_ctx.ROOT, cache_dir=cache, mock=True))
    result = WindowMatcher(
        runtime, CATALOG, top_k_abnormal=2, top_k_normal=4, shortlist_pool_multiplier=2.0,
    ).match(case)
    candidates = result["graph_candidates"]
    assert len(candidates["selected_abnormal"]) == 2
    assert len(candidates["selected_normal"]) == 4
    assert candidates["selector_pool"]["abnormal"] > 2
    assert candidates["selector_pool"]["normal"] > 4


def test_mock_response_cache_resumes_without_recompute():
    source = _record("example_label_B2-0-0", 4)
    case = WindowCase(source["segment_key"], source["video_id"], source["video_path"], 0, 95, 1, source)
    cache = Path(tempfile.mkdtemp())
    runtime = CachedVideoVLM(RuntimeConfig(code_dir=_ctx.ROOT, cache_dir=cache, mock=True))
    first = runtime.request_json(case=case, prompt="mock prompt", namespace="test", mock_spec={"kind": "independent", "node_key": "x"})
    second = runtime.request_json(case=case, prompt="mock prompt", namespace="test", mock_spec={"kind": "independent", "node_key": "x"})
    assert first["cache_hit"] is False
    assert second["cache_hit"] is True
    assert first["parsed"] == second["parsed"]


if __name__ == "__main__":
    for name, function in sorted(globals().items()):
        if name.startswith("test_"):
            function()
            print("PASS", name)
