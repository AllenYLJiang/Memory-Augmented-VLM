import _ctx  # noqa
import numpy as np
import matching as mm, mock


def test_301_m1_collides_m2_does_not():
    g = mock.mk_graph(["A","B","C"])
    u = mock.mk_unary(["A","B","C"], ["E1","E2","E3"],
                      [[0.9,0.7,0.1],[0.88,0.2,0.75],[0.86,0.15,0.1]], [0.1,0.1,0.8])
    m1 = mm.match_graph_shared_rowmax(g, u, [0.0,3.5,7.0])
    m2 = mm.match_graph_unary_ot(g, u, [0.0,3.5,7.0])
    assert m1.diagnostics["collision_evidence"] >= 1      # visible independent rows collide on E1
    assert m2.diagnostics["collision_evidence"] == 0      # OT de-collides
    # same unary matrix used, only allocation differs
    assert u.scores.shape == (3,3)


def test_306_single_node_m1_close_to_m2():
    g = mock.mk_graph(["A"])
    u = mock.mk_unary(["A"], ["E1","E2"], [[0.8,0.3]], [0.1])
    m1 = mm.match_graph_shared_rowmax(g, u, [0.0,7.0])
    m2 = mm.match_graph_unary_ot(g, u, [0.0,7.0])
    assert abs(m1.node_presence["A"] - m2.node_presence["A"]) < 0.35   # nearly identical for K=1


if __name__ == "__main__":
    for n,f in sorted(globals().items()):
        if n.startswith("test_"): f(); print("PASS",n)
