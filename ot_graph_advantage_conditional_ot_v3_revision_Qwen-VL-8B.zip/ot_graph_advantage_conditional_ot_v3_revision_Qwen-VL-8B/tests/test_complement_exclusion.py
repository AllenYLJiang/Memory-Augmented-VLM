import json
import tempfile
from pathlib import Path

import _ctx  # noqa
from build_complement_exclusion import build


def test_build_uses_prior_sample_and_active_sources_union():
    root = Path(tempfile.mkdtemp())
    selection = root / "selection.json"
    sources = root / "sources.txt"
    output = root / "excluded.txt"
    selection.write_text(json.dumps({
        "source_anomaly_videos": 6,
        "selected_videos": [{"video_id": "a"}, {"video_id": "b"}, {"video_id": "c"}],
    }), encoding="utf-8")
    sources.write_text("c\nd\n", encoding="utf-8")

    manifest = build(selection, sources, output)

    assert output.read_text(encoding="utf-8").splitlines() == ["a", "b", "c", "d"]
    assert manifest["prior_sample_videos"] == 3
    assert manifest["active_library_source_videos"] == 2
    assert manifest["overlap_prior_sample_and_active_sources"] == 1
    assert manifest["excluded_union_videos"] == 4
    assert manifest["safe_remaining_videos_before_window_filter"] == 2
