import _ctx  # noqa
import numpy as np
import matching as mm, temporal as tp, mock
from schemas import N_BINS


def test_302_early_middle_late_permutation():
    g = mock.mk_graph(["A","B","C"])
    u = mock.mk_unary(["A","B","C"], ["E1","E2","E3"],
                      [[0.9,0.5,0.3],[0.5,0.9,0.4],[0.3,0.4,0.9]], [0.1,0.1,0.1])
    # phase distributions: A early, B middle, C late
    phase = np.zeros((3,N_BINS))
    phase[0,0:2]=2; phase[1,3:5]=2; phase[2,6:8]=2
    cond = mock.mk_conditional(["A","B","C"], ["E1","E2","E3"],
                               [[0.9,0.5,0.3],[0.5,0.9,0.4],[0.3,0.4,0.9]], [0.1,0.1,0.1],
                               priors=[0.8,0.8,0.8], coherence=0.85, phase=phase)
    # evidence E1 early(bin0), E2 mid(bin3), E3 late(bin7)
    from schemas import EvidenceUnit
    units=[EvidenceUnit("E1",0,1,(),"full","a",3,3,1),EvidenceUnit("E2",3,4,(),"full","b",3,3,1),EvidenceUnit("E3",6,7,(),"full","c",3,3,1)]
    tmask = tp.evidence_time_mask(units)
    T = tp.temporal_compatibility(tp.phase_softmax(phase), tmask)
    m3 = mm.match_graph_conditional_ot(g, u, cond, [0.5,3.5,6.5], temporal=T)
    picks = {k:int(np.argmax(list(m3.diagnostics["fused_affinity"][i]))) for i,k in enumerate(["A","B","C"])}
    # final OT plan argmax should be the early->middle->late permutation
    import sinkhorn_ot as ot
    plan = np.array(m3.transport_plan)
    loc = plan[:3,:3]/plan[:3,:3].sum(1, keepdims=True)
    assert loc[0].argmax()==0 and loc[1].argmax()==1 and loc[2].argmax()==2


if __name__ == "__main__":
    for n,f in sorted(globals().items()):
        if n.startswith("test_"): f(); print("PASS",n)
